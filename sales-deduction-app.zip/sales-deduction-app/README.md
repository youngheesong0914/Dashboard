# Sales-Deduction AI Agent — 백엔드/프론트엔드 분리 버전

`0710_wireframe.html`에 하드코딩되어 있던 데이터를 Python(FastAPI) 백엔드로 옮기고,
JSP 프론트엔드가 API를 fetch해서 화면을 그리는 구조로 분리한 프로젝트입니다.

```
sales-deduction-app/
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py          # FastAPI 앱 — 4개 REST 엔드포인트 + 집계 로직
│       └── data.py          # 와이어프레임에서 추출한 데이터 (→ 나중에 DB 조회로 교체)
└── frontend/
    ├── index.jsp            # → approval.jsp 리다이렉트
    ├── approval.jsp         # 01 Approval Review
    ├── claimLt.jsp          # 02 Claim L/T Analysis
    ├── overdue.jsp          # 03 Overdue Conditions
    ├── budget.jsp           # 04 Target Plan Budget
    ├── common/
    │   ├── head.jspf        # 공통 <head> (CSS·폰트·API_BASE 주입)
    │   └── header.jspf      # 공통 상단바 + 네비 (activeNav로 활성 탭 표시)
    └── static/
        ├── dashboard.css    # 공통 스타일
        ├── common.js        # 유틸·fetch 캐시·에러 처리·네비 뱃지
        ├── approval.js      # 페이지별 렌더링 스크립트
        ├── claim.js
        ├── overdue.js
        └── budget.js
```

## 아키텍처

- **페이지 분리**: 화면당 JSP 1장씩 총 4개이며 상단 네비는 페이지 간 링크 이동입니다.
  공통 헤더/head는 `common/*.jspf`를 JSP 정적 include로 공유하고, 각 페이지가
  `activeNav` 변수로 활성 탭을 지정합니다.
- **백엔드는 숫자와 구조만** 내려줍니다. 스테이지별 집계, 리스크 유형 집계,
  연체 버킷 합산, 예산 %/합계 계산 등 데이터 로직은 전부 `main.py`에서 수행합니다.
- **프론트엔드는 표현만** 담당합니다. 각 페이지는 로드 시 자기 엔드포인트 하나만
  fetch해서 렌더링합니다 (`common.js` 공통 유틸 + 페이지별 `*.js`).
- 네비의 Approval 뱃지(대기 건수)는 `common.js`가 모든 페이지에서 `/api/approval`로
  받아 채웁니다. approval 페이지에서는 본문 fetch와 요청 캐시를 공유해
  실제 요청은 1번만 나갑니다.


## 백엔드 실행

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

| Method | Endpoint | 화면 |
|---|---|---|
| GET | `/api/approval` | 01 Approval Review (대기열 + 스테이지/리스크 집계) |
| GET | `/api/claim-lt` | 02 Claim L/T Analysis (KPI·트렌드·제품/단계/고객) |
| GET | `/api/overdue`  | 03 Overdue Conditions (요약 카드·aging 버킷·사업부 테이블) |
| GET | `/api/budget`   | 04 Target Plan Budget (예산 테이블·Condition List) |

Swagger 문서: `http://localhost:8000/docs`

## 프론트엔드 배포 (Tomcat)

1. `*.jsp` 5개 → 웹앱 루트(예: `webapp/`)
2. `common/`, `static/` 폴더 → `webapp/common/`, `webapp/static/`
3. API 주소는 기본 `http://localhost:8000`이며, JVM 옵션으로 변경 가능:
   ```
   -Dapi.base=https://api.example.com
   ```
   (운영에서는 web.xml context-param이나 프로퍼티 파일 주입으로 바꾸는 것을 권장)

접속: `http://localhost:8080/<context>/` (index.jsp가 approval.jsp로 리다이렉트)


## 프론트만 빠르게 확인하기 (백엔드·Tomcat 불필요)

`frontend/preview/` 폴더의 HTML 4장을 브라우저에서 바로 열면 됩니다
(`preview/approval.html` 부터). `mock-api.js`가 실제 백엔드 응답을 그대로 담고 있어
`window.fetch`를 가로채 mock으로 응답하며, 운영 코드(`common.js`, 페이지별 JS, CSS)는
수정 없이 그대로 사용하므로 실제 렌더링 결과와 동일합니다.

- preview는 확인용입니다. 운영 배포에는 `frontend/*.jsp`를 사용하세요.
- 백엔드 스키마가 바뀌면 mock을 다시 뜨면 됩니다:
  각 엔드포인트 응답을 `mock-api.js`의 MOCK 객체에 교체.

## CORS

JSP(Tomcat)와 API(uvicorn)의 포트가 다르므로 백엔드에 CORS가 열려 있습니다
(`main.py`의 `allow_origins=["*"]`). **운영 배포 시 실제 프론트 도메인으로 좁혀 주세요.**
같은 도메인 뒤에 리버스 프록시(`/api` → uvicorn)로 묶으면 CORS 설정 자체가 불필요해집니다.

## DB 연동으로 교체할 때

`data.py`의 상수들만 DB 조회 함수로 바꾸면 됩니다. API 응답 스키마는 그대로 유지되므로
프론트엔드는 수정할 필요가 없습니다. 필터(Company/BusArea/Product, 월 선택)는 현재
와이어프레임처럼 장식용인데, 실제 연동 시 각 엔드포인트에 쿼리 파라미터
(`?period=2026-06&company=...`)를 추가하고 `dashboard.js`의 fetch URL에 붙이면 됩니다.

## 구현된 인터랙션

- 상단 네비로 4개 페이지 이동, 현재 페이지 활성 표시 + 전 페이지 Approval 뱃지
- Approval Review: `All / Risk only / Clean only` 필터, "View risk items" 버튼 동작
- API 연결 실패 시 에러 배너 + 다시 시도 버튼
