"""
데이터 계층 (Mock DB)
=====================
와이어프레임에 하드코딩되어 있던 데이터를 그대로 옮겨둔 파일입니다.
실제 연동 시 이 파일의 함수들만 DB 조회(SQLAlchemy, pyodbc 등)로
교체하면 API 계층(main.py)은 수정 없이 그대로 사용할 수 있습니다.
"""

# ---------------------------------------------------------------
# 01. Approval Review — 승인 대기 항목
# ---------------------------------------------------------------
APPROVAL_ROWS = [
    {"id": "A2S910E26540159", "stage": "CLAIM",  "risks": [],                                      "checkedAt": "06-26 16:34"},
    {"id": "A2S7B0C26610620", "stage": "CHANGE", "risks": ["Budget exceeded"],                     "checkedAt": "06-26 16:06"},
    {"id": "A2S330D26987267", "stage": "CREATE", "risks": [],                                      "checkedAt": "06-25 15:50"},
    {"id": "A2S330D26784516", "stage": "CLAIM",  "risks": ["Post-approval", "Budget exceeded"],    "checkedAt": "06-25 08:19"},
    {"id": "A2S560A26699512", "stage": "CREATE", "risks": ["Deal Sheet Exception"],                "checkedAt": "06-24 16:38"},
    {"id": "A2S7B0C26436239", "stage": "CLAIM",  "risks": [],                                      "checkedAt": "06-24 11:20"},
    {"id": "A2S910E26512044", "stage": "CHANGE", "risks": ["Post-approval"],                       "checkedAt": "06-23 09:12"},
    {"id": "A2S330D26689026", "stage": "CREATE", "risks": [],                                      "checkedAt": "06-23 08:40"},
    {"id": "A2S560A26771330", "stage": "CLAIM",  "risks": ["Budget exceeded"],                     "checkedAt": "06-22 17:05"},
]

# ---------------------------------------------------------------
# 02. Claim L/T Analysis
# ---------------------------------------------------------------
CLAIM_AI_INSIGHT = (
    "For the Jun 2026 settlement, the average Claim L/T is 122.4 days — a 0.6-day "
    "improvement over the prior month (123.0 days). Exertis Ireland Estore (799.0 days) "
    "and the Mobile division (193.8 days) far exceed the company average and should be "
    "reviewed first. About 68% of total delay occurs in the Customer Delay "
    "(Promo End ~ I/V) segment."
)

CLAIM_TREND = [
    {"month": "'25.07", "claims": 2734, "avgDays": 101.0},
    {"month": "'25.08", "claims": 2856, "avgDays": 94.0},
    {"month": "'25.09", "claims": 2790, "avgDays": 94.3},
    {"month": "'25.10", "claims": 2529, "avgDays": 134.3},
    {"month": "'25.11", "claims": 2648, "avgDays": 89.6},
    {"month": "'25.12", "claims": 3068, "avgDays": 106.9},
    {"month": "'26.01", "claims": 3141, "avgDays": 97.0},
    {"month": "'26.02", "claims": 2527, "avgDays": 91.2},
    {"month": "'26.03", "claims": 3321, "avgDays": 109.3},
    {"month": "'26.04", "claims": 2031, "avgDays": 105.9},
    {"month": "'26.05", "claims": 2372, "avgDays": 123.0},
    {"month": "'26.06", "claims": 3329, "avgDays": 122.4},
]

CLAIM_BY_PRODUCT = [
    {"name": "Mobile",      "avgDays": 194.9},
    {"name": "Computer",    "avgDays": 185.9},
    {"name": "Memory",      "avgDays": 164.1},
    {"name": "Brown Goods", "avgDays": 127.2},
    {"name": "White Goods", "avgDays": 106.8},
    {"name": "CTV",         "avgDays": 93.0},
]

CLAIM_STEPS = [
    {"name": "1. Promo End ~ I/V Issue",             "days": 72.7,  "kind": "step"},
    {"name": "2. I/V Issue ~ I/V Receipt",           "days": 4.4,   "kind": "step"},
    {"name": "Customer Delay",                       "days": 77.1,  "kind": "subtotal"},
    {"name": "3. I/V Receipt ~ Claim Creation",      "days": 18.9,  "kind": "step"},
    {"name": "4. Claim Creation ~ End of Approval",  "days": 26.4,  "kind": "step"},
    {"name": "Samsung Delay",                        "days": 45.2,  "kind": "subtotal"},
    {"name": "Sum",                                  "days": 122.4, "kind": "total"},
]

# s1~s4: 각 단계별 소요일. customerDelay/samsungDelay는 API에서 계산.
CLAIM_CUSTOMERS = [
    {"name": "2430031 Exertis Ireland Estore",           "claims": 140, "ltAvg": 799.0, "s1": 771.3, "s2": 2.5,  "s3": 5.6,  "s4": 19.6},
    {"name": "2015695 Shop Direct Home Shopping",        "claims": 128, "ltAvg": 186.6, "s1": 115.8, "s2": 2.3,  "s3": 10.9, "s4": 57.6},
    {"name": "4244888 TD Synnex UK Limited",             "claims": 92,  "ltAvg": 180.5, "s1": 130.4, "s2": 2.5,  "s3": 8.9,  "s4": 38.7},
    {"name": "4531120 Partner Retail Services Ltd",      "claims": 67,  "ltAvg": 166.3, "s1": 67.2,  "s2": 5.6,  "s3": 40.0, "s4": 53.5},
    {"name": "4522186 Westcoast / Very",                 "claims": 54,  "ltAvg": 158.1, "s1": 100.3, "s2": 5.4,  "s3": 8.9,  "s4": 43.5},
    {"name": "2062094 Exertis (UK) Ltd",                 "claims": 46,  "ltAvg": 148.7, "s1": 90.5,  "s2": 4.5,  "s3": 12.9, "s4": 40.8},
    {"name": "9037215 Combined Independent (Holdings)",  "claims": 41,  "ltAvg": 148.3, "s1": 55.4,  "s2": 4.5,  "s3": 51.7, "s4": 36.7},
    {"name": "2015540 Sky UK Ltd",                       "claims": 27,  "ltAvg": 145.6, "s1": 108.4, "s2": 5.0,  "s3": 12.0, "s4": 20.2},
    {"name": "2430099 Exertis / Very",                   "claims": 23,  "ltAvg": 140.2, "s1": 90.3,  "s2": 5.2,  "s3": 6.5,  "s4": 38.2},
    {"name": "2015472 Tesco Stores Limited",             "claims": 21,  "ltAvg": 139.8, "s1": 108.7, "s2": 10.7, "s3": 6.8,  "s4": 13.6},
    {"name": "6031882 SEUK eStore - Hybris",             "claims": 18,  "ltAvg": 137.4, "s1": 94.4,  "s2": 4.5,  "s3": 8.5,  "s4": 30.0},
    {"name": "2258190 Currys Retail Limited",            "claims": 10,  "ltAvg": 133.0, "s1": 43.7,  "s2": 4.5,  "s3": 4.5,  "s4": 80.3},
]

# ---------------------------------------------------------------
# 03. Overdue Conditions
# 컬럼 순서: [OverdueAmt, 1-15, 16-31, Over31, 32-60, 61-90,
#             Over90, 91-180, Over180, 181-365, 1-2y, 2y+]
# None = 값 없음(—)
# ---------------------------------------------------------------
OVERDUE_COLUMNS = [
    "overdueAmt", "d1_15", "d16_31", "over31", "d32_60", "d61_90",
    "over90", "d91_180", "over180", "d181_365", "y1_2", "y2_plus",
]

OVERDUE_DIVISIONS = [
    {"name": "CTV",     "currency": "RUR", "cells": [6101625, 885630, 1343961, 4066037, 750025, 2646120, 1350249, 580750, 277435, 247743, None, None]},
    {"name": "HA",      "currency": "RUR", "cells": [836137, 21359, 14346, 798076, 58484, 21526, 716666, 33897, 662769, 556482, 126288, None]},
    {"name": "Monitor", "currency": "RUR", "cells": [770152, 320830, 2213, 662150, 533183, 86726, 472240, 75894, 576368, 372621, 3745, None]},
    {"name": "REF",     "currency": "RUR", "cells": [1497032, 554777, 72746, 1269510, 196940, 188357, 604573, 249686, 634487, 558687, 71744, 4055]},
    {"name": "WM",      "currency": "RUR", "cells": [1580762, 138515, 48226, 1393940, 354900, 238800, 554785, 406242, 454662, 404047, 54668, 4055]},
    {"name": "VC",      "currency": "RUR", "cells": [6401, None, 5271, 577286, 64232, 96222, 547760, 75101, 50442, 44047, 3444, 4055]},
    {"name": "NIWD",    "currency": "RUR", "cells": [682297, 574, 685421, 551102, 19140, 15000, 406242, 164635, 319533, 318600, None, None]},
    {"name": "Mobile",  "currency": "RUR", "cells": [33142675, 3522635, 1866257, 27753746, 4034552, 3151140, 20367696, 7846767, 12521529, 11548556, 960464, 52505]},
    {"name": "Memory",  "currency": "RUR", "cells": [260082, 27968, None, 232114, 27674, 8511, 195929, 12435, 183095, None, None, None]},
]

# aging 버킷 차트에 쓰는 (라벨, cells 인덱스) 매핑
OVERDUE_BUCKETS = [
    ("1–15", 1), ("16–31", 2), ("32–60", 4), ("61–90", 5),
    ("91–180", 7), ("181–365", 9), ("1–2y", 10), ("2y+", 11),
]

# 와이어프레임 상단 요약 카드 / 도넛 (원본 수치 그대로)
OVERDUE_SUMMARY = {
    "totalOverdue": 45474310,
    "over31": 37236803,
    "over90": 26675788,
    "over180": 17332845,
}

# ---------------------------------------------------------------
# 04. Target Plan Budget
# ---------------------------------------------------------------
BUDGET_KPI = {
    "month":   {"label": "26.02", "pct": 18.2, "qty": "10.7M", "yoy": "+0.8%p", "delta": "−1.6M"},
    "quarter": {"label": "26.1Q", "pct": 18.2, "qty": "10.7M", "yoy": "+0.8%p", "delta": "−1.6M"},
}

# Rebate 레벨만 값이 있고 SA/PP/Coop은 0 (와이어프레임과 동일)
BUDGET_DIVISIONS = [
    {"div": "Total",       "targetPlan": 11070000, "approved": 1542235, "inProc": 26000, "paid": 0},
    {"div": "TV (A1)",     "targetPlan": 5000000,  "approved": 691856,  "inProc": 2540,  "paid": 0},
    {"div": "Mobile (G1)", "targetPlan": 6000000,  "approved": 537284,  "inProc": 22280, "paid": 0},
    {"div": "ES",          "targetPlan": 70000,    "approved": 313095,  "inProc": 1380,  "paid": 0},
]

BUDGET_CHECK_LEVELS = ["Rebate", "SA", "PP", "Coop"]

CONDITION_GROUPS = [
    {
        "name": "Direct Price Discount",
        "items": [
            {"doc": "A05430A240035241", "title": "NPC Q1'25 Amazon. Chromebook Plus Save. 01.01.25 – 14.01.25",                          "qty": 16,   "amount": 1800},
            {"doc": "A05430A240035243", "title": "NPC Q1'25 Amazon. Chromebook Plus Save 1. 12.02.25 – 25.02.25",                        "qty": 24,   "amount": 2700},
            {"doc": "A05430A240035250", "title": "NPC Q1'25 Amazon. Save. 01.01.25 – 14.01.25",                                          "qty": 0,    "amount": 0},
            {"doc": "A05430A250004726", "title": "NPC Q1'25 Amazon. Save 4. 12.02.25 – 11.03.25",                                        "qty": 4,    "amount": 600},
            {"doc": "A05430A250006883", "title": "NPC Q1'25 Amazon. Save. 19.03.25 – 08.04.25",                                          "qty": 49,   "amount": 7350},
            {"doc": "A05430A250007666", "title": "NPC Q2'25 Amazon. WK 14 SOA SAVE. 01.04.25 – 09.04.25",                                "qty": 23,   "amount": 3075},
            {"doc": "A05430A250010756", "title": "Amazon MEM WIGIG 980 PRO Heatsink April 2025 EUR",                                     "qty": 50,   "amount": 848},
            {"doc": "A05430A250011139", "title": "Amazon Early May Promo 2025",                                                          "qty": 3690, "amount": 43182},
            {"doc": "A05430A250011141", "title": "Amazon Late May Promo 2025",                                                           "qty": 5165, "amount": 58466},
            {"doc": "A05430A250013497", "title": "Amazon Always on May–June 2025",                                                       "qty": 2745, "amount": 25024},
            {"doc": "A05430A250014093", "title": "Amazon MEM WIGIG 980 PRO Heatsink May to June 2025 EUR",                               "qty": 661,  "amount": 11211},
            {"doc": "A05430A250014331", "title": "NPC Q2'25 Amazon. WK 21 SOA SAVE. 20.05.25 – 11.06.25",                                "qty": 89,   "amount": 12075},
            {"doc": "A05430A250014334", "title": "NPC Q2'25 Amazon. Special Invoice Price SOA – NP730QFG-KA1UK. 14.05.25 – 31.10.25",    "qty": 380,  "amount": 23518},
            {"doc": "A05430A250014993", "title": "NPC Q2'25 Amazon. Prime Day & Back to School. 05.05.25 – 30.11.25",                    "qty": 120,  "amount": 28975},
            {"doc": "A05430A250015144", "title": "Amazon Summer Sale 2025",                                                              "qty": 1713, "amount": 18101},
            {"doc": "A05430A250015151", "title": "Amazon Always on June–July 2025",                                                      "qty": 1855, "amount": 21557},
        ],
    },
    {
        "name": "LSV Program",
        "items": [
            {"doc": "R05430A240002682", "title": "NPC Q1'25 Amazon. LSV. 22.01.25 – 18.02.25", "qty": 47, "amount": 6450},
        ],
    },
    {
        "name": "Multi-buy Offer",
        "items": [
            {"doc": "A05430A240035317", "title": "NPC Q1'25 Amazon. Voucher. 22.01.25 – 18.02.25", "qty": 49, "amount": 4500},
        ],
    },
]
