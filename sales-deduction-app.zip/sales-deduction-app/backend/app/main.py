"""
Sales-Deduction AI Agent — Backend API (FastAPI)
================================================
실행:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

엔드포인트:
    GET /api/approval   01. Approval Review (대기열 + 스테이지/리스크 집계)
    GET /api/claim-lt   02. Claim L/T Analysis
    GET /api/overdue    03. Overdue Conditions (요약/버킷 집계 포함)
    GET /api/budget     04. Target Plan Budget + Condition List

원칙: 백엔드는 "숫자와 구조"만 내려주고, 색상·막대 높이·포맷팅 같은
표현 로직은 전부 프론트엔드(dashboard.js)가 담당한다.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import data

app = FastAPI(title="Sales-Deduction AI Agent API", version="0.1.0")

# JSP(Tomcat) 오리진에서 fetch 할 수 있도록 CORS 허용.
# 운영 배포 시 allow_origins를 실제 도메인으로 좁혀주세요.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

STAGE_ORDER = ["CREATE", "CHANGE", "CLAIM"]


@app.get("/api/health")
def health():
    return {"status": "ok"}


# ---------------------------------------------------------------
# 01. Approval Review
# ---------------------------------------------------------------
@app.get("/api/approval")
def get_approval():
    rows = data.APPROVAL_ROWS

    # 스테이지별 total / risk 집계 (와이어프레임에선 하드코딩이었던 부분)
    by_stage = {s: {"stage": s, "total": 0, "risk": 0} for s in STAGE_ORDER}
    for r in rows:
        st = by_stage[r["stage"]]
        st["total"] += 1
        if r["risks"]:
            st["risk"] += 1

    # 리스크 유형별 × 스테이지별 건수 집계
    risk_types: dict = {}
    for r in rows:
        for risk in r["risks"]:
            rt = risk_types.setdefault(risk, {"name": risk, "byStage": {}, "total": 0})
            rt["byStage"][r["stage"]] = rt["byStage"].get(r["stage"], 0) + 1
            rt["total"] += 1

    risk_count = sum(1 for r in rows if r["risks"])

    return {
        "period": "2026-06",
        "pendingCount": len(rows),
        "riskCount": risk_count,
        "pendingByStage": [by_stage[s] for s in STAGE_ORDER],
        "riskByType": sorted(risk_types.values(), key=lambda t: -t["total"]),
        "rows": rows,
    }


# ---------------------------------------------------------------
# 02. Claim L/T Analysis
# ---------------------------------------------------------------
@app.get("/api/claim-lt")
def get_claim_lt():
    latest = data.CLAIM_TREND[-1]

    customers = [
        {
            **c,
            "customerDelay": round(c["s1"] + c["s2"], 1),
            "samsungDelay": round(c["s3"] + c["s4"], 1),
        }
        for c in data.CLAIM_CUSTOMERS
    ]

    return {
        "period": "2026-06",
        "kpi": {"ltAvgDays": latest["avgDays"], "claims": latest["claims"]},
        "companyAvg": latest["avgDays"],
        "aiInsight": data.CLAIM_AI_INSIGHT,
        "trend": data.CLAIM_TREND,
        "byProduct": data.CLAIM_BY_PRODUCT,
        "steps": data.CLAIM_STEPS,
        "customers": customers,
    }


# ---------------------------------------------------------------
# 03. Overdue Conditions
# ---------------------------------------------------------------
@app.get("/api/overdue")
def get_overdue():
    divisions = [
        {
            "name": d["name"],
            "currency": d["currency"],
            # cells 배열 → 컬럼명 딕셔너리로 변환
            "values": dict(zip(data.OVERDUE_COLUMNS, d["cells"])),
        }
        for d in data.OVERDUE_DIVISIONS
    ]

    # aging 버킷 차트: Mobile / CTV / Others로 스택 집계
    buckets = []
    for label, idx in data.OVERDUE_BUCKETS:
        mobile = ctv = others = 0
        for d in data.OVERDUE_DIVISIONS:
            v = d["cells"][idx] or 0
            if d["name"] == "Mobile":
                mobile += v
            elif d["name"] == "CTV":
                ctv += v
            else:
                others += v
        buckets.append({
            "label": label,
            "mobile": mobile,
            "ctv": ctv,
            "others": others,
            "total": mobile + ctv + others,
        })

    s = data.OVERDUE_SUMMARY
    total = s["totalOverdue"]
    pct = lambda v: round(v / total * 100)  # noqa: E731

    return {
        "summary": {
            "totalOverdue": total,
            "over31": {"amount": s["over31"], "pctOfTotal": pct(s["over31"])},
            "over90": {"amount": s["over90"], "pctOfTotal": pct(s["over90"])},
            "over180": {"amount": s["over180"], "pctOfTotal": pct(s["over180"])},
        },
        "agingBuckets": buckets,
        "columns": data.OVERDUE_COLUMNS,
        "divisions": divisions,
    }


# ---------------------------------------------------------------
# 04. Target Plan Budget
# ---------------------------------------------------------------
@app.get("/api/budget")
def get_budget():
    def build_rows(g):
        rows = []
        for level in data.BUDGET_CHECK_LEVELS:
            if level == "Rebate":
                tp, ap, ip_, pd_ = g["targetPlan"], g["approved"], g["inProc"], g["paid"]
            else:
                tp = ap = ip_ = pd_ = 0
            total = ap + ip_ + pd_
            pct = round(total / tp * 100, 1) if tp else 0.0
            period = {
                "targetPlan": tp, "approved": ap, "inProc": ip_,
                "paid": pd_, "total": total, "pct": pct,
            }
            rows.append({
                "div": g["div"],
                "checkLevel": level,
                # 와이어프레임처럼 월/분기 동일 값. 실제 DB 연동 시 분리.
                "month": period,
                "quarter": dict(period),
                "overBudget": level == "Rebate" and tp and total > tp,
            })
        return rows

    budget_rows = [row for g in data.BUDGET_DIVISIONS for row in build_rows(g)]

    groups = []
    grand_qty = grand_amt = 0
    for g in data.CONDITION_GROUPS:
        tq = sum(i["qty"] for i in g["items"])
        ta = sum(i["amount"] for i in g["items"])
        grand_qty += tq
        grand_amt += ta
        groups.append({
            "name": g["name"],
            "items": g["items"],
            "totalQty": tq,
            "totalAmount": ta,
        })

    return {
        "kpi": data.BUDGET_KPI,
        "budgetRows": budget_rows,
        "conditionGroups": groups,
        "conditionGrandTotal": {"qty": grand_qty, "amount": grand_amt},
    }
