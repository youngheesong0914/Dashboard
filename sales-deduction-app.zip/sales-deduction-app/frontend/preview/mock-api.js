/* preview 전용 mock API
 * 실제 백엔드(/api/*) 응답을 그대로 담아두고 window.fetch를 가로챈다.
 * 백엔드·Tomcat 없이 브라우저에서 파일만 열어 프론트 렌더링을 확인하는 용도.
 * 운영 코드(common.js, 페이지 JS)는 전혀 수정하지 않는다. */
(function () {
  'use strict';
  var MOCK = {
  "/api/approval": {
    "period": "2026-06",
    "pendingCount": 9,
    "riskCount": 5,
    "pendingByStage": [
      {
        "stage": "CREATE",
        "total": 3,
        "risk": 1
      },
      {
        "stage": "CHANGE",
        "total": 2,
        "risk": 2
      },
      {
        "stage": "CLAIM",
        "total": 4,
        "risk": 2
      }
    ],
    "riskByType": [
      {
        "name": "Budget exceeded",
        "byStage": {
          "CHANGE": 1,
          "CLAIM": 2
        },
        "total": 3
      },
      {
        "name": "Post-approval",
        "byStage": {
          "CLAIM": 1,
          "CHANGE": 1
        },
        "total": 2
      },
      {
        "name": "Deal Sheet Exception",
        "byStage": {
          "CREATE": 1
        },
        "total": 1
      }
    ],
    "rows": [
      {
        "id": "A2S910E26540159",
        "stage": "CLAIM",
        "risks": [],
        "checkedAt": "06-26 16:34"
      },
      {
        "id": "A2S7B0C26610620",
        "stage": "CHANGE",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-26 16:06"
      },
      {
        "id": "A2S330D26987267",
        "stage": "CREATE",
        "risks": [],
        "checkedAt": "06-25 15:50"
      },
      {
        "id": "A2S330D26784516",
        "stage": "CLAIM",
        "risks": [
          "Post-approval",
          "Budget exceeded"
        ],
        "checkedAt": "06-25 08:19"
      },
      {
        "id": "A2S560A26699512",
        "stage": "CREATE",
        "risks": [
          "Deal Sheet Exception"
        ],
        "checkedAt": "06-24 16:38"
      },
      {
        "id": "A2S7B0C26436239",
        "stage": "CLAIM",
        "risks": [],
        "checkedAt": "06-24 11:20"
      },
      {
        "id": "A2S910E26512044",
        "stage": "CHANGE",
        "risks": [
          "Post-approval"
        ],
        "checkedAt": "06-23 09:12"
      },
      {
        "id": "A2S330D26689026",
        "stage": "CREATE",
        "risks": [],
        "checkedAt": "06-23 08:40"
      },
      {
        "id": "A2S560A26771330",
        "stage": "CLAIM",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-22 17:05"
      }
    ]
  },
  "/api/claim-lt": {
    "period": "2026-06",
    "kpi": {
      "ltAvgDays": 122.4,
      "claims": 3329
    },
    "companyAvg": 122.4,
    "aiInsight": "For the Jun 2026 settlement, the average Claim L/T is 122.4 days — a 0.6-day improvement over the prior month (123.0 days). Exertis Ireland Estore (799.0 days) and the Mobile division (193.8 days) far exceed the company average and should be reviewed first. About 68% of total delay occurs in the Customer Delay (Promo End ~ I/V) segment.",
    "trend": [
      {
        "month": "'25.07",
        "claims": 2734,
        "avgDays": 101.0
      },
      {
        "month": "'25.08",
        "claims": 2856,
        "avgDays": 94.0
      },
      {
        "month": "'25.09",
        "claims": 2790,
        "avgDays": 94.3
      },
      {
        "month": "'25.10",
        "claims": 2529,
        "avgDays": 134.3
      },
      {
        "month": "'25.11",
        "claims": 2648,
        "avgDays": 89.6
      },
      {
        "month": "'25.12",
        "claims": 3068,
        "avgDays": 106.9
      },
      {
        "month": "'26.01",
        "claims": 3141,
        "avgDays": 97.0
      },
      {
        "month": "'26.02",
        "claims": 2527,
        "avgDays": 91.2
      },
      {
        "month": "'26.03",
        "claims": 3321,
        "avgDays": 109.3
      },
      {
        "month": "'26.04",
        "claims": 2031,
        "avgDays": 105.9
      },
      {
        "month": "'26.05",
        "claims": 2372,
        "avgDays": 123.0
      },
      {
        "month": "'26.06",
        "claims": 3329,
        "avgDays": 122.4
      }
    ],
    "byProduct": [
      {
        "name": "Mobile",
        "avgDays": 194.9
      },
      {
        "name": "Computer",
        "avgDays": 185.9
      },
      {
        "name": "Memory",
        "avgDays": 164.1
      },
      {
        "name": "Brown Goods",
        "avgDays": 127.2
      },
      {
        "name": "White Goods",
        "avgDays": 106.8
      },
      {
        "name": "CTV",
        "avgDays": 93.0
      }
    ],
    "steps": [
      {
        "name": "1. Promo End ~ I/V Issue",
        "days": 72.7,
        "kind": "step"
      },
      {
        "name": "2. I/V Issue ~ I/V Receipt",
        "days": 4.4,
        "kind": "step"
      },
      {
        "name": "Customer Delay",
        "days": 77.1,
        "kind": "subtotal"
      },
      {
        "name": "3. I/V Receipt ~ Claim Creation",
        "days": 18.9,
        "kind": "step"
      },
      {
        "name": "4. Claim Creation ~ End of Approval",
        "days": 26.4,
        "kind": "step"
      },
      {
        "name": "Samsung Delay",
        "days": 45.2,
        "kind": "subtotal"
      },
      {
        "name": "Sum",
        "days": 122.4,
        "kind": "total"
      }
    ],
    "customers": [
      {
        "name": "2430031 Exertis Ireland Estore",
        "claims": 140,
        "ltAvg": 799.0,
        "s1": 771.3,
        "s2": 2.5,
        "s3": 5.6,
        "s4": 19.6,
        "customerDelay": 773.8,
        "samsungDelay": 25.2
      },
      {
        "name": "2015695 Shop Direct Home Shopping",
        "claims": 128,
        "ltAvg": 186.6,
        "s1": 115.8,
        "s2": 2.3,
        "s3": 10.9,
        "s4": 57.6,
        "customerDelay": 118.1,
        "samsungDelay": 68.5
      },
      {
        "name": "4244888 TD Synnex UK Limited",
        "claims": 92,
        "ltAvg": 180.5,
        "s1": 130.4,
        "s2": 2.5,
        "s3": 8.9,
        "s4": 38.7,
        "customerDelay": 132.9,
        "samsungDelay": 47.6
      },
      {
        "name": "4531120 Partner Retail Services Ltd",
        "claims": 67,
        "ltAvg": 166.3,
        "s1": 67.2,
        "s2": 5.6,
        "s3": 40.0,
        "s4": 53.5,
        "customerDelay": 72.8,
        "samsungDelay": 93.5
      },
      {
        "name": "4522186 Westcoast / Very",
        "claims": 54,
        "ltAvg": 158.1,
        "s1": 100.3,
        "s2": 5.4,
        "s3": 8.9,
        "s4": 43.5,
        "customerDelay": 105.7,
        "samsungDelay": 52.4
      },
      {
        "name": "2062094 Exertis (UK) Ltd",
        "claims": 46,
        "ltAvg": 148.7,
        "s1": 90.5,
        "s2": 4.5,
        "s3": 12.9,
        "s4": 40.8,
        "customerDelay": 95.0,
        "samsungDelay": 53.7
      },
      {
        "name": "9037215 Combined Independent (Holdings)",
        "claims": 41,
        "ltAvg": 148.3,
        "s1": 55.4,
        "s2": 4.5,
        "s3": 51.7,
        "s4": 36.7,
        "customerDelay": 59.9,
        "samsungDelay": 88.4
      },
      {
        "name": "2015540 Sky UK Ltd",
        "claims": 27,
        "ltAvg": 145.6,
        "s1": 108.4,
        "s2": 5.0,
        "s3": 12.0,
        "s4": 20.2,
        "customerDelay": 113.4,
        "samsungDelay": 32.2
      },
      {
        "name": "2430099 Exertis / Very",
        "claims": 23,
        "ltAvg": 140.2,
        "s1": 90.3,
        "s2": 5.2,
        "s3": 6.5,
        "s4": 38.2,
        "customerDelay": 95.5,
        "samsungDelay": 44.7
      },
      {
        "name": "2015472 Tesco Stores Limited",
        "claims": 21,
        "ltAvg": 139.8,
        "s1": 108.7,
        "s2": 10.7,
        "s3": 6.8,
        "s4": 13.6,
        "customerDelay": 119.4,
        "samsungDelay": 20.4
      },
      {
        "name": "6031882 SEUK eStore - Hybris",
        "claims": 18,
        "ltAvg": 137.4,
        "s1": 94.4,
        "s2": 4.5,
        "s3": 8.5,
        "s4": 30.0,
        "customerDelay": 98.9,
        "samsungDelay": 38.5
      },
      {
        "name": "2258190 Currys Retail Limited",
        "claims": 10,
        "ltAvg": 133.0,
        "s1": 43.7,
        "s2": 4.5,
        "s3": 4.5,
        "s4": 80.3,
        "customerDelay": 48.2,
        "samsungDelay": 84.8
      }
    ]
  },
  "/api/overdue": {
    "summary": {
      "totalOverdue": 45474310,
      "over31": {
        "amount": 37236803,
        "pctOfTotal": 82
      },
      "over90": {
        "amount": 26675788,
        "pctOfTotal": 59
      },
      "over180": {
        "amount": 17332845,
        "pctOfTotal": 38
      }
    },
    "agingBuckets": [
      {
        "label": "1–15",
        "mobile": 3522635,
        "ctv": 885630,
        "others": 1064023,
        "total": 5472288
      },
      {
        "label": "16–31",
        "mobile": 1866257,
        "ctv": 1343961,
        "others": 828223,
        "total": 4038441
      },
      {
        "label": "32–60",
        "mobile": 4034552,
        "ctv": 750025,
        "others": 1254553,
        "total": 6039130
      },
      {
        "label": "61–90",
        "mobile": 3151140,
        "ctv": 2646120,
        "others": 655142,
        "total": 6452402
      },
      {
        "label": "91–180",
        "mobile": 7846767,
        "ctv": 580750,
        "others": 1017890,
        "total": 9445407
      },
      {
        "label": "181–365",
        "mobile": 11548556,
        "ctv": 247743,
        "others": 2254484,
        "total": 14050783
      },
      {
        "label": "1–2y",
        "mobile": 960464,
        "ctv": 0,
        "others": 259889,
        "total": 1220353
      },
      {
        "label": "2y+",
        "mobile": 52505,
        "ctv": 0,
        "others": 12165,
        "total": 64670
      }
    ],
    "columns": [
      "overdueAmt",
      "d1_15",
      "d16_31",
      "over31",
      "d32_60",
      "d61_90",
      "over90",
      "d91_180",
      "over180",
      "d181_365",
      "y1_2",
      "y2_plus"
    ],
    "divisions": [
      {
        "name": "CTV",
        "currency": "RUR",
        "values": {
          "overdueAmt": 6101625,
          "d1_15": 885630,
          "d16_31": 1343961,
          "over31": 4066037,
          "d32_60": 750025,
          "d61_90": 2646120,
          "over90": 1350249,
          "d91_180": 580750,
          "over180": 277435,
          "d181_365": 247743,
          "y1_2": null,
          "y2_plus": null
        }
      },
      {
        "name": "HA",
        "currency": "RUR",
        "values": {
          "overdueAmt": 836137,
          "d1_15": 21359,
          "d16_31": 14346,
          "over31": 798076,
          "d32_60": 58484,
          "d61_90": 21526,
          "over90": 716666,
          "d91_180": 33897,
          "over180": 662769,
          "d181_365": 556482,
          "y1_2": 126288,
          "y2_plus": null
        }
      },
      {
        "name": "Monitor",
        "currency": "RUR",
        "values": {
          "overdueAmt": 770152,
          "d1_15": 320830,
          "d16_31": 2213,
          "over31": 662150,
          "d32_60": 533183,
          "d61_90": 86726,
          "over90": 472240,
          "d91_180": 75894,
          "over180": 576368,
          "d181_365": 372621,
          "y1_2": 3745,
          "y2_plus": null
        }
      },
      {
        "name": "REF",
        "currency": "RUR",
        "values": {
          "overdueAmt": 1497032,
          "d1_15": 554777,
          "d16_31": 72746,
          "over31": 1269510,
          "d32_60": 196940,
          "d61_90": 188357,
          "over90": 604573,
          "d91_180": 249686,
          "over180": 634487,
          "d181_365": 558687,
          "y1_2": 71744,
          "y2_plus": 4055
        }
      },
      {
        "name": "WM",
        "currency": "RUR",
        "values": {
          "overdueAmt": 1580762,
          "d1_15": 138515,
          "d16_31": 48226,
          "over31": 1393940,
          "d32_60": 354900,
          "d61_90": 238800,
          "over90": 554785,
          "d91_180": 406242,
          "over180": 454662,
          "d181_365": 404047,
          "y1_2": 54668,
          "y2_plus": 4055
        }
      },
      {
        "name": "VC",
        "currency": "RUR",
        "values": {
          "overdueAmt": 6401,
          "d1_15": null,
          "d16_31": 5271,
          "over31": 577286,
          "d32_60": 64232,
          "d61_90": 96222,
          "over90": 547760,
          "d91_180": 75101,
          "over180": 50442,
          "d181_365": 44047,
          "y1_2": 3444,
          "y2_plus": 4055
        }
      },
      {
        "name": "NIWD",
        "currency": "RUR",
        "values": {
          "overdueAmt": 682297,
          "d1_15": 574,
          "d16_31": 685421,
          "over31": 551102,
          "d32_60": 19140,
          "d61_90": 15000,
          "over90": 406242,
          "d91_180": 164635,
          "over180": 319533,
          "d181_365": 318600,
          "y1_2": null,
          "y2_plus": null
        }
      },
      {
        "name": "Mobile",
        "currency": "RUR",
        "values": {
          "overdueAmt": 33142675,
          "d1_15": 3522635,
          "d16_31": 1866257,
          "over31": 27753746,
          "d32_60": 4034552,
          "d61_90": 3151140,
          "over90": 20367696,
          "d91_180": 7846767,
          "over180": 12521529,
          "d181_365": 11548556,
          "y1_2": 960464,
          "y2_plus": 52505
        }
      },
      {
        "name": "Memory",
        "currency": "RUR",
        "values": {
          "overdueAmt": 260082,
          "d1_15": 27968,
          "d16_31": null,
          "over31": 232114,
          "d32_60": 27674,
          "d61_90": 8511,
          "over90": 195929,
          "d91_180": 12435,
          "over180": 183095,
          "d181_365": null,
          "y1_2": null,
          "y2_plus": null
        }
      }
    ]
  },
  "/api/budget": {
    "kpi": {
      "month": {
        "label": "26.02",
        "pct": 18.2,
        "qty": "10.7M",
        "yoy": "+0.8%p",
        "delta": "−1.6M"
      },
      "quarter": {
        "label": "26.1Q",
        "pct": 18.2,
        "qty": "10.7M",
        "yoy": "+0.8%p",
        "delta": "−1.6M"
      }
    },
    "budgetRows": [
      {
        "div": "Total",
        "checkLevel": "Rebate",
        "month": {
          "targetPlan": 11070000,
          "approved": 1542235,
          "inProc": 26000,
          "paid": 0,
          "total": 1568235,
          "pct": 14.2
        },
        "quarter": {
          "targetPlan": 11070000,
          "approved": 1542235,
          "inProc": 26000,
          "paid": 0,
          "total": 1568235,
          "pct": 14.2
        },
        "overBudget": false
      },
      {
        "div": "Total",
        "checkLevel": "SA",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "Total",
        "checkLevel": "PP",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "Total",
        "checkLevel": "Coop",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "TV (A1)",
        "checkLevel": "Rebate",
        "month": {
          "targetPlan": 5000000,
          "approved": 691856,
          "inProc": 2540,
          "paid": 0,
          "total": 694396,
          "pct": 13.9
        },
        "quarter": {
          "targetPlan": 5000000,
          "approved": 691856,
          "inProc": 2540,
          "paid": 0,
          "total": 694396,
          "pct": 13.9
        },
        "overBudget": false
      },
      {
        "div": "TV (A1)",
        "checkLevel": "SA",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "TV (A1)",
        "checkLevel": "PP",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "TV (A1)",
        "checkLevel": "Coop",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "Mobile (G1)",
        "checkLevel": "Rebate",
        "month": {
          "targetPlan": 6000000,
          "approved": 537284,
          "inProc": 22280,
          "paid": 0,
          "total": 559564,
          "pct": 9.3
        },
        "quarter": {
          "targetPlan": 6000000,
          "approved": 537284,
          "inProc": 22280,
          "paid": 0,
          "total": 559564,
          "pct": 9.3
        },
        "overBudget": false
      },
      {
        "div": "Mobile (G1)",
        "checkLevel": "SA",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "Mobile (G1)",
        "checkLevel": "PP",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "Mobile (G1)",
        "checkLevel": "Coop",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "ES",
        "checkLevel": "Rebate",
        "month": {
          "targetPlan": 70000,
          "approved": 313095,
          "inProc": 1380,
          "paid": 0,
          "total": 314475,
          "pct": 449.2
        },
        "quarter": {
          "targetPlan": 70000,
          "approved": 313095,
          "inProc": 1380,
          "paid": 0,
          "total": 314475,
          "pct": 449.2
        },
        "overBudget": true
      },
      {
        "div": "ES",
        "checkLevel": "SA",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "ES",
        "checkLevel": "PP",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      },
      {
        "div": "ES",
        "checkLevel": "Coop",
        "month": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "quarter": {
          "targetPlan": 0,
          "approved": 0,
          "inProc": 0,
          "paid": 0,
          "total": 0,
          "pct": 0.0
        },
        "overBudget": false
      }
    ],
    "conditionGroups": [
      {
        "name": "Direct Price Discount",
        "items": [
          {
            "doc": "A05430A240035241",
            "title": "NPC Q1'25 Amazon. Chromebook Plus Save. 01.01.25 – 14.01.25",
            "qty": 16,
            "amount": 1800
          },
          {
            "doc": "A05430A240035243",
            "title": "NPC Q1'25 Amazon. Chromebook Plus Save 1. 12.02.25 – 25.02.25",
            "qty": 24,
            "amount": 2700
          },
          {
            "doc": "A05430A240035250",
            "title": "NPC Q1'25 Amazon. Save. 01.01.25 – 14.01.25",
            "qty": 0,
            "amount": 0
          },
          {
            "doc": "A05430A250004726",
            "title": "NPC Q1'25 Amazon. Save 4. 12.02.25 – 11.03.25",
            "qty": 4,
            "amount": 600
          },
          {
            "doc": "A05430A250006883",
            "title": "NPC Q1'25 Amazon. Save. 19.03.25 – 08.04.25",
            "qty": 49,
            "amount": 7350
          },
          {
            "doc": "A05430A250007666",
            "title": "NPC Q2'25 Amazon. WK 14 SOA SAVE. 01.04.25 – 09.04.25",
            "qty": 23,
            "amount": 3075
          },
          {
            "doc": "A05430A250010756",
            "title": "Amazon MEM WIGIG 980 PRO Heatsink April 2025 EUR",
            "qty": 50,
            "amount": 848
          },
          {
            "doc": "A05430A250011139",
            "title": "Amazon Early May Promo 2025",
            "qty": 3690,
            "amount": 43182
          },
          {
            "doc": "A05430A250011141",
            "title": "Amazon Late May Promo 2025",
            "qty": 5165,
            "amount": 58466
          },
          {
            "doc": "A05430A250013497",
            "title": "Amazon Always on May–June 2025",
            "qty": 2745,
            "amount": 25024
          },
          {
            "doc": "A05430A250014093",
            "title": "Amazon MEM WIGIG 980 PRO Heatsink May to June 2025 EUR",
            "qty": 661,
            "amount": 11211
          },
          {
            "doc": "A05430A250014331",
            "title": "NPC Q2'25 Amazon. WK 21 SOA SAVE. 20.05.25 – 11.06.25",
            "qty": 89,
            "amount": 12075
          },
          {
            "doc": "A05430A250014334",
            "title": "NPC Q2'25 Amazon. Special Invoice Price SOA – NP730QFG-KA1UK. 14.05.25 – 31.10.25",
            "qty": 380,
            "amount": 23518
          },
          {
            "doc": "A05430A250014993",
            "title": "NPC Q2'25 Amazon. Prime Day & Back to School. 05.05.25 – 30.11.25",
            "qty": 120,
            "amount": 28975
          },
          {
            "doc": "A05430A250015144",
            "title": "Amazon Summer Sale 2025",
            "qty": 1713,
            "amount": 18101
          },
          {
            "doc": "A05430A250015151",
            "title": "Amazon Always on June–July 2025",
            "qty": 1855,
            "amount": 21557
          }
        ],
        "totalQty": 16584,
        "totalAmount": 258482
      },
      {
        "name": "LSV Program",
        "items": [
          {
            "doc": "R05430A240002682",
            "title": "NPC Q1'25 Amazon. LSV. 22.01.25 – 18.02.25",
            "qty": 47,
            "amount": 6450
          }
        ],
        "totalQty": 47,
        "totalAmount": 6450
      },
      {
        "name": "Multi-buy Offer",
        "items": [
          {
            "doc": "A05430A240035317",
            "title": "NPC Q1'25 Amazon. Voucher. 22.01.25 – 18.02.25",
            "qty": 49,
            "amount": 4500
          }
        ],
        "totalQty": 49,
        "totalAmount": 4500
      }
    ],
    "conditionGrandTotal": {
      "qty": 16680,
      "amount": 269432
    }
  }
};

  window.API_BASE = '';
  var realFetch = window.fetch ? window.fetch.bind(window) : null;

  window.fetch = function (url) {
    var path = String(url).replace(/^https?:\/\/[^\/]+/, '');
    if (MOCK[path]) {
      return Promise.resolve({
        ok: true,
        status: 200,
        json: function () {
          // 실제 통신처럼 약간의 지연을 준다 (로딩 배너 확인용)
          return new Promise(function (res) {
            setTimeout(function () { res(MOCK[path]); }, 300);
          });
        },
      });
    }
    return realFetch ? realFetch(url) : Promise.reject(new Error('no mock for ' + path));
  };
})();
