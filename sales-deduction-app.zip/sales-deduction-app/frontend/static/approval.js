/* 01. Approval Review — approval.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc;
  var queueFilter = 'all'; // all | risk | clean

  function render(data) {
    var el = document.getElementById('screen-queue');
    var maxTot = Math.max.apply(null, data.pendingByStage.map(function (s) { return s.total; }));

    var stageBars = data.pendingByStage.map(function (s) {
      var clean = s.total - s.risk;
      var riskH = s.total ? (s.risk / s.total * 100) : 0;
      return '' +
        '<div class="stage-col"><div class="grow">' +
          '<div class="stage-bar" style="height:' + (s.total / maxTot * 100).toFixed(1) + '%">' +
            (s.risk ? '<div class="risk" style="height:' + riskH.toFixed(1) + '%"><span>' + s.risk + '</span></div>' : '') +
            (clean ? '<div class="clean" style="height:' + (100 - riskH).toFixed(1) + '%"><span>' + clean + '</span></div>' : '') +
          '</div></div>' +
          '<div class="stage-label"><div class="n">' + esc(s.stage) + '</div>' +
          '<div class="t">' + s.total + ' items</div></div>' +
        '</div>';
    }).join('');

    var STAGE_COLOR = { CREATE: '#0381fe', CHANGE: '#0c8fa0', CLAIM: '#e8863c' };
    var STAGE_ORDER = ['CREATE', 'CHANGE', 'CLAIM'];
    var rtMax = Math.max.apply(null, data.riskByType.map(function (t) { return t.total; }));

    var riskRows = data.riskByType.map(function (t) {
      var segs = STAGE_ORDER.filter(function (st) { return t.byStage[st]; }).map(function (st) {
        var c = t.byStage[st];
        return '<div class="rt-seg" style="width:' + (c / rtMax * 100).toFixed(1) + '%;background:' + STAGE_COLOR[st] + '"><span>' + c + '</span></div>';
      }).join('');
      return '<div class="rt-row"><div class="rt-name" title="' + esc(t.name) + '">' + esc(t.name) + '</div>' +
             '<div class="rt-track">' + segs + '</div><div class="rt-total">' + t.total + '</div></div>';
    }).join('');

    var rows = data.rows.filter(function (r) {
      if (queueFilter === 'risk') return r.risks.length > 0;
      if (queueFilter === 'clean') return r.risks.length === 0;
      return true;
    }).map(function (r) {
      var has = r.risks.length > 0;
      var riskCell = has
        ? '<span class="risk-wrap">' + r.risks.map(function (x) { return '<span class="pill-risk">' + esc(x) + '</span>'; }).join('') + '</span>'
        : '<span class="txt-clean">Clean</span>';
      return '<tr class="' + (has ? 'row-risk' : '') + '">' +
        '<td class="id-cell" style="padding:13px 24px">' + esc(r.id) + '</td>' +
        '<td style="padding:13px 16px"><span class="pill-stage ' + esc(r.stage) + '">' + esc(r.stage) + '</span></td>' +
        '<td style="padding:13px 16px">' + riskCell + '</td>' +
        '<td style="padding:13px 16px;color:#707070;white-space:nowrap">' + esc(r.checkedAt) + '</td>' +
        '<td class="num" style="padding:13px 24px"><button class="btn-report">Open report</button></td>' +
      '</tr>';
    }).join('');

    el.innerHTML = '' +
      '<div class="mb22">' +
        '<div class="page-head"><div>' +
          '<h1 class="page-title">Approval Review</h1>' +
          '<div class="page-sub">' + data.pendingCount + ' awaiting your approval</div>' +
        '</div></div>' +
        '<div class="filter-bar" style="margin-top:16px;margin-bottom:0">' +
          '<div class="seg-toggle"><button class="on">Inbox <span style="opacity:.7">' + data.pendingCount + '</span></button><button>All</button></div>' +
          '<div class="vdiv"></div>' +
          SD.filterChip('Company', 'All') + SD.filterChip('BusArea', 'All') +
          '<button class="btn-apply">Apply</button>' +
          '<div style="margin-left:auto">' + SD.monthNav('Jun 2026', data.period, true) + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="alert-risk"><span class="alert-dot"></span>' +
        '<span class="alert-text"><b>' + data.riskCount + '</b> pending items carry risk flags. Review these first.</span>' +
        '<button class="alert-btn" id="btn-view-risk">View risk items</button>' +
      '</div>' +
      '<div class="grid-2">' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Pending by stage</div>' +
          '<div class="card-sub" style="margin-bottom:16px">Risk sits on top of each bar; clean below</div>' +
          '<div class="stage-chart">' + stageBars + '</div>' +
          '<div class="legend"><span><i style="background:#ef3434"></i>Risk</span><span><i style="background:#bcd9ff"></i>Clean</span></div>' +
        '</div>' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Risk by type</div>' +
          '<div class="card-sub" style="margin-bottom:18px">Segments show which stage each risk falls in</div>' +
          '<div class="rt-list">' + riskRows + '</div>' +
          '<div class="legend" style="margin-top:16px">' +
            '<span><i style="background:#0381fe"></i>CREATE</span>' +
            '<span><i style="background:#0c8fa0"></i>CHANGE</span>' +
            '<span><i style="background:#e8863c"></i>CLAIM</span>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="card" style="overflow:hidden">' +
        '<div class="tbl-head-bar">' +
          '<div class="tbl-head-title">Pending items</div>' +
          '<div class="tbl-head-sub">' + data.pendingCount + ' shown · <b style="color:#ef3434">' + data.riskCount + ' risk</b></div>' +
          '<div style="margin-left:auto;display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
            '<div class="mini-toggle" id="queue-filter">' +
              '<button data-f="all"' + (queueFilter === 'all' ? ' class="on"' : '') + '>All</button>' +
              '<button data-f="risk"' + (queueFilter === 'risk' ? ' class="on"' : '') + '>Risk only</button>' +
              '<button data-f="clean"' + (queueFilter === 'clean' ? ' class="on"' : '') + '>Clean only</button>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="tbl-wrap"><table class="tbl">' +
          '<thead><tr>' +
            '<th style="text-align:left;padding:12px 24px">Condition ID</th>' +
            '<th style="text-align:left">Stage</th>' +
            '<th style="text-align:left">Risk type</th>' +
            '<th style="text-align:left">Checked at</th>' +
            '<th class="num" style="padding:12px 24px">Report</th>' +
          '</tr></thead>' +
          '<tbody>' + rows + '</tbody>' +
        '</table></div>' +
      '</div>';

    Array.prototype.forEach.call(el.querySelectorAll('#queue-filter button'), function (btn) {
      btn.addEventListener('click', function () {
        queueFilter = btn.getAttribute('data-f');
        render(data);
      });
    });
    var viewRisk = el.querySelector('#btn-view-risk');
    if (viewRisk) viewRisk.addEventListener('click', function () {
      queueFilter = 'risk';
      render(data);
    });
  }

  SD.boot('/api/approval', render);
})();
