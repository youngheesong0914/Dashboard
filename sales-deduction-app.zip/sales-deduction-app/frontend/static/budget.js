/* 04. Target Plan Budget — budget.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmt1 = SD.fmt1;

  function render(data) {
    var el = document.getElementById('screen-budget');

    var kpiCard = function (title, k) {
      return '<div class="sum-card">' +
        '<div class="sum-k">' + esc(title) + ' · ' + esc(k.label) + '</div>' +
        '<div class="bk-pct">' + fmt1(k.pct) + '%</div>' +
        '<div class="bk-rows">' +
          '<div><span>QTY</span><b>' + esc(k.qty) + '</b></div>' +
          '<div><span>YoY</span><b>' + esc(k.yoy) + '</b></div>' +
          '<div><span>Delta</span><b class="neg">' + esc(k.delta) + '</b></div>' +
        '</div>' +
      '</div>';
    };

    var periodCells = function (p, over) {
      var pctCls = over ? ' cell-red' : ' strong';
      return '<td class="num bl">' + fmt(p.targetPlan) + '</td>' +
             '<td class="num">' + fmt(p.approved) + '</td>' +
             '<td class="num">' + fmt(p.inProc) + '</td>' +
             '<td class="num">' + fmt(p.paid) + '</td>' +
             '<td class="num">' + fmt(p.total) + '</td>' +
             '<td class="num' + pctCls + '">' + fmt1(p.pct) + '%</td>';
    };

    var bRows = data.budgetRows.map(function (b) {
      var first = b.checkLevel === 'Rebate';
      return '<tr class="' + (first ? 'group-top' : '') + '">' +
        '<td class="div-cell">' + (first ? esc(b.div) : '') + '</td>' +
        '<td class="lvl-cell">' + esc(b.checkLevel) + '</td>' +
        periodCells(b.month, b.overBudget) +
        periodCells(b.quarter, b.overBudget) +
      '</tr>';
    }).join('');

    var condRows = '';
    data.conditionGroups.forEach(function (g) {
      g.items.forEach(function (it, i) {
        condRows += '<tr class="' + (i === 0 ? 'group-top' : '') + '">' +
          '<td style="font-weight:700;color:#000;white-space:nowrap">' + (i === 0 ? esc(g.name) : '') + '</td>' +
          '<td class="doc-cell">' + esc(it.doc) + '</td>' +
          '<td style="font:500 11.5px/1.4 Manrope,sans-serif">' + esc(it.title) + '</td>' +
          '<td class="num">' + fmt(it.qty) + '</td>' +
          '<td class="num strong">' + fmt(it.amount) + '</td>' +
        '</tr>';
      });
      condRows += '<tr class="subtotal-row"><td></td><td></td>' +
        '<td>(Total) ' + esc(g.name) + '</td>' +
        '<td class="num">' + fmt(g.totalQty) + '</td>' +
        '<td class="num">' + fmt(g.totalAmount) + '</td></tr>';
    });
    condRows += '<tr class="grand-row"><td></td><td></td><td>Total</td>' +
      '<td class="num">' + fmt(data.conditionGrandTotal.qty) + '</td>' +
      '<td class="num">' + fmt(data.conditionGrandTotal.amount) + '</td></tr>';

    el.innerHTML = '' +
      '<div class="page-head"><div>' +
        '<h1 class="page-title">Sales Deduction Budget for Target Plan</h1>' +
        '<div class="page-sub">Budget vs. execution · Month (' + esc(data.kpi.month.label) + ') and Quarter (' + esc(data.kpi.quarter.label) + ')</div>' +
      '</div></div>' +
      '<div class="grid-budget">' +
        kpiCard('Month', data.kpi.month) +
        '<div class="placeholder-box">Month execution chart — placeholder</div>' +
        kpiCard('Quarter', data.kpi.quarter) +
        '<div class="placeholder-box">Quarter execution chart — placeholder</div>' +
      '</div>' +
      '<div class="card card-pad mb16">' +
        '<div style="font:700 15px/1.2 Manrope,sans-serif;margin-bottom:4px">Budget by division &amp; check level</div>' +
        '<div class="tbl-note">% = Total execution / Target Plan</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1120px">' +
          '<thead>' +
            '<tr><th rowspan="2" style="text-align:left;vertical-align:bottom">Div</th>' +
            '<th rowspan="2" style="text-align:left;vertical-align:bottom">Check Level</th>' +
            '<th colspan="6" class="hl-blue bl" style="text-align:center">Month (' + esc(data.kpi.month.label) + ')</th>' +
            '<th colspan="6" class="hl-blue bl" style="text-align:center">Quarter (' + esc(data.kpi.quarter.label) + ')</th></tr>' +
            '<tr>' +
              '<th class="num bl">Target Plan</th><th class="num">Approved</th><th class="num">In Proc.</th><th class="num">Paid</th><th class="num">Total</th><th class="num" style="color:#000;font-weight:700">%</th>' +
              '<th class="num bl">Target Plan</th><th class="num">Approved</th><th class="num">In Proc.</th><th class="num">Paid</th><th class="num">Total</th><th class="num" style="color:#000;font-weight:700">%</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>' + bRows + '</tbody>' +
        '</table></div>' +
      '</div>' +
      '<div class="sec-head">' +
        '<h2 class="sec-title">Condition List</h2><div class="vdiv"></div>' +
        SD.filterChip('Month', '2026-02') + SD.filterChip('DIV', 'All') + SD.filterChip('Status', 'All') +
      '</div>' +
      '<div class="card card-pad">' +
        '<div class="tbl-note">Grouped by Activity Name · Click a column header to sort</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1000px">' +
          '<thead><tr>' +
            '<th style="text-align:left;width:180px">Activity Name <span class="sort-hint">⇅</span></th>' +
            '<th style="text-align:left;width:160px">Condition Doc. <span class="sort-hint">⇅</span></th>' +
            '<th style="text-align:left">Condition Title <span class="sort-hint">⇅</span></th>' +
            '<th class="num" style="width:140px">Promotion QTY<br>(LAST)</th>' +
            '<th class="num hl-blue" style="width:160px">Promotion Amount T<br>(LAST)</th>' +
          '</tr></thead>' +
          '<tbody>' + condRows + '</tbody>' +
        '</table></div>' +
      '</div>';
  }

  SD.boot('/api/budget', render);
})();
