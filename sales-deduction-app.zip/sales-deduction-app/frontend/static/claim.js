/* 02. Claim L/T Analysis — claim.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmt1 = SD.fmt1;

  function render(data) {
    var el = document.getElementById('screen-claim');

    var cMax = Math.max.apply(null, data.trend.map(function (t) { return t.claims; }));
    var aMin = 80, aMax = 140;
    var yOf = function (a) { return Math.max(2, Math.min(98, (1 - (a - aMin) / (aMax - aMin)) * 100)); };

    var trendCols = data.trend.map(function (t) {
      return '<div class="trend-col">' +
        '<div class="trend-avg" style="top:' + yOf(t.avgDays).toFixed(1) + '%">' + fmt1(t.avgDays) + '</div>' +
        '<div class="trend-claims">' + fmt(t.claims) + '</div>' +
        '<div class="trend-bar" style="height:' + (t.claims / cMax * 70).toFixed(1) + '%"></div>' +
      '</div>';
    }).join('');
    var trendLine = data.trend.map(function (t, i) {
      return ((i + 0.5) / data.trend.length * 100).toFixed(2) + ',' + yOf(t.avgDays).toFixed(2);
    }).join(' ');
    var trendX = data.trend.map(function (t) { return '<div>' + esc(t.month) + '</div>'; }).join('');

    var bpMax = Math.max.apply(null, data.byProduct.map(function (p) { return p.avgDays; }));
    var bpShades = ['#9cc4f2', '#6ba6e8', '#3f83d6', '#20609f', '#154a80', '#f2d98c'];
    var products = data.byProduct.map(function (p, i) {
      return '<div class="hbar-row"><div class="hbar-name">' + esc(p.name) + '</div>' +
        '<div class="hbar-track"><div class="hbar-fill" style="width:' + (p.avgDays / bpMax * 100).toFixed(0) + '%;background:' + bpShades[i % bpShades.length] + '"></div></div>' +
        '<div class="hbar-val">' + fmt1(p.avgDays) + '</div></div>';
    }).join('');

    var steps = data.steps.map(function (s) {
      return '<div class="step-row ' + esc(s.kind) + '"><span class="step-name">' + esc(s.name) + '</span>' +
             '<span class="step-val">' + fmt1(s.days) + '</span></div>';
    }).join('');

    var custRows = data.customers.map(function (c) {
      return '<tr>' +
        '<td style="font-weight:600;color:#000;white-space:nowrap">' + esc(c.name) + '</td>' +
        '<td class="num strong">' + fmt(c.claims) + '</td>' +
        '<td class="num cell-blue">' + fmt1(c.ltAvg) + '</td>' +
        '<td class="num">' + fmt1(c.s1) + '</td>' +
        '<td class="num">' + fmt1(c.s2) + '</td>' +
        '<td class="num cell-amber">' + fmt1(c.customerDelay) + '</td>' +
        '<td class="num">' + fmt1(c.s3) + '</td>' +
        '<td class="num">' + fmt1(c.s4) + '</td>' +
        '<td class="num cell-amber">' + fmt1(c.samsungDelay) + '</td>' +
      '</tr>';
    }).join('');

    el.innerHTML = '' +
      '<div class="page-head"><h1 class="page-title">Claim L/T Analysis</h1></div>' +
      '<div class="ai-box">' +
        '<div class="ai-head"><span class="ai-badge">AI</span><span class="ai-title">AI Insight</span>' +
        '<span class="ai-sub">LLM-generated summary</span></div>' +
        '<div class="ai-body">' + esc(data.aiInsight) + '</div>' +
      '</div>' +
      '<div class="filter-bar">' +
        SD.monthNav('Jun 2026', data.period, false) + '<div class="vdiv"></div>' +
        SD.filterChip('Company', 'All') + SD.filterChip('BusArea', 'All') + SD.filterChip('Product', 'All') +
        '<button class="btn-apply">Apply</button>' +
      '</div>' +
      '<div class="kpi-strip">' +
        '<div class="kpi"><span class="k">Claim L/T (Days)</span><span class="v-lg">' + fmt1(data.kpi.ltAvgDays) + '</span></div>' +
        '<div class="vdiv"></div>' +
        '<div class="kpi"><span class="k">No. Claims (EA)</span><span class="v-md">' + fmt(data.kpi.claims) + '</span></div>' +
      '</div>' +
      '<div class="grid-claim">' +
        '<div class="card card-pad">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">' +
            '<div class="card-title">Monthly Trend</div>' +
            '<div class="legend" style="margin-top:0"><span><i style="background:#2f7ed8;width:12px;height:8px;border-radius:2px"></i>Number of Claims</span>' +
            '<span><i style="background:#e8863c;width:12px;height:2px;border-radius:0"></i>L/T Avg Days</span></div>' +
          '</div>' +
          '<div class="trend-wrap">' +
            '<svg class="trend-svg" viewBox="0 0 100 100" preserveAspectRatio="none">' +
              '<polyline points="' + trendLine + '" fill="none" stroke="#e8863c" stroke-width="0.6" vector-effect="non-scaling-stroke"></polyline>' +
            '</svg>' +
            '<div class="trend-bars">' + trendCols + '</div>' +
            '<div class="trend-x">' + trendX + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="card" style="padding:20px 22px">' +
          '<div class="card-title" style="margin-bottom:16px">by Product <span style="font-weight:500;color:#707070;font-size:11px">(L/T Avg Days)</span></div>' +
          '<div class="hbar-list">' + products + '</div>' +
        '</div>' +
        '<div class="card" style="padding:20px 22px">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:12px">' +
            '<div class="card-title">Step</div>' +
            '<div style="font:600 11px/1 Manrope,sans-serif;color:#707070">L/T Avg Days</div>' +
          '</div>' + steps +
        '</div>' +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:6px">' +
          '<div style="font:700 15px/1.2 Manrope,sans-serif">by Customer</div>' +
          '<span class="badge-over">Over Company Avg · ' + fmt1(data.companyAvg) + ' days</span>' +
          '<button class="btn-download">⭳ Raw Data Download</button>' +
        '</div>' +
        '<div class="tbl-note">Showing only customers whose L/T Avg Days exceeds the company average (' + fmt1(data.companyAvg) + ' days) · Click a column header to sort</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1040px">' +
          '<thead><tr>' +
            '<th style="text-align:left">Customer <span class="sort-hint">⇅</span></th>' +
            '<th class="num">No. Claims <span class="sort-hint">⇅</span></th>' +
            '<th class="num hl-blue">L/T Avg Days <span class="sort-hint">⇅</span></th>' +
            '<th class="num">1. Promo End<br>~ I/V Issue</th>' +
            '<th class="num">2. I/V Issue<br>~ I/V Receipt</th>' +
            '<th class="num hl-amber">Customer Delay<br>(1+2)</th>' +
            '<th class="num">3. I/V Receipt<br>~ Claim Creation</th>' +
            '<th class="num">4. Claim Creation<br>~ End of Approval</th>' +
            '<th class="num hl-amber">Samsung Delay<br>(3+4)</th>' +
          '</tr></thead>' +
          '<tbody>' + custRows + '</tbody>' +
        '</table></div>' +
      '</div>';
  }

  SD.boot('/api/claim-lt', render);
})();
