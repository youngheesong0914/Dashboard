/* Sales-Deduction AI Agent — common.js
 * 페이지 공통 유틸: 포맷터, fetch(요청 캐시), 로딩/에러 처리, 네비 뱃지.
 * 각 페이지 스크립트(approval.js 등)는 window.SD를 통해 사용한다. */
(function () {
  'use strict';

  var API = (window.API_BASE || '').replace(/\/$/, '');
  var cache = {}; // path → Promise. 같은 페이지에서 중복 요청 방지(뱃지 + 본문 공유)

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function fmt(n) { return n == null ? '—' : Number(n).toLocaleString('en-US'); }
  function fmt1(n) { return n == null ? '—' : Number(n).toFixed(1); }
  function fmtM(v) { return v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : Math.round(v / 1e3) + 'K'; }

  function fetchJSON(path) {
    if (!cache[path]) {
      cache[path] = fetch(API + path).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status + ' — ' + path);
        return res.json();
      }).catch(function (err) {
        delete cache[path]; // 실패한 요청은 캐시에서 제거해 재시도 가능하게
        throw err;
      });
    }
    return cache[path];
  }

  function showLoading(on) {
    var el = document.getElementById('loading');
    if (el) el.hidden = !on;
  }
  function showError(err) {
    var el = document.getElementById('error');
    if (!el) return;
    document.getElementById('error-detail').textContent = err.message || String(err);
    el.hidden = false;
  }
  function hideError() {
    var el = document.getElementById('error');
    if (el) el.hidden = true;
  }

  /* 페이지 부트스트랩: init(data)를 실행하고 로딩/에러/재시도를 공통 처리 */
  function boot(endpoint, init) {
    function run() {
      hideError();
      showLoading(true);
      fetchJSON(endpoint).then(function (data) {
        showLoading(false);
        init(data);
      }).catch(function (err) {
        showLoading(false);
        showError(err);
      });
    }
    var retry = document.getElementById('retry');
    if (retry) retry.addEventListener('click', run);
    run();
  }

  /* 네비 Approval 탭 뱃지 — 모든 페이지에서 대기 건수 표시.
     approval 페이지에서는 본문 fetch와 캐시를 공유하므로 요청이 1번만 나간다. */
  function initBadge() {
    var badge = document.getElementById('nav-badge');
    if (!badge) return;
    fetchJSON('/api/approval').then(function (d) {
      badge.textContent = d.pendingCount;
      badge.hidden = false;
    }).catch(function () { /* 뱃지는 실패해도 조용히 넘어감 */ });
  }

  // ---------- 공용 마크업 조각 ----------
  function filterChip(k, v) {
    return '<div class="filter-chip"><span class="k">' + esc(k) + '</span>' +
           '<span class="v">' + esc(v) + '</span><span class="arr">▾</span></div>';
  }
  function monthNav(main, sub, dim) {
    return '<div class="month-nav"' + (dim ? ' style="opacity:.45"' : '') + '>' +
           '<button>◀</button><div class="m-wrap"><div class="m">' + esc(main) + '</div>' +
           '<div class="m-sub">' + esc(sub) + '</div></div><button>▶</button></div>';
  }

  window.SD = {
    esc: esc, fmt: fmt, fmt1: fmt1, fmtM: fmtM,
    fetchJSON: fetchJSON, boot: boot,
    filterChip: filterChip, monthNav: monthNav,
  };

  initBadge();
})();
