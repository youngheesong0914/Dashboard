# Sales-Deduction AI Agent — 백엔드/프론트엔드 분리 버전

`0710_wireframe.html`에 하드코딩되어 있던 데이터를 Python(FastAPI) 백엔드로 옮기고,
JSP 프론트엔드가 API를 fetch해서 화면을 그리는 구조로 분리한 프로젝트입니다.

```
sales-deduction-app/
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py          # FastAPI 앱 — 4개 REST 엔드포인트 + 집계 로직
│       └── data.py          # 와이어프레임에서 추출한 데이터 (→ 나중에 DB 조회로 교체)
└── frontend/
    ├── index.jsp            # → approval.jsp 리다이렉트
    ├── approval.jsp         # 01 Approval Review
    ├── claimLt.jsp          # 02 Claim L/T Analysis
    ├── overdue.jsp          # 03 Overdue Conditions
    ├── budget.jsp           # 04 Target Plan Budget
    ├── common/
    │   ├── head.jspf        # 공통 <head> (CSS·폰트·API_BASE 주입)
    │   └── header.jspf      # 공통 상단바 + 네비 (activeNav로 활성 탭 표시)
    └── static/
        ├── dashboard.css    # 공통 스타일
        ├── common.js        # 유틸·fetch 캐시·에러 처리·네비 뱃지
        ├── approval.js      # 페이지별 렌더링 스크립트
        ├── claim.js
        ├── overdue.js
        └── budget.js
```

## 아키텍처

- **페이지 분리**: 화면당 JSP 1장씩 총 4개이며 상단 네비는 페이지 간 링크 이동입니다.
  공통 헤더/head는 `common/*.jspf`를 JSP 정적 include로 공유하고, 각 페이지가
  `activeNav` 변수로 활성 탭을 지정합니다.
- **백엔드는 숫자와 구조만** 내려줍니다. 스테이지별 집계, 리스크 유형 집계,
  연체 버킷 합산, 예산 %/합계 계산 등 데이터 로직은 전부 `main.py`에서 수행합니다.
- **프론트엔드는 표현만** 담당합니다. 각 페이지는 로드 시 자기 엔드포인트 하나만
  fetch해서 렌더링합니다 (`common.js` 공통 유틸 + 페이지별 `*.js`).
- 네비의 Approval 뱃지(대기 건수)는 `common.js`가 모든 페이지에서 `/api/approval`로
  받아 채웁니다. approval 페이지에서는 본문 fetch와 요청 캐시를 공유해
  실제 요청은 1번만 나갑니다.

## 캐시/저장소 구조 (외부 인프라 없음)

Redis, Memcached 같은 캐시 서버는 **사용하지 않습니다**. 클라이언트에 두 가지
브라우저 저장 공간만 있습니다.

| 구분 | 구현 | 수명 | 용도 |
|---|---|---|---|
| 요청 캐시 | `common.js`의 순수 JS 객체 `var cache = {}` — `{ "URL": Promise }` | 현재 페이지가 떠 있는 동안만 (페이지 이동/새로고침 시 소멸) | 같은 페이지 안에서 동일 URL 중복 호출 방지 (예: 네비 뱃지와 본문이 `/api/approval?view=inbox`를 공유 → HTTP 요청 1번) |
| 공유 필터 | 브라우저 `sessionStorage`의 `sd.filter` 키 (JSON 문자열) | 브라우저 탭이 살아있는 동안 (탭 닫으면 소멸, 페이지 이동은 유지) | 법인×BA×Product 필터를 대시보드 간 전달 |

- 요청 캐시가 Promise를 담는 이유: 응답이 도착하기 전에 두 곳에서 같은 URL을
  요청해도 동일 Promise를 공유해 요청이 한 번만 나가게 하기 위함입니다.
  실패한 요청은 캐시에서 제거해 "다시 시도"가 가능합니다.
- 필터를 바꿔 Apply 하면 쿼리스트링이 달라져 캐시 키(URL)도 달라지므로
  자연스럽게 새 요청이 나갑니다. 별도 무효화 로직은 없습니다.
- 백엔드(FastAPI)에도 캐시 계층이 없습니다 — 매 요청마다 `data.py`에서
  즉시 계산합니다. 실 DB 연동 후 응답이 무거워지면 그때 서버측 캐시
  (Redis 등) 도입을 검토하면 됩니다.


## 백엔드 실행

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

| Method | Endpoint | 화면 |
|---|---|---|
| GET | `/api/approval?userId=..&view=inbox\|all` | 01 사용자 정보 조회 — condition 문서(F01_TO_T_PT_DOCUMENT) + 법인/BA 리스트 + defaultFilter |
| GET | `/api/claim-lt?period=..&bukrs=..&gsper=..&product=..` | 02 Claim L/T — 화면 전체 데이터를 필터 반영해 반환 |
| GET | `/api/claim-lt/raw-data?period=..&bukrs=..&gsper=..&product=..` | 02 by Customer 원본 엑셀(.xlsx) 다운로드 |
| GET | `/api/overdue?period=..&bukrs=..&gsper=..&product=..`  | 03 Overdue — 팩트 기반 필터·요약/버킷 재집계 |
| GET | `/api/budget?period=..&div=..&status=..`   | 04 Budget — DIV/Status 필터 (샘플은 2026-02 고정) |

Swagger 문서: `http://localhost:8000/docs`

## 프론트엔드 배포 (Tomcat)

1. `*.jsp` 5개 → 웹앱 루트(예: `webapp/`)
2. `common/`, `static/` 폴더 → `webapp/common/`, `webapp/static/`
3. API 주소는 기본 `http://localhost:8000`이며, JVM 옵션으로 변경 가능:
   ```
   -Dapi.base=https://api.example.com
   ```
   (운영에서는 web.xml context-param이나 프로퍼티 파일 주입으로 바꾸는 것을 권장)

접속: `http://localhost:8080/<context>/` (index.jsp가 approval.jsp로 리다이렉트)


## Approval Review 데이터 흐름

- 페이지 로드 시 `GET /api/approval?userId=..&view=inbox`로 사용자 정보를 가져옵니다.
  응답에는 condition 문서 목록(`F01_TO_T_PT_DOCUMENT`: OBKEY / TYPE / APP_STATUS /
  BUKRS / GSPER + AI 점검 부가필드 risks·checkedAt), 법인(`companies`)·BA
  (`businessAreas`) 리스트, 그리고 **condition 수가 가장 많은 법인×BA 조합**인
  `defaultFilter`가 포함됩니다.
- `defaultFilter`는 **요청된 view 기준**으로 condition 최다 법인×BA 조합을
  계산합니다(Product는 항상 All). Approval Review 화면은 view=inbox로 조회하므로
  **승인 대기 기준** 초기값을, 뒤 대시보드들은 메타를 view=all로 조회하므로
  **전체 기준** 초기값을 갖습니다(샘플에선 우연히 둘 다 SEUK×461A). 사용자가
  Apply로 바꾸면 sessionStorage(`sd.filter`)에 저장되어 다른 대시보드로 전달됩니다.
- Claim L/T·Overdue의 Company/BA/Product 드롭다운 옵션은 Approval Review
  view=all 응답의 `companies`/`businessAreas`/`products` 리스트에서 채워지고,
  Apply 시 `?period=..&bukrs=..&gsper=..&product=..`로 재조회하며, **백엔드가
  화면에 필요한 모든 데이터를 필터 반영 상태로 반환**합니다. 고객/제품/연체
  팩트는 실제 차원 필터이고, KPI·트렌드·Step은 샘플에 원천 차원이 없어
  데모 가중치(`data.DEMO_*`)로 결정적으로 스케일합니다 — 실제 DB 연동 시
  이 부분만 원천 집계 쿼리로 교체하면 스키마는 그대로입니다. Claim의 월
  네비게이션(◀ ▶)은 `period`를 바꿔 재조회하며 KPI·Step 합계가 함께 바뀝니다.
- Budget의 DIV/Status 필터는 페이지 로컬이며 `?div=..&status=..`로 재조회해
  예산 테이블(선택 DIV + Total)과 Condition List(그룹 DIV·아이템 Status)를
  필터링합니다. Month는 샘플에 2026-02 한 달뿐이라 표시용입니다.
- Inbox/All 전환은 `view` 파라미터로 재요청하고, Company/BA 필터링과 차트
  집계는 클라이언트에서 수행합니다(실제 API가 userId·view만 받는 계약이므로).

## 백엔드 없이 Tomcat만으로 실행하기 (mock 모드)

FastAPI를 아직 띄울 수 없는 환경을 위해 JSP가 **기본값으로 mock 모드**로 동작합니다.

- `common/head.jspf`가 `api.mock` 플래그(기본 `true`)를 보고 `static/mock-api.js`를
  로드합니다. 이 스크립트는 실제 백엔드 응답 데이터와 필터링 로직(법인/BA/제품,
  period, DIV/Status, Inbox/All)을 JS로 미러링해 `window.fetch`를 가로채므로,
  **Tomcat에 JSP만 배포해도 모든 화면과 인터랙션이 샘플 데이터로 동작**합니다.
  (엑셀 다운로드만 서버가 필요해 CSV로 대체됩니다.)
- 화면 코드(common.js, 페이지별 JS)는 mock 여부를 전혀 모릅니다 — fetch URL도
  실제 API와 동일하게 나갑니다.
- FastAPI가 준비되면 JVM 옵션 하나로 전환합니다:
  ```
  -Dapi.mock=false -Dapi.base=http://api-server:8000
  ```
  JSP·JS 수정 없이 그대로 실제 API를 호출합니다.

## 프론트만 빠르게 확인하기 (백엔드·Tomcat 불필요)

`frontend/preview/` 폴더의 HTML 4장을 브라우저에서 바로 열면 됩니다
(`preview/approval.html` 부터). `static/mock-api.js`(JSP mock 모드와 동일 파일)가 실제 백엔드 응답을 그대로 담고 있어
`window.fetch`를 가로채 mock으로 응답하며, 운영 코드(`common.js`, 페이지별 JS, CSS)는
수정 없이 그대로 사용하므로 실제 렌더링 결과와 동일합니다.

- preview는 확인용입니다. 운영 배포에는 `frontend/*.jsp`를 사용하세요.
- 백엔드 스키마가 바뀌면 mock을 다시 뜨면 됩니다:
  각 엔드포인트 응답을 `mock-api.js`의 MOCK 객체에 교체.

## CORS

JSP(Tomcat)와 API(uvicorn)의 포트가 다르므로 백엔드에 CORS가 열려 있습니다
(`main.py`의 `allow_origins=["*"]`). **운영 배포 시 실제 프론트 도메인으로 좁혀 주세요.**
같은 도메인 뒤에 리버스 프록시(`/api` → uvicorn)로 묶으면 CORS 설정 자체가 불필요해집니다.

## DB 연동으로 교체할 때

`data.py`의 상수들만 DB 조회 함수로 바꾸면 됩니다. API 응답 스키마는 그대로 유지되므로
프론트엔드는 수정할 필요가 없습니다. 필터(Company/BusArea/Product, 월 선택)는 현재
와이어프레임처럼 장식용인데, 실제 연동 시 각 엔드포인트에 쿼리 파라미터
(`?period=2026-06&company=...`)를 추가하고 `dashboard.js`의 fetch URL에 붙이면 됩니다.

## 구현된 인터랙션

- Claim L/T by Customer:
  - 컬럼 헤더 클릭 정렬 — 첫 클릭 시 숫자 컬럼은 내림차순, Customer는 오름차순,
    재클릭 시 방향 반전 (▲/▼ 표시)
  - Raw Data Download — 현재 필터/월 그대로 백엔드가 생성한 **.xlsx** 다운로드
    (preview에서는 서버가 없어 같은 데이터를 CSV로 대체 제공)

- 상단 네비로 4개 페이지 이동, 현재 페이지 활성 표시 + 전 페이지 Approval 뱃지
- Approval Review:
  - `Inbox / All` 뷰 전환 — view 파라미터로 API 재요청, All 뷰에서 Status 컬럼 표시
  - `Company / BusArea` 드롭다운 + Apply — 차트·테이블에 필터 적용, 공유 필터로 저장
  - **차트 클릭 필터** — 스테이지 막대/리스크 유형 행 클릭 시 테이블 필터
    (재클릭 또는 ✕ 칩으로 해제, 선택 외 항목은 흐리게 표시)
  - `All / Risk only / Clean only` 리스크 필터 (위 필터들과 조합 가능), "View risk items" 버튼
- API 연결 실패 시 에러 배너 + 다시 시도 버튼
