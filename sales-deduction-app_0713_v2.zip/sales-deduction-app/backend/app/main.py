"""
Sales-Deduction AI Agent — Backend API (FastAPI)
================================================
실행:
    cd backend
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

엔드포인트:
    GET /api/approval   01. Approval Review (대기열 + 스테이지/리스크 집계)
    GET /api/claim-lt   02. Claim L/T Analysis
    GET /api/overdue    03. Overdue Conditions (요약/버킷 집계 포함)
    GET /api/budget     04. Target Plan Budget + Condition List

원칙: 백엔드는 "숫자와 구조"만 내려주고, 색상·막대 높이·포맷팅 같은
표현 로직은 전부 프론트엔드(dashboard.js)가 담당한다.
"""
from collections import Counter

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware

from . import data

app = FastAPI(title="Sales-Deduction AI Agent API", version="0.1.0")

# JSP(Tomcat) 오리진에서 fetch 할 수 있도록 CORS 허용.
# 운영 배포 시 allow_origins를 실제 도메인으로 좁혀주세요.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

STAGE_ORDER = ["CREATE", "CHANGE", "CLAIM"]


@app.get("/api/health")
def health():
    return {"status": "ok"}


# ---------------------------------------------------------------
# 01. Approval Review
# ---------------------------------------------------------------
@app.get("/api/approval")
def get_approval(
    userId: str = Query("jane.doe", description="사용자 ID"),
    view: str = Query("inbox", pattern="^(inbox|all)$", description="inbox=승인 대기만, all=전체"),
):
    """사용자 정보 조회.

    실제 백엔드처럼 userId와 view(inbox/all)를 파라미터로 받아,
    condition 문서(F01_TO_T_PT_DOCUMENT)와 법인/BA 리스트를 함께 반환한다.
    Company/BA 필터링과 차트 집계는 프론트엔드에서 수행한다(계약상 API는
    userId·view만 받으므로).
    """
    docs = data.PT_DOCUMENTS  # 실제 구현에서는 userId 기준으로 조회
    pending = [d for d in docs if d["APP_STATUS"] == "PENDING"]
    view_docs = pending if view == "inbox" else docs

    # 필터 초기값: "요청된 view 기준"으로 condition 수가 가장 많은 법인 × BA 조합.
    #  - Approval Review 화면은 view=inbox로 조회 → inbox(승인 대기) 기준 최다 조합
    #  - 뒤 대시보드들은 메타를 view=all로 조회 → 전체 기준 최다 조합
    # Product는 항상 All.
    combo = Counter((d["BUKRS"], d["GSPER"]) for d in view_docs)
    top = combo.most_common(1)[0][0] if view_docs else (None, None)

    return {
        "userId": userId,
        "period": "2026-06",
        "view": view,
        "pendingCount": len(pending),
        "totalCount": len(docs),
        "companies": data.COMPANIES,
        "businessAreas": data.BUSINESS_AREAS,
        "products": data.PRODUCTS,
        "defaultFilter": {"bukrs": top[0], "gsper": top[1], "product": ""},
        "F01_TO_T_PT_DOCUMENT": view_docs,
    }

@app.get("/api/approval/report")
def get_approval_report(obkey: str):
    """condition 문서 1건의 AI 점검 리포트."""
    doc = next((d for d in data.PT_DOCUMENTS if d["OBKEY"] == obkey), None)
    if doc is None:
        raise HTTPException(status_code=404, detail="Unknown OBKEY: " + obkey)

    seed = sum(ord(ch) for ch in obkey)  # 데모용 결정적 수치 생성
    checks = []
    for i, rule in enumerate(data.REPORT_RULES):
        failed = rule["name"] in doc["risks"]
        detail = (
            rule["fail"].format(
                pct=round(3 + (seed + i * 7) % 120 / 10, 1),
                days=1 + (seed + i * 3) % 21,
                bukrs=doc["BUKRS"], gsper=doc["GSPER"],
            )
            if failed else rule["ok"]
        )
        checks.append({"name": rule["name"],
                       "status": "FAIL" if failed else "PASS",
                       "detail": detail})

    fail_count = sum(1 for c in checks if c["status"] == "FAIL")
    if fail_count:
        names = ", ".join(c["name"] for c in checks if c["status"] == "FAIL")
        summary = ("%d of %d checks flagged risk (%s). "
                   "Review the flagged items before approving.") % (fail_count, len(checks), names)
    else:
        summary = ("All %d checks passed. "
                   "No risk detected — the condition is ready for approval.") % len(checks)

    return {
        "OBKEY": doc["OBKEY"], "TYPE": doc["TYPE"], "APP_STATUS": doc["APP_STATUS"],
        "BUKRS": doc["BUKRS"], "GSPER": doc["GSPER"], "checkedAt": doc["checkedAt"],
        "failCount": fail_count,
        "summary": summary,
        "checks": checks,
    }


# ---------------------------------------------------------------
# 02. Claim L/T Analysis
# ---------------------------------------------------------------
@app.get("/api/claim-lt")
def get_claim_lt(period: str = "", bukrs: str = "", gsper: str = "", product: str = ""):
    """화면에 필요한 모든 데이터를 (period × 법인 × BA × 제품) 필터 반영해 반환.

    고객/제품 테이블은 실제 차원 필터, KPI·트렌드·단계는 샘플에 원천 차원이
    없어 데모 가중치(data.DEMO_*)로 결정적으로 스케일한다. 실 DB 연동 시
    이 부분을 원천 집계 쿼리로 교체하면 응답 스키마는 그대로 유지된다.
    """
    to_period = lambda m: "20" + m[1:3] + "-" + m[4:6]  # noqa: E731  "'25.07" → "2025-07"
    periods = [to_period(t["month"]) for t in data.CLAIM_TREND]
    if period not in periods:
        period = periods[-1]

    factor = (data.DEMO_BUKRS_WEIGHT.get(bukrs, 1.0)
              * data.DEMO_GSPER_WEIGHT.get(gsper, 1.0)
              * data.DEMO_PRODUCT_WEIGHT.get(product, 1.0))
    # 세그먼트가 좁을수록 L/T가 소폭 길어지는 데모 보정 (factor=1이면 원본)
    avg_adj = 1 + (1 - factor) * 0.12

    trend = [
        {"month": t["month"],
         "claims": max(1, round(t["claims"] * factor)),
         "avgDays": round(t["avgDays"] * avg_adj, 1)}
        for t in data.CLAIM_TREND
    ]
    sel = trend[periods.index(period)]
    kpi_avg = sel["avgDays"]
    base_avg = data.CLAIM_TREND[-1]["avgDays"]  # 122.4 — steps 스케일 기준

    steps = [
        {**s, "days": round(s["days"] * kpi_avg / base_avg, 1)}
        for s in data.CLAIM_STEPS
    ]

    by_product = [
        {"name": p["name"], "avgDays": round(p["avgDays"] * avg_adj, 1)}
        for p in data.CLAIM_BY_PRODUCT
        if not product or p["name"] == product
    ]

    customers = [
        {**c,
         "customerDelay": round(c["s1"] + c["s2"], 1),
         "samsungDelay": round(c["s3"] + c["s4"], 1)}
        for c in data.CLAIM_CUSTOMERS
        if (not bukrs or c["bukrs"] == bukrs)
        and (not gsper or c["gsper"] == gsper)
        and (not product or c["product"] == product)
    ]

    return {
        "period": period,
        "availablePeriods": periods,
        "appliedFilter": {"bukrs": bukrs, "gsper": gsper, "product": product},
        "kpi": {"ltAvgDays": kpi_avg, "claims": sel["claims"]},
        "companyAvg": kpi_avg,
        "aiInsight": data.CLAIM_AI_INSIGHT,
        "trend": trend,
        "byProduct": by_product,
        "steps": steps,
        "customers": customers,
    }


def _filtered_claim_customers(bukrs: str, gsper: str, product: str):
    return [
        {**c,
         "customerDelay": round(c["s1"] + c["s2"], 1),
         "samsungDelay": round(c["s3"] + c["s4"], 1)}
        for c in data.CLAIM_CUSTOMERS
        if (not bukrs or c["bukrs"] == bukrs)
        and (not gsper or c["gsper"] == gsper)
        and (not product or c["product"] == product)
    ]


@app.get("/api/claim-lt/raw-data")
def claim_raw_data(period: str = "", bukrs: str = "", gsper: str = "", product: str = ""):
    """by Customer 원본 데이터를 엑셀(.xlsx)로 다운로드."""
    from io import BytesIO

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    customers = _filtered_claim_customers(bukrs, gsper, product)

    wb = Workbook()
    ws = wb.active
    ws.title = "by Customer"

    headers = [
        ("Customer", 38), ("Company", 10), ("BusArea", 10), ("Product", 13),
        ("No. Claims", 11), ("L/T Avg Days", 13),
        ("1. Promo End ~ I/V Issue", 22), ("2. I/V Issue ~ I/V Receipt", 22),
        ("Customer Delay (1+2)", 19),
        ("3. I/V Receipt ~ Claim Creation", 26), ("4. Claim Creation ~ End of Approval", 30),
        ("Samsung Delay (3+4)", 19),
    ]
    head_font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    head_fill = PatternFill("solid", fgColor="1F2937")
    body_font = Font(name="Arial", size=10)
    for i, (name, width) in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=i, value=name)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.freeze_panes = "A2"

    for r, c in enumerate(customers, start=2):
        row = [c["name"], c["bukrs"], c["gsper"], c["product"], c["claims"], c["ltAvg"],
               c["s1"], c["s2"], c["customerDelay"], c["s3"], c["s4"], c["samsungDelay"]]
        for i, v in enumerate(row, start=1):
            cell = ws.cell(row=r, column=i, value=v)
            cell.font = body_font
            if i >= 5:
                cell.number_format = "#,##0" if i == 5 else "#,##0.0"

    buf = BytesIO()
    wb.save(buf)
    fname = "claim_lt_customers_" + (period or "latest") + ".xlsx"
    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="%s"' % fname},
    )


# ---------------------------------------------------------------
# 03. Overdue Conditions
# ---------------------------------------------------------------
@app.get("/api/overdue")
def get_overdue(period: str = "", bukrs: str = "", gsper: str = "", product: str = ""):
    # period별 스냅샷 데모: 과거로 갈수록 소폭 감소 (실 DB 연동 시 월별 조회로 교체)
    months_back = 0
    if period and period != "2026-06":
        try:
            y, m = int(period[:4]), int(period[5:7])
            months_back = max(0, (2026 - y) * 12 + (6 - m))
        except ValueError:
            months_back = 0
    pf = 0.97 ** months_back

    facts = [
        {**f, "cells": [None if v is None else round(v * pf) for v in f["cells"]]}
        for f in data.OVERDUE_FACTS
        if (not bukrs or f["bukrs"] == bukrs)
        and (not gsper or f["gsper"] == gsper)
        and (not product or f["product"] == product)
    ]

    def add_cells(a, b):
        return [
            (None if (x is None and y is None) else (x or 0) + (y or 0))
            for x, y in zip(a, b)
        ]

    # 사업부별 합산 테이블
    by_div: dict = {}
    for f in facts:
        d = by_div.setdefault(f["division"], {
            "name": f["division"], "currency": f["currency"],
            "cells": [None] * len(data.OVERDUE_COLUMNS),
        })
        d["cells"] = add_cells(d["cells"], f["cells"])
    div_order = [d["name"] for d in data.OVERDUE_DIVISIONS]
    divisions = [
        {"name": n, "currency": by_div[n]["currency"],
         "values": dict(zip(data.OVERDUE_COLUMNS, by_div[n]["cells"]))}
        for n in div_order if n in by_div
    ]

    # aging 버킷 (Mobile / CTV / Others 스택)
    buckets = []
    for label, idx in data.OVERDUE_BUCKETS:
        mobile = ctv = others = 0
        for f in facts:
            v = f["cells"][idx] or 0
            if f["division"] == "Mobile":
                mobile += v
            elif f["division"] == "CTV":
                ctv += v
            else:
                others += v
        buckets.append({"label": label, "mobile": mobile, "ctv": ctv,
                        "others": others, "total": mobile + ctv + others})

    # 요약 카드: 필터된 팩트에서 계산
    col = {c: i for i, c in enumerate(data.OVERDUE_COLUMNS)}
    def tot(name):
        return sum(f["cells"][col[name]] or 0 for f in facts)
    total = tot("overdueAmt")
    pct = lambda v: round(v / total * 100) if total else 0  # noqa: E731

    return {
        "appliedFilter": {"period": period or "2026-06", "bukrs": bukrs, "gsper": gsper, "product": product},
        "summary": {
            "totalOverdue": total,
            "over31": {"amount": tot("over31"), "pctOfTotal": pct(tot("over31"))},
            "over90": {"amount": tot("over90"), "pctOfTotal": pct(tot("over90"))},
            "over180": {"amount": tot("over180"), "pctOfTotal": pct(tot("over180"))},
        },
        "agingBuckets": buckets,
        "columns": data.OVERDUE_COLUMNS,
        "divisions": divisions,
    }

# ---------------------------------------------------------------
# 04. Target Plan Budget
# ---------------------------------------------------------------
@app.get("/api/budget")
def get_budget(period: str = "", div: str = "", status: str = ""):
    # 샘플 데이터는 2026-02 한 달치만 존재. period는 계약상 수용하되 현재는 고정.
    def build_rows(g):
        rows = []
        for level in data.BUDGET_CHECK_LEVELS:
            if level == "Rebate":
                tp, ap, ip_, pd_ = g["targetPlan"], g["approved"], g["inProc"], g["paid"]
            else:
                tp = ap = ip_ = pd_ = 0
            total = ap + ip_ + pd_
            pct = round(total / tp * 100, 1) if tp else 0.0
            period = {
                "targetPlan": tp, "approved": ap, "inProc": ip_,
                "paid": pd_, "total": total, "pct": pct,
            }
            rows.append({
                "div": g["div"],
                "checkLevel": level,
                # 와이어프레임처럼 월/분기 동일 값. 실제 DB 연동 시 분리.
                "month": period,
                "quarter": dict(period),
                "overBudget": level == "Rebate" and tp and total > tp,
            })
        return rows

    groups_src = [g for g in data.BUDGET_DIVISIONS if not div or g["div"] in (div, "Total")]
    budget_rows = [row for g in groups_src for row in build_rows(g)]

    groups = []
    grand_qty = grand_amt = 0
    for g in data.CONDITION_GROUPS:
        if div and g["div"] != div:
            continue
        items = [i for i in g["items"] if not status or i["status"] == status]
        if not items:
            continue
        tq = sum(i["qty"] for i in items)
        ta = sum(i["amount"] for i in items)
        grand_qty += tq
        grand_amt += ta
        groups.append({
            "name": g["name"],
            "div": g["div"],
            "items": items,
            "totalQty": tq,
            "totalAmount": ta,
        })

    return {
        "appliedFilter": {"div": div, "status": status},
        "statusOptions": ["Approved", "In Proc.", "Paid"],
        "divOptions": [g["div"] for g in data.BUDGET_DIVISIONS if g["div"] != "Total"],
        "kpi": data.BUDGET_KPI,
        "budgetRows": budget_rows,
        "conditionGroups": groups,
        "conditionGrandTotal": {"qty": grand_qty, "amount": grand_amt},
    }
