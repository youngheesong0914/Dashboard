<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    String pageTitle = "Approval Review";
    String activeNav = "queue";
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<%@ include file="common/head.jspf" %>
</head>
<body>

<div class="layout">
<%@ include file="common/header.jspf" %>

  <main class="main">
    <div id="loading" class="state-banner">데이터를 불러오는 중…</div>
    <div id="error" class="state-banner state-error" hidden>
      API 서버에 연결할 수 없습니다. (<span id="error-detail"></span>)
      <button id="retry" class="btn-retry">다시 시도</button>
    </div>
    <section id="screen-queue" class="screen"></section>
  </main>
</div>

<script src="${pageContext.request.contextPath}/static/common.js"></script>
<script src="${pageContext.request.contextPath}/static/approval.js"></script>
</body>
</html>
