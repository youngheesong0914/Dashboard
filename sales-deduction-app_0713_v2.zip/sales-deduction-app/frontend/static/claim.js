/* 02. Claim L/T Analysis — claim.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmt1 = SD.fmt1;

  var period = '';           // ''=최신. API가 실제 적용된 period를 돌려준다
  var sortKey = null;        // by Customer 정렬 컬럼
  var sortDir = -1;          // 1=오름차순, -1=내림차순

  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function periodLabel(p) { // "2026-06" → "Jun 2026"
    return MONTHS[parseInt(p.slice(5, 7), 10) - 1] + ' ' + p.slice(0, 4);
  }
  function qs() {
    var q = SD.filterQS('?');
    if (period) q += (q ? '&' : '?') + 'period=' + encodeURIComponent(period);
    return q;
  }

  /* 메타(법인/BA/Product 리스트)는 Approval Review의 view=all 응답에서,
     기본 필터는 그 안의 defaultFilter(ALL 기준 최다 조합, Product=All)에서 온다. */
  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.loadMeta().then(function (meta) {
      SD.ensureFilter(meta);
      return SD.fetchJSON('/api/claim-lt' + qs()).then(function (data) {
        loading.hidden = true;
        period = data.period; // 실제 적용된 월로 동기화
        render(meta, data);
      });
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  function sortTh(key, label, style, cls) {
    var hint = sortKey === key
      ? '<span class="sort-hint" style="color:#0b57c2">' + (sortDir === 1 ? '▲' : '▼') + '</span>'
      : '<span class="sort-hint">⇅</span>';
    return '<th class="sortable ' + cls + '" data-sort="' + key + '"' +
           (style ? ' style="' + style + '"' : '') + '>' + label + ' ' + hint + '</th>';
  }

  function render(meta, data) {
    var el = document.getElementById('screen-claim');
    var f = SD.getFilter() || {};

    var cMax = Math.max.apply(null, data.trend.map(function (t) { return t.claims; }));
    var aMin = 80, aMax = 140;
    var yOf = function (a) { return Math.max(2, Math.min(98, (1 - (a - aMin) / (aMax - aMin)) * 100)); };

    var trendCols = data.trend.map(function (t) {
      return '<div class="trend-col">' +
        '<div class="trend-avg" style="top:' + yOf(t.avgDays).toFixed(1) + '%">' + fmt1(t.avgDays) + '</div>' +
        '<div class="trend-claims">' + fmt(t.claims) + '</div>' +
        '<div class="trend-bar" style="height:' + (t.claims / cMax * 70).toFixed(1) + '%"></div>' +
      '</div>';
    }).join('');
    var trendLine = data.trend.map(function (t, i) {
      return ((i + 0.5) / data.trend.length * 100).toFixed(2) + ',' + yOf(t.avgDays).toFixed(2);
    }).join(' ');
    var trendX = data.trend.map(function (t) { return '<div>' + esc(t.month) + '</div>'; }).join('');

    var bpMax = Math.max.apply(null, data.byProduct.map(function (p) { return p.avgDays; }));
    var bpShades = ['#9cc4f2', '#6ba6e8', '#3f83d6', '#20609f', '#154a80', '#f2d98c'];
    var products = data.byProduct.map(function (p, i) {
      return '<div class="hbar-row"><div class="hbar-name">' + esc(p.name) + '</div>' +
        '<div class="hbar-track"><div class="hbar-fill" style="width:' + (p.avgDays / bpMax * 100).toFixed(0) + '%;background:' + bpShades[i % bpShades.length] + '"></div></div>' +
        '<div class="hbar-val">' + fmt1(p.avgDays) + '</div></div>';
    }).join('');

    var steps = data.steps.map(function (s) {
      return '<div class="step-row ' + esc(s.kind) + '"><span class="step-name">' + esc(s.name) + '</span>' +
             '<span class="step-val">' + fmt1(s.days) + '</span></div>';
    }).join('');

    var customers = data.customers.slice();
    if (sortKey) {
      customers.sort(function (a, b) {
        var x = a[sortKey], y = b[sortKey];
        var cmp = (typeof x === 'string') ? x.localeCompare(y) : (x - y);
        return cmp * sortDir;
      });
    }

    var custRows = customers.map(function (c) {
      return '<tr>' +
        '<td style="font-weight:600;color:#000;white-space:nowrap">' + esc(c.name) + '</td>' +
        '<td class="num strong">' + fmt(c.claims) + '</td>' +
        '<td class="num cell-blue">' + fmt1(c.ltAvg) + '</td>' +
        '<td class="num">' + fmt1(c.s1) + '</td>' +
        '<td class="num">' + fmt1(c.s2) + '</td>' +
        '<td class="num cell-amber">' + fmt1(c.customerDelay) + '</td>' +
        '<td class="num">' + fmt1(c.s3) + '</td>' +
        '<td class="num">' + fmt1(c.s4) + '</td>' +
        '<td class="num cell-amber">' + fmt1(c.samsungDelay) + '</td>' +
      '</tr>';
    }).join('');

    el.innerHTML = '' +
      '<div class="page-head"><h1 class="page-title">Claim L/T Analysis</h1></div>' +
      '<div class="ai-box">' +
        '<div class="ai-head"><span class="ai-badge">AI</span><span class="ai-title">AI Insight</span>' +
        '<span class="ai-sub">LLM-generated summary</span></div>' +
        '<div class="ai-body">' + esc(data.aiInsight) + '</div>' +
      '</div>' +
      '<div class="filter-bar">' +
        (function () {
          var i = data.availablePeriods.indexOf(data.period);
          var canPrev = i > 0, canNext = i < data.availablePeriods.length - 1;
          return '<div class="month-nav">' +
            '<button id="m-prev"' + (canPrev ? '' : ' disabled style="opacity:.3;cursor:default"') + '>◀</button>' +
            '<div class="m-wrap"><div class="m">' + periodLabel(data.period) + '</div>' +
            '<div class="m-sub">' + esc(data.period) + '</div></div>' +
            '<button id="m-next"' + (canNext ? '' : ' disabled style="opacity:.3;cursor:default"') + '>▶</button>' +
          '</div>';
        })() + '<div class="vdiv"></div>' +
        SD.selectChip('Company', 'f-bukrs', meta.companies.map(function (c) { return c.bukrs; }), f.bukrs) +
        SD.selectChip('BusArea', 'f-gsper', meta.businessAreas.map(function (b) { return b.gsper; }), f.gsper) +
        SD.selectChip('Product', 'f-product', meta.products, f.product) +
        '<button class="btn-apply" id="btn-apply">Apply</button>' +
      '</div>' +
      '<div class="kpi-strip">' +
        '<div class="kpi"><span class="k">Claim L/T (Days)</span><span class="v-lg">' + fmt1(data.kpi.ltAvgDays) + '</span></div>' +
        '<div class="vdiv"></div>' +
        '<div class="kpi"><span class="k">No. Claims (EA)</span><span class="v-md">' + fmt(data.kpi.claims) + '</span></div>' +
      '</div>' +
      '<div class="grid-claim">' +
        '<div class="card card-pad">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">' +
            '<div class="card-title">Monthly Trend</div>' +
            '<div class="legend" style="margin-top:0"><span><i style="background:#2f7ed8;width:12px;height:8px;border-radius:2px"></i>Number of Claims</span>' +
            '<span><i style="background:#e8863c;width:12px;height:2px;border-radius:0"></i>L/T Avg Days</span></div>' +
          '</div>' +
          '<div class="trend-wrap">' +
            '<svg class="trend-svg" viewBox="0 0 100 100" preserveAspectRatio="none">' +
              '<polyline points="' + trendLine + '" fill="none" stroke="#e8863c" stroke-width="0.6" vector-effect="non-scaling-stroke"></polyline>' +
            '</svg>' +
            '<div class="trend-bars">' + trendCols + '</div>' +
            '<div class="trend-x">' + trendX + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="card" style="padding:20px 22px">' +
          '<div class="card-title" style="margin-bottom:16px">by Product <span style="font-weight:500;color:#707070;font-size:11px">(L/T Avg Days)</span></div>' +
          '<div class="hbar-list">' + products + '</div>' +
        '</div>' +
        '<div class="card" style="padding:20px 22px">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:12px">' +
            '<div class="card-title">Step</div>' +
            '<div style="font:600 11px/1 Manrope,sans-serif;color:#707070">L/T Avg Days</div>' +
          '</div>' + steps +
        '</div>' +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:6px">' +
          '<div style="font:700 15px/1.2 Manrope,sans-serif">by Customer</div>' +
          '<span class="badge-over">Over Company Avg · ' + fmt1(data.companyAvg) + ' days</span>' +
          '<button class="btn-download" id="btn-download">⭳ Raw Data Download</button>' +
        '</div>' +
        '<div class="tbl-note">Showing only customers whose L/T Avg Days exceeds the company average (' + fmt1(data.companyAvg) + ' days) · Click a column header to sort</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1040px">' +
          '<thead><tr>' +
            sortTh('name', 'Customer', 'text-align:left', '') +
            sortTh('claims', 'No. Claims', '', 'num') +
            sortTh('ltAvg', 'L/T Avg Days', '', 'num hl-blue') +
            sortTh('s1', '1. Promo End<br>~ I/V Issue', '', 'num') +
            sortTh('s2', '2. I/V Issue<br>~ I/V Receipt', '', 'num') +
            sortTh('customerDelay', 'Customer Delay<br>(1+2)', '', 'num hl-amber') +
            sortTh('s3', '3. I/V Receipt<br>~ Claim Creation', '', 'num') +
            sortTh('s4', '4. Claim Creation<br>~ End of Approval', '', 'num') +
            sortTh('samsungDelay', 'Samsung Delay<br>(3+4)', '', 'num hl-amber') +
          '</tr></thead>' +
          '<tbody>' + (custRows || '<tr><td colspan="9" style="padding:24px;text-align:center;color:#909090">No customers match the current filters</td></tr>') + '</tbody>' +
        '</table></div>' +
      '</div>';

    el.querySelector('#btn-apply').addEventListener('click', function () {
      SD.setFilter({
        bukrs: el.querySelector('#f-bukrs').value,
        gsper: el.querySelector('#f-gsper').value,
        product: el.querySelector('#f-product').value,
      });
      load();
    });

    // 월 이동
    var prev = el.querySelector('#m-prev'), next = el.querySelector('#m-next');
    function moveMonth(step) {
      var i = data.availablePeriods.indexOf(data.period) + step;
      if (i < 0 || i >= data.availablePeriods.length) return;
      period = data.availablePeriods[i];
      load();
    }
    if (prev && !prev.disabled) prev.addEventListener('click', function () { moveMonth(-1); });
    if (next && !next.disabled) next.addEventListener('click', function () { moveMonth(1); });

    // 컬럼 헤더 정렬 (첫 클릭: 문자열=오름차순, 숫자=내림차순 / 재클릭: 방향 반전)
    Array.prototype.forEach.call(el.querySelectorAll('th.sortable'), function (th) {
      th.style.cursor = 'pointer';
      th.addEventListener('click', function () {
        var key = th.getAttribute('data-sort');
        if (sortKey === key) sortDir = -sortDir;
        else { sortKey = key; sortDir = (key === 'name') ? 1 : -1; }
        render(meta, data);
      });
    });

    // Raw Data Download (.xlsx) — 현재 필터/월 그대로 서버에서 생성
    el.querySelector('#btn-download').addEventListener('click', function () {
      var url = (window.API_BASE || '') + '/api/claim-lt/raw-data' + qs();
      fetch(url).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var cd = res.headers && res.headers.get && res.headers.get('content-disposition');
        var m = cd && /filename="?([^";]+)"?/.exec(cd);
        return res.blob().then(function (blob) {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = m ? m[1] : 'claim_lt_customers.xlsx';
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        });
      }).catch(function (err) {
        alert('다운로드에 실패했습니다: ' + (err.message || err));
      });
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
