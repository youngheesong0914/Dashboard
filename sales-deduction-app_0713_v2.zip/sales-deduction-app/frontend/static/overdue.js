/* 03. Overdue Conditions — overdue.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmtM = SD.fmtM;

  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.loadMeta().then(function (meta) {
      SD.ensureFilter(meta);
      return SD.fetchJSON('/api/overdue' + SD.filterQS('?')).then(function (data) {
        loading.hidden = true;
        render(meta, data);
      });
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  function render(meta, data) {
    var el = document.getElementById('screen-overdue');
    var f = SD.getFilter() || {};
    var s = data.summary;

    var agMax = Math.max.apply(null, data.agingBuckets.map(function (b) { return b.total; }));
    var agingCols = data.agingBuckets.map(function (b) {
      var segH = function (v) { return b.total ? (v / b.total * 100).toFixed(1) : 0; };
      return '<div class="aging-col">' +
        '<div class="aging-total">' + fmtM(b.total) + '</div>' +
        '<div class="aging-bar" style="height:' + Math.max(2.5, b.total / agMax * 100).toFixed(1) + '%">' +
          '<div style="background:#0381fe;height:' + segH(b.mobile) + '%"></div>' +
          '<div style="background:#0c8fa0;height:' + segH(b.ctv) + '%"></div>' +
          '<div style="background:#c9d3e2;height:' + segH(b.others) + '%"></div>' +
        '</div>' +
        '<div class="aging-label">' + esc(b.label) + '</div>' +
      '</div>';
    }).join('');

    // 도넛: over90 / (31~90) / (1~31) 비중
    var p90 = s.over90.pctOfTotal;
    var p31_90 = s.over31.pctOfTotal - p90;
    var p1_31 = 100 - s.over31.pctOfTotal;
    var donutSeg = function (pct, offset, color) {
      return '<circle cx="21" cy="21" r="15.9" fill="none" stroke="' + color + '" stroke-width="5.5" ' +
             'stroke-dasharray="' + pct + ' ' + (100 - pct) + '" stroke-dashoffset="' + offset + '"></circle>';
    };

    var COLS = [
      ['overdueAmt', 'Overdue Amt', 'strong'],
      ['d1_15', '1–15', ''], ['d16_31', '16–31', ''],
      ['over31', 'Over 31', 'amber'],
      ['d32_60', '32–60', ''], ['d61_90', '61–90', ''],
      ['over90', 'Over 90', 'amber'],
      ['d91_180', '91–180', ''],
      ['over180', 'Over 180', 'red'],
      ['d181_365', '181–365', ''], ['y1_2', '1–2y', ''], ['y2_plus', '2y+', ''],
    ];
    var headCells = COLS.map(function (c) {
      var cls = c[2] === 'amber' ? ' hl-amber' : c[2] === 'red' ? ' hl-red' : '';
      return '<th class="num' + cls + '">' + c[1] + '</th>';
    }).join('');
    var divRows = data.divisions.map(function (d) {
      var cells = COLS.map(function (c) {
        var cls = c[2] === 'strong' ? ' strong' : c[2] === 'amber' ? ' cell-amber' : c[2] === 'red' ? ' cell-red' : '';
        return '<td class="num' + cls + '">' + fmt(d.values[c[0]]) + '</td>';
      }).join('');
      return '<tr><td style="font-weight:600;color:#000;white-space:nowrap">' + esc(d.name) + '</td>' +
             '<td style="color:#909090">' + esc(d.currency) + '</td>' + cells + '</tr>';
    }).join('');

    el.innerHTML = '' +
      '<div class="page-head"><div>' +
        '<h1 class="page-title">Overdue Conditions</h1>' +
        '<div class="page-sub">Over 90 days · <b style="color:#ef3434">' + fmtM(s.over90.amount) + '</b> outstanding</div>' +
      '</div></div>' +
      '<div class="ai-box empty">' +
        '<span class="ai-badge">AI</span><span class="ai-title">AI Insight</span>' +
        '<span class="ai-sub">LLM summary slot — intentionally left blank for now</span>' +
      '</div>' +
      '<div class="filter-bar">' +
        SD.selectChip('Company', 'f-bukrs', meta.companies.map(function (c) { return c.bukrs; }), f.bukrs) +
        SD.selectChip('BA', 'f-gsper', meta.businessAreas.map(function (b) { return b.gsper; }), f.gsper) +
        SD.selectChip('Product', 'f-product', meta.products, f.product) +
        '<button class="btn-apply" id="btn-apply">Apply</button>' +
      '</div>' +
      '<div class="grid-4">' +
        '<div class="sum-card"><div class="sum-k">Total overdue</div><div class="sum-v">' + fmt(s.totalOverdue) + '</div><div class="sum-p">100%</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 31 days</div><div class="sum-v">' + fmt(s.over31.amount) + '</div><div class="sum-p amber">' + s.over31.pctOfTotal + '% of total</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 90 days</div><div class="sum-v">' + fmt(s.over90.amount) + '</div><div class="sum-p red">' + s.over90.pctOfTotal + '% of total</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 180 days</div><div class="sum-v">' + fmt(s.over180.amount) + '</div><div class="sum-p red">' + s.over180.pctOfTotal + '% of total</div></div>' +
      '</div>' +
      '<div class="grid-overdue">' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Overdue amount by aging bucket</div>' +
          '<div class="card-sub" style="margin-bottom:16px">Stacked by division · local currency</div>' +
          '<div class="aging-chart">' + agingCols + '</div>' +
          '<div class="legend"><span><i style="background:#0381fe"></i>Mobile</span>' +
          '<span><i style="background:#0c8fa0"></i>CTV</span><span><i style="background:#c9d3e2"></i>Others</span></div>' +
        '</div>' +
        '<div class="card donut-card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Share by aging band</div>' +
          '<div class="card-sub">Of total overdue ' + fmtM(s.totalOverdue) + '</div>' +
          '<div class="donut-wrap">' +
            '<svg width="164" height="164" viewBox="0 0 42 42">' +
              '<circle cx="21" cy="21" r="15.9" fill="none" stroke="#f0f0f0" stroke-width="5.5"></circle>' +
              donutSeg(p90, 25, '#ef3434') +
              donutSeg(p31_90, 25 - p90, '#e8863c') +
              donutSeg(p1_31, 25 - p90 - p31_90, '#bcd9ff') +
            '</svg>' +
            '<div class="donut-center"><div class="donut-pct">' + p90 + '%</div><div class="donut-cap">Over 90 days</div></div>' +
          '</div>' +
          '<div class="legend"><span><i style="background:#ef3434"></i>Over 90</span>' +
          '<span><i style="background:#e8863c"></i>31–90</span><span><i style="background:#bcd9ff"></i>1–31</span></div>' +
        '</div>' +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="font:700 15px/1.2 Manrope,sans-serif;margin-bottom:4px">Overdue amount by division</div>' +
        '<div class="tbl-note">Highlighted columns are cumulative bands (Over 31 / Over 90 / Over 180) · Local currency</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1120px">' +
          '<thead><tr><th style="text-align:left">Division</th><th style="text-align:left">L.Curr</th>' + headCells + '</tr></thead>' +
          '<tbody>' + (divRows || '<tr><td colspan="14" style="padding:24px;text-align:center;color:#909090">No data for the current filters</td></tr>') + '</tbody>' +
        '</table></div>' +
      '</div>';

    el.querySelector('#btn-apply').addEventListener('click', function () {
      SD.setFilter({
        bukrs: el.querySelector('#f-bukrs').value,
        gsper: el.querySelector('#f-gsper').value,
        product: el.querySelector('#f-product').value,
      });
      load();
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
