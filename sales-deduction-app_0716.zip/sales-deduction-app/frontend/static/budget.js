/* 04. Target Plan Budget — budget.js (0716 와이어프레임) */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt;

  // 페이지 로컬 필터 (Condition List용)
  var fDiv = '';
  var fStatus = '';

  function qs() {
    var q = [];
    var f = SD.getFilter() || {};
    if (f.bukrs) q.push('bukrs=' + encodeURIComponent(f.bukrs));
    if (f.gsper) q.push('gsper=' + encodeURIComponent(f.gsper));
    if (fDiv) q.push('div=' + encodeURIComponent(fDiv));
    if (fStatus) q.push('status=' + encodeURIComponent(fStatus));
    return q.length ? '?' + q.join('&') : '';
  }

  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.loadMeta().then(function (meta) {
      SD.ensureFilter(meta);
      return SD.fetchJSON('/api/budget' + qs()).then(function (data) {
        loading.hidden = true;
        render(meta, data);
      });
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  function fmtBM(v) { return (v < 1 ? v.toFixed(2) : v.toFixed(1)) + 'M$'; }

  // 불릿 차트: 목표 100% = 트랙 50% 지점, 초과분은 오른쪽 빨강, 200% 캡(⤍)
  function bullets(divs, tKey, eKey) {
    var CAP = 200, TARGET_AT = 50;
    return divs.map(function (d) {
      var t = d[tKey], e = d[eKey];
      var pct = t > 0 ? e / t * 100 : 0;
      var over = pct > 100, capped = pct > CAP;
      var baseW = Math.min(pct, 100) / 100 * TARGET_AT;
      var overW = over ? (Math.min(pct, CAP) - 100) / 100 * TARGET_AT : 0;
      return '<div style="display:flex;align-items:center;gap:10px">' +
        '<div style="flex:0 0 82px;text-align:right;font:600 13.5px/1.2 Manrope,sans-serif;color:#333;white-space:nowrap">' + esc(d.name) + '</div>' +
        '<div style="flex:1 1 0%;position:relative;height:16px;background:#eef0f3;border-radius:4px">' +
          '<div style="position:absolute;top:0;bottom:0;left:0;border-radius:4px 0 0 4px;width:' + baseW.toFixed(1) + '%;background:' + (over ? '#e5807d' : '#3b82d6') + '"></div>' +
          (over ? '<div style="position:absolute;top:0;bottom:0;left:' + TARGET_AT + '%;border-radius:0 4px 4px 0;width:' + overW.toFixed(1) + '%;background:#ef3434"></div>' : '') +
          '<div style="position:absolute;top:-3px;bottom:-3px;left:50%;width:2px;background:#1f2430;z-index:2"></div>' +
        '</div>' +
        '<div style="flex:0 0 124px;text-align:right;font:600 13px/1 Manrope,sans-serif;color:#555;white-space:nowrap;font-variant-numeric:tabular-nums">' + fmtBM(e) + ' / ' + fmtBM(t) + '</div>' +
        '<div style="flex:0 0 62px;text-align:right;white-space:nowrap;font:800 14.5px/1 Manrope,sans-serif;color:' + (over ? '#ef3434' : '#2f6fd0') + '">' + pct.toFixed(0) + '%' + (capped ? ' ⤍' : '') + '</div>' +
      '</div>';
    }).join('');
  }

  function periodCard(title, headBg, iconSvg, p, bulletsHtml) {
    var over = p.pct > 100;
    return '<div class="card" style="overflow:hidden;padding:0">' +
      '<div style="display:flex;align-items:center;gap:10px;background:' + headBg + ';padding:11px 24px">' +
        iconSvg +
        '<span style="font:800 16px/1 Manrope,sans-serif;color:#fff;letter-spacing:.02em">' + title + '</span>' +
        '<span style="font:700 14px/1 Manrope,sans-serif;color:rgba(255,255,255,.75)">' + esc(p.label) + '</span>' +
      '</div>' +
      '<div style="padding:18px 24px 20px">' +
        '<div style="display:flex;align-items:flex-end;gap:26px">' +
          '<div><div style="font:600 12.5px/1 Manrope,sans-serif;color:#909090;margin-bottom:5px">Execution</div>' +
            '<span style="font:800 34px/1 Manrope,sans-serif;letter-spacing:-0.01em;color:' + (over ? '#ef3434' : '#0b57c2') + '">' + p.pct.toFixed(1) + '%</span></div>' +
          '<div style="width:1px;align-self:stretch;background:#eee"></div>' +
          '<div><div style="font:600 12.5px/1 Manrope,sans-serif;color:#909090;margin-bottom:5px">Estimated</div>' +
            '<span style="font:800 26px/1 Manrope,sans-serif;letter-spacing:-0.01em;color:#000">' + fmtBM(p.estimate) + '</span></div>' +
          '<div><div style="font:600 12.5px/1 Manrope,sans-serif;color:#909090;margin-bottom:5px">Target</div>' +
            '<span style="font:800 26px/1 Manrope,sans-serif;letter-spacing:-0.01em;color:#707070">' + fmtBM(p.target) + '</span></div>' +
        '</div>' +
        '<div style="height:1px;background:#f0f0f0;margin:15px 0 13px"></div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:11px">' +
          '<div style="font:700 14px/1 Manrope,sans-serif;color:#333;white-space:nowrap">Execution by division</div>' +
          '<div style="font:500 12.5px/1 Manrope,sans-serif;color:#909090;white-space:nowrap">┃ = 100% of target</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:10px">' + bulletsHtml + '</div>' +
      '</div>' +
    '</div>';
  }

  function render(meta, data) {
    var el = document.getElementById('screen-budget');
    var f = SD.getFilter() || {};

    var calIcon = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M16 2v4"></path><path d="M8 2v4"></path><path d="M3 10h18"></path></svg>';
    var clkIcon = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>';

    // ---- SUMMARY 테이블: Div × Check Level × (MONTH 6 + QUARTER 6) ----
    var tdBase = 'padding:8px 12px;border-bottom:1px solid #f2f2f2;text-align:right;font:500 13.5px/1 Manrope,sans-serif;color:#555;font-variant-numeric:tabular-nums;white-space:nowrap;';
    function sideCells(s, isSum, over) {
      var cells = [
        { v: fmt(s.target), k: 0 }, { v: fmt(s.approved), k: 1 }, { v: fmt(s.inproc), k: 2 },
        { v: fmt(s.paid), k: 3 }, { v: fmt(s.total), k: 4 }, { v: s.pct.toFixed(1) + '%', k: 5 },
      ];
      return cells.map(function (c) {
        var st = tdBase;
        if (c.k === 0) st += 'border-left:2px solid #e5e5e5;';
        if (isSum) st += 'font-weight:700;color:#000;';
        if (c.k === 0 || c.k === 4) st += 'font-weight:700;color:#000;';
        else if (c.k === 5) st += over ? 'font-weight:800;color:#ef3434;background:#fdecec;' : 'font-weight:800;color:#000;';
        else if (!isSum) st += 'color:#9a9a9a;font-weight:400;';
        return '<td style="' + st + '">' + c.v + '</td>';
      }).join('');
    }

    var prevDiv = null;
    var sumRows = data.summaryRows.map(function (r) {
      var isSum = r.level === 'Total';
      var firstOfDiv = r.div !== prevDiv;
      prevDiv = r.div;
      var over = r.month.pct > 100 && (isSum || r.level === 'Rebate');
      return '<tr style="' + (firstOfDiv ? 'border-top:2px solid #e5e5e5;background:#f8f8f8;' : '') + '">' +
        '<td style="padding:8px 12px;border-bottom:1px solid #f2f2f2;font:700 14px/1.3 Manrope,sans-serif;white-space:nowrap">' + (firstOfDiv ? esc(r.div) : '') + '</td>' +
        '<td style="padding:8px 12px' + (isSum ? '' : ' 8px 22px') + ';border-bottom:1px solid #f2f2f2;font:' + (isSum ? '700' : '500') + ' 13.5px/1.3 Manrope,sans-serif;color:' + (isSum ? '#000' : '#707070') + ';white-space:nowrap">' + esc(r.level) + '</td>' +
        sideCells(r.month, isSum, over) + sideCells(r.quarter, isSum, over) +
      '</tr>';
    }).join('');

    var thB = 'padding:9px 12px;background:#fafafa;border-bottom:1px solid #ddd;font:600 13px/1.3 Manrope,sans-serif;color:#555;white-space:nowrap;';
    var subTh = 'text-align:right;padding:9px 12px;background:#fafafa;border-bottom:1px solid #ddd;font:500 12.5px/1.3 Manrope,sans-serif;color:#9a9a9a;white-space:nowrap;';
    var sideSub = '<th style="' + subTh + '">① Approved</th><th style="' + subTh + '">② In Proc.</th><th style="' + subTh + '">③ Paid</th>' +
      '<th style="text-align:right;padding:9px 12px;background:#fafafa;border-bottom:1px solid #ddd;font:700 13px/1.3 Manrope,sans-serif;color:#000;white-space:nowrap">Total <span style="font-weight:500;color:#909090">(①+②+③)</span></th>';
    var sideMid = '<th rowspan="2" style="' + thB + 'text-align:right;border-left:2px solid #e5e5e5;font-weight:700;color:#000;vertical-align:bottom">Target Plan</th>' +
      '<th colspan="4" style="text-align:center;padding:7px 12px;background:#fafafa;border-bottom:1px solid #eee;font:600 12.5px/1 Manrope,sans-serif;color:#707070;white-space:nowrap">Estimated Actual</th>' +
      '<th rowspan="2" style="' + thB + 'text-align:right;font:800 13px/1.3 Manrope,sans-serif;color:#000;vertical-align:bottom">%</th>';

    // ---- DETAIL Condition List ----
    var cBase = 'padding:8px 12px;border-bottom:1px solid #f2f2f2;font:500 13.5px/1.4 Manrope,sans-serif;color:#555;';
    function statusChip(s) {
      var st = s === 'Approved' ? 'color:#0b7a3e;background:#e9f6ee;' : s === 'Paid' ? 'color:#555;background:#f0f0f0;' : 'color:#b5701f;background:#fdf6ee;';
      return '<span style="display:inline-block;font:600 12px/1 Manrope,sans-serif;border-radius:5px;padding:4px 8px;white-space:nowrap;' + st + '">' + esc(s) + '</span>';
    }
    var condRows = data.conditions.map(function (r) {
      return '<tr>' +
        '<td style="' + cBase + 'white-space:nowrap">' + esc(r.division) + '</td>' +
        '<td style="' + cBase + 'white-space:nowrap">' + esc(r.sdType) + '</td>' +
        '<td style="' + cBase + 'white-space:nowrap">' + statusChip(r.status) + '</td>' +
        '<td style="' + cBase + 'font-family:ui-monospace,Menlo,monospace;font-size:12.5px;white-space:nowrap">' + esc(r.doc) + '</td>' +
        '<td style="' + cBase + 'max-width:380px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#333" title="' + esc(r.title) + '">' + esc(r.title) + '</td>' +
        '<td style="' + cBase + 'text-align:center;font-variant-numeric:tabular-nums;white-space:nowrap">' + esc(r.startDate) + '</td>' +
        '<td style="' + cBase + 'text-align:center;font-variant-numeric:tabular-nums;white-space:nowrap">' + esc(r.endDate) + '</td>' +
        '<td style="' + cBase + 'font-family:ui-monospace,Menlo,monospace;font-size:12.5px;white-space:nowrap">' + esc(r.customer) + '</td>' +
        '<td style="' + cBase + 'max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(r.customerName) + '</td>' +
        '<td style="' + cBase + 'text-align:right;font-variant-numeric:tabular-nums;font-weight:700;color:#000">' + fmt(r.amount) + '</td>' +
      '</tr>';
    }).join('');
    var grandTd = 'padding:10px 12px;border-bottom:none;font:700 14px/1.4 Manrope,sans-serif;background:#000;color:#fff;';
    var condFoot = '<tr><td colspan="9" style="' + grandTd + '">Total</td>' +
      '<td style="' + grandTd + 'text-align:right;font-variant-numeric:tabular-nums">' + fmt(data.conditionTotal) + '</td></tr>';

    var condTh = 'text-align:left;padding:10px 12px;background:#fafafa;border-bottom:1px solid #ddd;font:600 13px/1.3 Manrope,sans-serif;color:#555;white-space:nowrap;';

    var xlsIcon = '<span style="width:16px;height:16px;border-radius:3px;background:#1d6f42;color:#fff;display:inline-flex;align-items:center;justify-content:center;font:800 10px/1 Manrope,sans-serif">X</span>';

    el.innerHTML = '' +
      '<div class="page-head"><h1 class="page-title">Target Plan Budget</h1>' +
      '<div class="page-sub">Budget vs. execution · Month (' + esc(data.month.label) + ') and Quarter (' + esc(data.quarter.label) + ')</div></div>' +
      '<div class="filter-bar">' +
        SD.selectChip('Company', 'f-bukrs', meta.companies.map(function (c) { return c.bukrs; }), f.bukrs) +
        SD.selectChip('BA', 'f-gsper', meta.businessAreas.map(function (b) { return b.gsper; }), f.gsper) +
        '<button class="btn-apply" id="btn-apply">Apply</button>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-bottom:16px">' +
        periodCard('MONTH', '#0b57c2', calIcon, data.month, bullets(data.scaleDivisions, 'monthTarget', 'monthEstimate')) +
        periodCard('QUARTER', '#1f2430', clkIcon, data.quarter, bullets(data.scaleDivisions, 'quarterTarget', 'quarterEstimate')) +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="font:700 16px/1.2 Manrope,sans-serif;margin-bottom:18px">Budget by division &amp; check level</div>' +
        '<div style="border:1px solid #e8e8e8;border-radius:8px;background:#fdfdfd;padding:16px 18px">' +
          '<div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;margin-bottom:12px">' +
            '<span style="font:800 11.5px/1 Manrope,sans-serif;letter-spacing:.08em;color:#0b57c2;background:#eef4ff;border-radius:5px;padding:5px 9px">SUMMARY</span>' +
            '<span style="font:400 13.5px/1.4 \'Noto Sans KR\',sans-serif;color:#909090">% = Total execution / Target Plan</span>' +
          '</div>' +
          '<div class="tbl-wrap"><table class="tbl" style="min-width:1120px">' +
            '<thead>' +
              '<tr><th rowspan="3" style="' + thB + 'text-align:left;vertical-align:bottom">Div</th>' +
                '<th rowspan="3" style="' + thB + 'text-align:left;vertical-align:bottom">Check Level</th>' +
                '<th colspan="6" style="text-align:center;padding:9px 12px;background:#0b57c2;border-bottom:1px solid #0b57c2;border-left:2px solid #e5e5e5;font:800 13.5px/1 Manrope,sans-serif;color:#fff;letter-spacing:.03em;white-space:nowrap">MONTH · ' + esc(data.month.label) + '</th>' +
                '<th colspan="6" style="text-align:center;padding:9px 12px;background:#1f2430;border-bottom:1px solid #1f2430;border-left:2px solid #e5e5e5;font:800 13.5px/1 Manrope,sans-serif;color:#fff;letter-spacing:.03em;white-space:nowrap">QUARTER · ' + esc(data.quarter.label) + '</th></tr>' +
              '<tr>' + sideMid + sideMid + '</tr>' +
              '<tr>' + sideSub + sideSub + '</tr>' +
            '</thead>' +
            '<tbody>' + sumRows + '</tbody>' +
          '</table></div>' +
        '</div>' +
        '<div style="border:1px solid #e8e8e8;border-radius:8px;background:#fdfdfd;padding:16px 18px;margin-top:14px">' +
          '<div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;margin-bottom:12px">' +
            '<span style="font:800 11.5px/1 Manrope,sans-serif;letter-spacing:.08em;color:#555;background:#f0f0f0;border-radius:5px;padding:5px 9px">DETAIL</span>' +
            '<span style="font:700 14.5px/1.2 Manrope,sans-serif">Condition List</span>' +
            '<span style="font:400 13.5px/1.4 \'Noto Sans KR\',sans-serif;color:#909090">Conditions behind the summary above</span>' +
          '</div>' +
          '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">' +
            SD.filterChip('Month', data.months[0]) +
            SD.selectChip('DIV', 'f-div', data.divOptions, fDiv) +
            SD.selectChip('Status', 'f-status', data.statusOptions, fStatus) +
            '<button class="btn-apply" id="btn-cond-apply">Apply</button>' +
            '<div style="flex:1 1 0%"></div>' +
            '<button id="btn-xls" style="display:inline-flex;align-items:center;gap:8px;background:#fff;border:1px solid #ddd;border-radius:10px;padding:8px 14px;font:600 13.5px/1 Manrope,sans-serif;color:#333;cursor:pointer">' + xlsIcon + ' Excel Download</button>' +
          '</div>' +
          '<div class="tbl-wrap"><table class="tbl" style="min-width:1320px">' +
            '<thead><tr>' +
              '<th style="' + condTh + '">Division</th><th style="' + condTh + '">SD Type</th><th style="' + condTh + '">Status</th>' +
              '<th style="' + condTh + '">Condition doc.</th><th style="' + condTh + '">Title</th>' +
              '<th style="' + condTh + 'text-align:center">Start Date</th><th style="' + condTh + 'text-align:center">End Date</th>' +
              '<th style="' + condTh + '">Customer</th><th style="' + condTh + '">Customer Name</th>' +
              '<th style="' + condTh + 'text-align:right;font-weight:700;color:#000">Amount(L)</th>' +
            '</tr></thead>' +
            '<tbody>' + (condRows || '<tr><td colspan="10" style="padding:24px;text-align:center;color:#909090">No conditions match the current filters</td></tr>') + condFoot + '</tbody>' +
          '</table></div>' +
        '</div>' +
      '</div>';

    el.querySelector('#btn-apply').addEventListener('click', function () {
      var prev = SD.getFilter() || {};
      SD.setFilter({
        bukrs: el.querySelector('#f-bukrs').value,
        gsper: el.querySelector('#f-gsper').value,
        product: prev.product || '',
      });
      load();
    });
    el.querySelector('#btn-cond-apply').addEventListener('click', function () {
      fDiv = el.querySelector('#f-div').value;
      fStatus = el.querySelector('#f-status').value;
      load();
    });

    // Excel Download — 현재 필터 그대로 서버에서 .xlsx 생성
    el.querySelector('#btn-xls').addEventListener('click', function () {
      var url = (window.API_BASE || '') + '/api/budget/raw-data' + qs();
      fetch(url).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var cd = res.headers && res.headers.get && res.headers.get('content-disposition');
        var m = cd && /filename="?([^";]+)"?/.exec(cd);
        return res.blob().then(function (blob) {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = m ? m[1] : 'budget_conditions.xlsx';
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        });
      }).catch(function (err) {
        alert('다운로드에 실패했습니다: ' + (err.message || err));
      });
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
