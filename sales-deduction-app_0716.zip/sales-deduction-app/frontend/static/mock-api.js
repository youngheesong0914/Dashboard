/* preview 전용 mock API
 * 실제 백엔드 응답/원천 데이터를 담아두고 window.fetch를 가로챈다.
 * 필터 파라미터(bukrs/gsper/product, div/status)는 백엔드(main.py)와 동일한
 * 로직을 JS로 미러링해 처리한다 — 백엔드·Tomcat 없이 필터 동작까지 확인 가능.
 * 운영 코드(common.js, 페이지 JS)는 전혀 수정하지 않는다. */
(function () {
  'use strict';
  var BASE = {
  "approval_inbox": {
    "userId": "jane.doe",
    "period": "2026-06",
    "view": "inbox",
    "pendingCount": 12,
    "totalCount": 17,
    "companies": [
      {
        "bukrs": "SEUK",
        "name": "Samsung Electronics UK"
      },
      {
        "bukrs": "SEG",
        "name": "Samsung Electronics Germany"
      },
      {
        "bukrs": "SEI",
        "name": "Samsung Electronics Italia"
      }
    ],
    "businessAreas": [
      {
        "gsper": "461A"
      },
      {
        "gsper": "520B"
      },
      {
        "gsper": "702C"
      }
    ],
    "products": [
      "Mobile",
      "CTV",
      "Computer",
      "Memory",
      "White Goods",
      "Brown Goods"
    ],
    "defaultFilter": {
      "bukrs": "SEUK",
      "gsper": "461A",
      "product": ""
    },
    "F01_TO_T_PT_DOCUMENT": [
      {
        "OBKEY": "A2S910E26540159",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-26 16:34"
      },
      {
        "OBKEY": "A2S7B0C26610620",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-26 16:06"
      },
      {
        "OBKEY": "A2S330D26987267",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-25 15:50"
      },
      {
        "OBKEY": "A2S330D26784516",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Post-approval",
          "Budget exceeded"
        ],
        "checkedAt": "06-25 08:19"
      },
      {
        "OBKEY": "A2S560A26699512",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Deal Sheet Exception"
        ],
        "checkedAt": "06-24 16:38"
      },
      {
        "OBKEY": "A2S7B0C26436239",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "520B",
        "risks": [],
        "checkedAt": "06-24 11:20"
      },
      {
        "OBKEY": "A2S910E26512044",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "520B",
        "risks": [
          "Post-approval"
        ],
        "checkedAt": "06-23 09:12"
      },
      {
        "OBKEY": "A2S330D26689026",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-23 08:40"
      },
      {
        "OBKEY": "A2S560A26771330",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "461A",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-22 17:05"
      },
      {
        "OBKEY": "A2S120F26611207",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "702C",
        "risks": [],
        "checkedAt": "06-21 13:25"
      },
      {
        "OBKEY": "A2S880B26630441",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEI",
        "GSPER": "461A",
        "risks": [
          "Deal Sheet Exception"
        ],
        "checkedAt": "06-20 15:48"
      },
      {
        "OBKEY": "A2S880B26571193",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEI",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-19 09:16"
      }
    ]
  },
  "approval_all": {
    "userId": "jane.doe",
    "period": "2026-06",
    "view": "all",
    "pendingCount": 12,
    "totalCount": 17,
    "companies": [
      {
        "bukrs": "SEUK",
        "name": "Samsung Electronics UK"
      },
      {
        "bukrs": "SEG",
        "name": "Samsung Electronics Germany"
      },
      {
        "bukrs": "SEI",
        "name": "Samsung Electronics Italia"
      }
    ],
    "businessAreas": [
      {
        "gsper": "461A"
      },
      {
        "gsper": "520B"
      },
      {
        "gsper": "702C"
      }
    ],
    "products": [
      "Mobile",
      "CTV",
      "Computer",
      "Memory",
      "White Goods",
      "Brown Goods"
    ],
    "defaultFilter": {
      "bukrs": "SEUK",
      "gsper": "461A",
      "product": ""
    },
    "F01_TO_T_PT_DOCUMENT": [
      {
        "OBKEY": "A2S910E26540159",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-26 16:34"
      },
      {
        "OBKEY": "A2S7B0C26610620",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-26 16:06"
      },
      {
        "OBKEY": "A2S330D26987267",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-25 15:50"
      },
      {
        "OBKEY": "A2S330D26784516",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Post-approval",
          "Budget exceeded"
        ],
        "checkedAt": "06-25 08:19"
      },
      {
        "OBKEY": "A2S560A26699512",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Deal Sheet Exception"
        ],
        "checkedAt": "06-24 16:38"
      },
      {
        "OBKEY": "A2S910E26471822",
        "TYPE": "CLAIM",
        "APP_STATUS": "APPROVED",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-20 14:11"
      },
      {
        "OBKEY": "A2S330D26455914",
        "TYPE": "CREATE",
        "APP_STATUS": "APPROVED",
        "BUKRS": "SEUK",
        "GSPER": "461A",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-19 10:47"
      },
      {
        "OBKEY": "A2S7B0C26436239",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "520B",
        "risks": [],
        "checkedAt": "06-24 11:20"
      },
      {
        "OBKEY": "A2S910E26512044",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEUK",
        "GSPER": "520B",
        "risks": [
          "Post-approval"
        ],
        "checkedAt": "06-23 09:12"
      },
      {
        "OBKEY": "A2S7B0C26402675",
        "TYPE": "CHANGE",
        "APP_STATUS": "REJECTED",
        "BUKRS": "SEUK",
        "GSPER": "520B",
        "risks": [
          "Post-approval"
        ],
        "checkedAt": "06-18 16:52"
      },
      {
        "OBKEY": "A2S330D26689026",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-23 08:40"
      },
      {
        "OBKEY": "A2S560A26771330",
        "TYPE": "CLAIM",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "461A",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-22 17:05"
      },
      {
        "OBKEY": "A2S560A26398120",
        "TYPE": "CLAIM",
        "APP_STATUS": "APPROVED",
        "BUKRS": "SEG",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-17 09:30"
      },
      {
        "OBKEY": "A2S120F26611207",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEG",
        "GSPER": "702C",
        "risks": [],
        "checkedAt": "06-21 13:25"
      },
      {
        "OBKEY": "A2S120F26588034",
        "TYPE": "CLAIM",
        "APP_STATUS": "APPROVED",
        "BUKRS": "SEG",
        "GSPER": "702C",
        "risks": [
          "Budget exceeded"
        ],
        "checkedAt": "06-16 11:02"
      },
      {
        "OBKEY": "A2S880B26630441",
        "TYPE": "CHANGE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEI",
        "GSPER": "461A",
        "risks": [
          "Deal Sheet Exception"
        ],
        "checkedAt": "06-20 15:48"
      },
      {
        "OBKEY": "A2S880B26571193",
        "TYPE": "CREATE",
        "APP_STATUS": "PENDING",
        "BUKRS": "SEI",
        "GSPER": "461A",
        "risks": [],
        "checkedAt": "06-19 09:16"
      }
    ]
  },
  "claim_src": {
    "trend": [
      {
        "month": "'25.07",
        "claims": 2734,
        "avgDays": 101.0
      },
      {
        "month": "'25.08",
        "claims": 2856,
        "avgDays": 94.0
      },
      {
        "month": "'25.09",
        "claims": 2790,
        "avgDays": 94.3
      },
      {
        "month": "'25.10",
        "claims": 2529,
        "avgDays": 134.3
      },
      {
        "month": "'25.11",
        "claims": 2648,
        "avgDays": 89.6
      },
      {
        "month": "'25.12",
        "claims": 3068,
        "avgDays": 106.9
      },
      {
        "month": "'26.01",
        "claims": 3141,
        "avgDays": 97.0
      },
      {
        "month": "'26.02",
        "claims": 2527,
        "avgDays": 91.2
      },
      {
        "month": "'26.03",
        "claims": 3321,
        "avgDays": 109.3
      },
      {
        "month": "'26.04",
        "claims": 2031,
        "avgDays": 105.9
      },
      {
        "month": "'26.05",
        "claims": 2372,
        "avgDays": 123.0
      },
      {
        "month": "'26.06",
        "claims": 3329,
        "avgDays": 122.4
      }
    ],
    "byProduct": [
      {
        "name": "Mobile",
        "avgDays": 194.9
      },
      {
        "name": "Computer",
        "avgDays": 185.9
      },
      {
        "name": "Memory",
        "avgDays": 164.1
      },
      {
        "name": "Brown Goods",
        "avgDays": 127.2
      },
      {
        "name": "White Goods",
        "avgDays": 106.8
      },
      {
        "name": "CTV",
        "avgDays": 93.0
      }
    ],
    "steps": [
      {
        "name": "1. Promo End ~ I/V Issue",
        "days": 72.7,
        "kind": "step"
      },
      {
        "name": "2. I/V Issue ~ I/V Receipt",
        "days": 4.4,
        "kind": "step"
      },
      {
        "name": "Customer Delay",
        "days": 77.1,
        "kind": "subtotal"
      },
      {
        "name": "3. I/V Receipt ~ Claim Creation",
        "days": 18.9,
        "kind": "step"
      },
      {
        "name": "4. Claim Creation ~ End of Approval",
        "days": 26.4,
        "kind": "step"
      },
      {
        "name": "Samsung Delay",
        "days": 45.2,
        "kind": "subtotal"
      },
      {
        "name": "Sum",
        "days": 122.4,
        "kind": "total"
      }
    ],
    "customers": [
      {
        "name": "2430031 Exertis Ireland Estore",
        "claims": 140,
        "ltAvg": 799.0,
        "s1": 771.3,
        "s2": 2.5,
        "s3": 5.6,
        "s4": 19.6,
        "bukrs": "SEUK",
        "gsper": "520B",
        "product": "Computer"
      },
      {
        "name": "2015695 Shop Direct Home Shopping",
        "claims": 128,
        "ltAvg": 186.6,
        "s1": 115.8,
        "s2": 2.3,
        "s3": 10.9,
        "s4": 57.6,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Mobile"
      },
      {
        "name": "4244888 TD Synnex UK Limited",
        "claims": 92,
        "ltAvg": 180.5,
        "s1": 130.4,
        "s2": 2.5,
        "s3": 8.9,
        "s4": 38.7,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Computer"
      },
      {
        "name": "4531120 Partner Retail Services Ltd",
        "claims": 67,
        "ltAvg": 166.3,
        "s1": 67.2,
        "s2": 5.6,
        "s3": 40.0,
        "s4": 53.5,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods"
      },
      {
        "name": "4522186 Westcoast / Very",
        "claims": 54,
        "ltAvg": 158.1,
        "s1": 100.3,
        "s2": 5.4,
        "s3": 8.9,
        "s4": 43.5,
        "bukrs": "SEUK",
        "gsper": "520B",
        "product": "CTV"
      },
      {
        "name": "2062094 Exertis (UK) Ltd",
        "claims": 46,
        "ltAvg": 148.7,
        "s1": 90.5,
        "s2": 4.5,
        "s3": 12.9,
        "s4": 40.8,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Mobile"
      },
      {
        "name": "9037215 Combined Independent (Holdings)",
        "claims": 41,
        "ltAvg": 148.3,
        "s1": 55.4,
        "s2": 4.5,
        "s3": 51.7,
        "s4": 36.7,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "CTV"
      },
      {
        "name": "2015540 Sky UK Ltd",
        "claims": 27,
        "ltAvg": 145.6,
        "s1": 108.4,
        "s2": 5.0,
        "s3": 12.0,
        "s4": 20.2,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "CTV"
      },
      {
        "name": "2430099 Exertis / Very",
        "claims": 23,
        "ltAvg": 140.2,
        "s1": 90.3,
        "s2": 5.2,
        "s3": 6.5,
        "s4": 38.2,
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "Mobile"
      },
      {
        "name": "2015472 Tesco Stores Limited",
        "claims": 21,
        "ltAvg": 139.8,
        "s1": 108.7,
        "s2": 10.7,
        "s3": 6.8,
        "s4": 13.6,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods"
      },
      {
        "name": "6031882 SEUK eStore - Hybris",
        "claims": 18,
        "ltAvg": 137.4,
        "s1": 94.4,
        "s2": 4.5,
        "s3": 8.5,
        "s4": 30.0,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Mobile"
      },
      {
        "name": "2258190 Currys Retail Limited",
        "claims": 10,
        "ltAvg": 133.0,
        "s1": 43.7,
        "s2": 4.5,
        "s3": 4.5,
        "s4": 80.3,
        "bukrs": "SEI",
        "gsper": "461A",
        "product": "Brown Goods"
      },
      {
        "name": "2015500 Argos Ltd",
        "claims": 88,
        "ltAvg": 118.4,
        "s1": 66.0,
        "s2": 4.2,
        "s3": 9.0,
        "s4": 39.2,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods"
      },
      {
        "name": "2044310 John Lewis plc",
        "claims": 61,
        "ltAvg": 109.5,
        "s1": 58.5,
        "s2": 3.5,
        "s3": 8.5,
        "s4": 39.0,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "CTV"
      },
      {
        "name": "4408125 AO Retail Limited",
        "claims": 74,
        "ltAvg": 96.2,
        "s1": 51.2,
        "s2": 3.8,
        "s3": 7.2,
        "s4": 34.0,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods"
      },
      {
        "name": "2039981 Amazon EU SARL",
        "claims": 156,
        "ltAvg": 88.7,
        "s1": 44.5,
        "s2": 3.8,
        "s3": 6.4,
        "s4": 34.0,
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Mobile"
      },
      {
        "name": "4470032 Costco Wholesale UK",
        "claims": 19,
        "ltAvg": 74.5,
        "s1": 36.5,
        "s2": 3.5,
        "s3": 5.5,
        "s4": 29.0,
        "bukrs": "SEUK",
        "gsper": "520B",
        "product": "Brown Goods"
      }
    ],
    "aiInsight": "For the Jun 2026 settlement, the average Claim L/T is 122.4 days — a 0.6-day improvement over the prior month (123.0 days). Exertis Ireland Estore (799.0 days) and the Mobile division (193.8 days) far exceed the company average and should be reviewed first. About 68% of total delay occurs in the Customer Delay (Promo End ~ I/V) segment.",
    "wB": {
      "SEUK": 0.55,
      "SEG": 0.3,
      "SEI": 0.15
    },
    "wG": {
      "461A": 0.7,
      "520B": 0.2,
      "702C": 0.1
    },
    "wP": {
      "Mobile": 0.32,
      "CTV": 0.22,
      "Computer": 0.16,
      "White Goods": 0.14,
      "Memory": 0.08,
      "Brown Goods": 0.08
    }
  },
  "budget_src": {
    "scaleDivs": [
      {
        "name": "TV (A1)",
        "mT": 5.0,
        "mE": 0.69,
        "qT": 15.0,
        "qE": 11.0
      },
      {
        "name": "Mobile (G1)",
        "mT": 6.0,
        "mE": 0.56,
        "qT": 18.0,
        "qE": 22.4
      },
      {
        "name": "DA (H1)",
        "mT": 3.2,
        "mE": 1.1,
        "qT": 9.6,
        "qE": 7.0
      },
      {
        "name": "VD (B1)",
        "mT": 2.1,
        "mE": 2.55,
        "qT": 6.3,
        "qE": 7.6
      },
      {
        "name": "Network",
        "mT": 1.4,
        "mE": 0.2,
        "qT": 4.2,
        "qE": 6.9
      },
      {
        "name": "ES",
        "mT": 0.07,
        "mE": 0.31,
        "qT": 0.21,
        "qE": 0.94
      },
      {
        "name": "Memory",
        "mT": 0.9,
        "mE": 0.3,
        "qT": 2.7,
        "qE": 1.9
      }
    ],
    "summary": [
      {
        "div": "Total",
        "target": 11070000,
        "approved": 1542235,
        "inproc": 26000,
        "paid": 0
      },
      {
        "div": "TV (A1)",
        "target": 5000000,
        "approved": 691856,
        "inproc": 2540,
        "paid": 0
      },
      {
        "div": "Mobile (G1)",
        "target": 6000000,
        "approved": 537284,
        "inproc": 22280,
        "paid": 0
      },
      {
        "div": "ES",
        "target": 70000,
        "approved": 313095,
        "inproc": 1380,
        "paid": 0
      }
    ],
    "conditions": [
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Approved",
        "doc": "A0S430A260003036",
        "title": "[IRL] TVAV. SOA. EXPERT. Stand alone SOA. [03.02.2026 - 03.03.2026]",
        "startDate": "2026-02-03",
        "endDate": "2026-03-03",
        "customer": "Y301343",
        "customerName": "EXPERT GROUP MEMBERS",
        "amount": 18400
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Approved",
        "doc": "A0S430A260004181",
        "title": "SOA MQ MP ~ 04 MAR - 31 DEC 2026 ~ TV ~ RICHER ~ P9 INC",
        "startDate": "2026-03-04",
        "endDate": "2026-12-31",
        "customer": "2016885",
        "customerName": "RICHER SOUNDS LIMITED",
        "amount": 32750
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Approved",
        "doc": "A0S430A260008062",
        "title": "PACKAGE ~ 15 APR-12 MAY 2026 ~ TVAV ~ CURRYS ~ NO. 428 50% WBW PACKAGE",
        "startDate": "2026-04-15",
        "endDate": "2026-05-12",
        "customer": "2015459",
        "customerName": "DSG RETAIL LTD",
        "amount": 41200
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Approved",
        "doc": "A0S430A260013591",
        "title": "SOA ~ 01 JUL-29 SEP 2026 ~ TV ~ JOHN LEWIS ~ INSTALLATION WITH THE FRAME TV SOA (65\"+) - Q3 2026",
        "startDate": "2026-07-01",
        "endDate": "2026-09-29",
        "customer": "2015609",
        "customerName": "JOHN LEWIS PLC",
        "amount": 27300
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Approved",
        "doc": "A0S430A260013717",
        "title": "PACKAGE ~ 17 JUN- 21 JUL 2026 ~ TVAV ~ CURRYS ~ S700D MIN DISCOUNT(NO.466)",
        "startDate": "2026-06-17",
        "endDate": "2026-07-21",
        "customer": "2015459",
        "customerName": "CURRYS GROUP LIMITED",
        "amount": 22150
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "In Processing",
        "doc": "A0S430A260013775",
        "title": "VOUCHER CODE ~ 03 JUN - 31 AUG 2026 ~ TV ~ AMAZON ~ QE55S84F Influencer 10% VC",
        "startDate": "2026-06-03",
        "endDate": "2026-08-31",
        "customer": "6027827",
        "customerName": "AMAZON EU SARL, UK BRANCH",
        "amount": 15800
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "In Processing",
        "doc": "A0S430A260014101",
        "title": "SOA ~ 01 JUL-29 SEP 2026 ~ TV ~ RICHER SOUNDS ~ INSTALLATION WITH THE FRAME TV SOA (65\"+) - Q3 2026",
        "startDate": "2026-07-01",
        "endDate": "2026-09-29",
        "customer": "2016885",
        "customerName": "RICHER SOUNDS LIMITED",
        "amount": 12600
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "In Processing",
        "doc": "A0S430A260015688",
        "title": "SOA MP ~01 JUL- 04 AUG 2026 ~ TV ~ CIH ~ JULY BASE - 2026 MODELS(NO.48)",
        "startDate": "2026-07-01",
        "endDate": "2026-08-04",
        "customer": "2014665",
        "customerName": "COMBINED INDEPENDENT (HOLDINGS) LTD",
        "amount": 19400
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "In Processing",
        "doc": "A0S430A260016040",
        "title": "VOUCHER CODE ~ 01 JUL-14 JUL 2026 ~ TV ~ JOHN LEWIS ~ S90F 10% VC",
        "startDate": "2026-07-01",
        "endDate": "2026-07-14",
        "customer": "2015609",
        "customerName": "JOHN LEWIS PLC",
        "amount": 8900
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "In Processing",
        "doc": "A0S430A260016051",
        "title": "PACKAGE ~ 22 JUL-25 AUG 2026 ~ TVAV ~ RICHER SOUNDS ~ Q600F - 35% WBW - SELECTED 2025 SKUS",
        "startDate": "2026-07-22",
        "endDate": "2026-08-25",
        "customer": "2016885",
        "customerName": "RICHER SOUNDS LIMITED",
        "amount": 26800
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Paid",
        "doc": "A0S430A260016137",
        "title": "SOA ~ 01 JUL-30 SEP 2026 ~ TV ~ EE ~ 48 MONTHS IFC",
        "startDate": "2026-07-01",
        "endDate": "2026-09-30",
        "customer": "2320141",
        "customerName": "EE LIMITED-TV ACCOUNT",
        "amount": 31500
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Paid",
        "doc": "A0S430A260016147",
        "title": "PACKAGE ~ 01 JUL-21 JUL 2026 ~ TVAV ~ JOHN LEWIS ~ S50B WBW SOA MIN DISCOUNT",
        "startDate": "2026-07-01",
        "endDate": "2026-07-21",
        "customer": "2015609",
        "customerName": "JOHN LEWIS PLC",
        "amount": 14200
      },
      {
        "division": "TV (A1)",
        "sdType": "Sales Allowance",
        "status": "Paid",
        "doc": "A0S430A260016157",
        "title": "VOUCHER CODE ~ 03 JUL-07 JUL 2026 ~ TV ~ JOHN LEWIS ~ LARGE SCREEN FRAME WEEKEND VC",
        "startDate": "2026-07-03",
        "endDate": "2026-07-07",
        "customer": "2015609",
        "customerName": "JOHN LEWIS PLC",
        "amount": 9700
      }
    ],
    "checkLevels": [
      "Total",
      "Rebate",
      "SA",
      "PP",
      "Coop"
    ],
    "wB": {
      "SEUK": 0.55,
      "SEG": 0.3,
      "SEI": 0.15
    },
    "wG": {
      "461A": 0.7,
      "520B": 0.2,
      "702C": 0.1
    }
  },
  "overdue_meta": {
    "columns": [
      "overdueAmt",
      "d1_15",
      "d16_31",
      "over31",
      "d32_60",
      "d61_90",
      "over90",
      "d91_180",
      "over180",
      "d181_365",
      "y1_2",
      "y2_plus"
    ],
    "buckets": [
      {
        "label": "1–15",
        "idx": 1
      },
      {
        "label": "16–31",
        "idx": 2
      },
      {
        "label": "32–60",
        "idx": 4
      },
      {
        "label": "61–90",
        "idx": 5
      },
      {
        "label": "91–180",
        "idx": 7
      },
      {
        "label": "181–365",
        "idx": 9
      },
      {
        "label": "1–2y",
        "idx": 10
      },
      {
        "label": "2y+",
        "idx": 11
      }
    ],
    "facts": [
      {
        "division": "CTV",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "CTV",
        "cells": [
          3050812,
          442815,
          671980,
          2033018,
          375012,
          1323060,
          675124,
          290375,
          138718,
          123872,
          null,
          null
        ]
      },
      {
        "division": "CTV",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "CTV",
        "cells": [
          1830488,
          265689,
          403188,
          1219811,
          225008,
          793836,
          405075,
          174225,
          83230,
          74323,
          null,
          null
        ]
      },
      {
        "division": "CTV",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "CTV",
        "cells": [
          1220325,
          177126,
          268792,
          813207,
          150005,
          529224,
          270050,
          116150,
          55487,
          49549,
          null,
          null
        ]
      },
      {
        "division": "HA",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          418068,
          10680,
          7173,
          399038,
          29242,
          10763,
          358333,
          16948,
          331384,
          278241,
          63144,
          null
        ]
      },
      {
        "division": "HA",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          250841,
          6408,
          4304,
          239423,
          17545,
          6458,
          215000,
          10169,
          198831,
          166945,
          37886,
          null
        ]
      },
      {
        "division": "HA",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "White Goods",
        "cells": [
          167227,
          4272,
          2869,
          159615,
          11697,
          4305,
          143333,
          6779,
          132554,
          111296,
          25258,
          null
        ]
      },
      {
        "division": "Monitor",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Computer",
        "cells": [
          385076,
          160415,
          1106,
          331075,
          266592,
          43363,
          236120,
          37947,
          288184,
          186310,
          1872,
          null
        ]
      },
      {
        "division": "Monitor",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "Computer",
        "cells": [
          231046,
          96249,
          664,
          198645,
          159955,
          26018,
          141672,
          22768,
          172910,
          111786,
          1124,
          null
        ]
      },
      {
        "division": "Monitor",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "Computer",
        "cells": [
          154030,
          64166,
          443,
          132430,
          106637,
          17345,
          94448,
          15179,
          115274,
          74524,
          749,
          null
        ]
      },
      {
        "division": "REF",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          748516,
          277388,
          36373,
          634755,
          98470,
          94178,
          302286,
          124843,
          317244,
          279344,
          35872,
          2028
        ]
      },
      {
        "division": "REF",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          449110,
          166433,
          21824,
          380853,
          59082,
          56507,
          181372,
          74906,
          190346,
          167606,
          21523,
          1216
        ]
      },
      {
        "division": "REF",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "White Goods",
        "cells": [
          299406,
          110955,
          14549,
          253902,
          39388,
          37671,
          120915,
          49937,
          126897,
          111737,
          14349,
          811
        ]
      },
      {
        "division": "WM",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          790381,
          69258,
          24113,
          696970,
          177450,
          119400,
          277392,
          203121,
          227331,
          202024,
          27334,
          2028
        ]
      },
      {
        "division": "WM",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          474229,
          41554,
          14468,
          418182,
          106470,
          71640,
          166436,
          121873,
          136399,
          121214,
          16400,
          1216
        ]
      },
      {
        "division": "WM",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "White Goods",
        "cells": [
          316152,
          27703,
          9645,
          278788,
          70980,
          47760,
          110957,
          81248,
          90932,
          80809,
          10934,
          811
        ]
      },
      {
        "division": "VC",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          3200,
          null,
          2636,
          288643,
          32116,
          48111,
          273880,
          37550,
          25221,
          22024,
          1722,
          2028
        ]
      },
      {
        "division": "VC",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "White Goods",
        "cells": [
          1920,
          null,
          1581,
          173186,
          19270,
          28867,
          164328,
          22530,
          15133,
          13214,
          1033,
          1216
        ]
      },
      {
        "division": "VC",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "White Goods",
        "cells": [
          1280,
          null,
          1054,
          115457,
          12846,
          19244,
          109552,
          15020,
          10088,
          8809,
          689,
          811
        ]
      },
      {
        "division": "NIWD",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Brown Goods",
        "cells": [
          341148,
          287,
          342710,
          275551,
          9570,
          7500,
          203121,
          82318,
          159766,
          159300,
          null,
          null
        ]
      },
      {
        "division": "NIWD",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "Brown Goods",
        "cells": [
          204689,
          172,
          205626,
          165331,
          5742,
          4500,
          121873,
          49390,
          95860,
          95580,
          null,
          null
        ]
      },
      {
        "division": "NIWD",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "Brown Goods",
        "cells": [
          136459,
          115,
          137084,
          110220,
          3828,
          3000,
          81248,
          32927,
          63907,
          63720,
          null,
          null
        ]
      },
      {
        "division": "Mobile",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Mobile",
        "cells": [
          16571338,
          1761318,
          933128,
          13876873,
          2017276,
          1575570,
          10183848,
          3923384,
          6260764,
          5774278,
          480232,
          26252
        ]
      },
      {
        "division": "Mobile",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "Mobile",
        "cells": [
          9942802,
          1056790,
          559877,
          8326124,
          1210366,
          945342,
          6110309,
          2354030,
          3756459,
          3464567,
          288139,
          15752
        ]
      },
      {
        "division": "Mobile",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "Mobile",
        "cells": [
          6628535,
          704527,
          373251,
          5550749,
          806910,
          630228,
          4073539,
          1569353,
          2504306,
          2309711,
          192093,
          10501
        ]
      },
      {
        "division": "Memory",
        "currency": "RUR",
        "bukrs": "SEUK",
        "gsper": "461A",
        "product": "Memory",
        "cells": [
          130041,
          13984,
          null,
          116057,
          13837,
          4256,
          97964,
          6218,
          91548,
          null,
          null,
          null
        ]
      },
      {
        "division": "Memory",
        "currency": "RUR",
        "bukrs": "SEG",
        "gsper": "461A",
        "product": "Memory",
        "cells": [
          78025,
          8390,
          null,
          69634,
          8302,
          2553,
          58779,
          3730,
          54928,
          null,
          null,
          null
        ]
      },
      {
        "division": "Memory",
        "currency": "RUR",
        "bukrs": "SEI",
        "gsper": "520B",
        "product": "Memory",
        "cells": [
          52016,
          5594,
          null,
          46423,
          5535,
          1702,
          39186,
          2487,
          36619,
          null,
          null,
          null
        ]
      }
    ],
    "divOrder": [
      "CTV",
      "HA",
      "Monitor",
      "REF",
      "WM",
      "VC",
      "NIWD",
      "Mobile",
      "Memory"
    ]
  }
};

  window.API_BASE = '';
  var realFetch = window.fetch ? window.fetch.bind(window) : null;

  function parseQS(qs) {
    var out = {};
    (qs || '').split('&').forEach(function (kv) {
      if (!kv) return;
      var p = kv.split('=');
      out[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || '');
    });
    return out;
  }

  function claimResponse(q) {
    var S = BASE.claim_src;
    var periods = S.trend.map(function (t) { return '20' + t.month.slice(1, 3) + '-' + t.month.slice(4, 6); });
    var period = periods.indexOf(q.period) >= 0 ? q.period : periods[periods.length - 1];

    var factor = (S.wB[q.bukrs] || 1) * (S.wG[q.gsper] || 1) * (S.wP[q.product] || 1);
    var avgAdj = 1 + (1 - factor) * 0.12;

    var trend = S.trend.map(function (t) {
      return { month: t.month,
               claims: Math.max(1, Math.round(t.claims * factor)),
               avgDays: Math.round(t.avgDays * avgAdj * 10) / 10 };
    });
    var sel = trend[periods.indexOf(period)];
    var baseAvg = S.trend[S.trend.length - 1].avgDays;

    var steps = S.steps.map(function (s) {
      return { name: s.name, kind: s.kind,
               days: Math.round(s.days * sel.avgDays / baseAvg * 10) / 10 };
    });
    var byProduct = S.byProduct.filter(function (p) { return !q.product || p.name === q.product; })
      .map(function (p) { return { name: p.name, avgDays: Math.round(p.avgDays * avgAdj * 10) / 10 }; });

    var customers = S.customers.filter(function (c) {
      return (!q.bukrs || c.bukrs === q.bukrs) &&
             (!q.gsper || c.gsper === q.gsper) &&
             (!q.product || c.product === q.product);
    }).map(function (c) {
      var o = JSON.parse(JSON.stringify(c));
      o.customerDelay = Math.round((c.s1 + c.s2) * 10) / 10;
      o.samsungDelay = Math.round((c.s3 + c.s4) * 10) / 10;
      return o;
    });

    return {
      period: period, availablePeriods: periods,
      appliedFilter: { bukrs: q.bukrs || '', gsper: q.gsper || '', product: q.product || '' },
      kpi: { ltAvgDays: sel.avgDays, claims: sel.claims },
      companyAvg: sel.avgDays,
      aiInsight: S.aiInsight,
      trend: trend, byProduct: byProduct, steps: steps, customers: customers,
    };
  }

  /* preview에서는 서버가 없어 .xlsx 생성이 불가하므로 같은 데이터를 CSV로 제공
     (Excel에서 바로 열림). 실제 배포에서는 백엔드가 .xlsx를 생성한다. */
  function claimRawCsv(q) {
    var rows = claimResponse(q).customers;
    var head = ['Customer', 'Company', 'BusArea', 'Product', 'No. Claims', 'L/T Avg Days',
      '1. Promo End ~ I/V Issue', '2. I/V Issue ~ I/V Receipt', 'Customer Delay (1+2)',
      '3. I/V Receipt ~ Claim Creation', '4. Claim Creation ~ End of Approval', 'Samsung Delay (3+4)'];
    var lines = [head.join(',')].concat(rows.map(function (c) {
      return ['"' + c.name.replace(/"/g, '""') + '"', c.bukrs, c.gsper, '"' + c.product + '"',
              c.claims, c.ltAvg, c.s1, c.s2, c.customerDelay, c.s3, c.s4, c.samsungDelay].join(',');
    }));
    return '\uFEFF' + lines.join('\r\n');
  }

  function overdueResponse(q) {
    var M = BASE.overdue_meta;
    var monthsBack = 0;
    if (q.period && q.period !== '2026-06') {
      var y = parseInt(q.period.slice(0, 4), 10), m = parseInt(q.period.slice(5, 7), 10);
      if (!isNaN(y) && !isNaN(m)) monthsBack = Math.max(0, (2026 - y) * 12 + (6 - m));
    }
    var pf = Math.pow(0.97, monthsBack);
    var facts = M.facts.filter(function (f) {
      return (!q.bukrs || f.bukrs === q.bukrs) &&
             (!q.gsper || f.gsper === q.gsper) &&
             (!q.product || f.product === q.product);
    }).map(function (f) {
      return { division: f.division, currency: f.currency, bukrs: f.bukrs, gsper: f.gsper, product: f.product,
               cells: f.cells.map(function (v) { return v == null ? null : Math.round(v * pf); }) };
    });
    var col = {};
    M.columns.forEach(function (c, i) { col[c] = i; });

    var byDiv = {};
    facts.forEach(function (f) {
      var d = byDiv[f.division] || (byDiv[f.division] = { currency: f.currency, cells: M.columns.map(function () { return null; }) });
      f.cells.forEach(function (v, i) {
        if (v == null && d.cells[i] == null) return;
        d.cells[i] = (d.cells[i] || 0) + (v || 0);
      });
    });
    var divisions = M.divOrder.filter(function (n) { return byDiv[n]; }).map(function (n) {
      var values = {};
      M.columns.forEach(function (c, i) { values[c] = byDiv[n].cells[i]; });
      return { name: n, currency: byDiv[n].currency, values: values };
    });

    var buckets = M.buckets.map(function (b) {
      var mobile = 0, ctv = 0, others = 0;
      facts.forEach(function (f) {
        var v = f.cells[b.idx] || 0;
        if (f.division === 'Mobile') mobile += v;
        else if (f.division === 'CTV') ctv += v;
        else others += v;
      });
      return { label: b.label, mobile: mobile, ctv: ctv, others: others, total: mobile + ctv + others };
    });

    var tot = function (name) {
      return facts.reduce(function (s, f) { return s + (f.cells[col[name]] || 0); }, 0);
    };
    var total = tot('overdueAmt');
    var pct = function (v) { return total ? Math.round(v / total * 100) : 0; };

    return {
      appliedFilter: { bukrs: q.bukrs || '', gsper: q.gsper || '', product: q.product || '' },
      summary: {
        totalOverdue: total,
        over31:  { amount: tot('over31'),  pctOfTotal: pct(tot('over31')) },
        over90:  { amount: tot('over90'),  pctOfTotal: pct(tot('over90')) },
        over180: { amount: tot('over180'), pctOfTotal: pct(tot('over180')) },
      },
      agingBuckets: buckets,
      columns: M.columns,
      divisions: divisions,
    };
  }

  function budgetResponse(q) {
    var S = BASE.budget_src;
    var scale = (S.wB[q.bukrs] || 1) * (S.wG[q.gsper] || 1);
    var m = function (v) { return Math.round(v * scale); };
    var m2 = function (v) { return Math.round(v * scale * 100) / 100; };

    var scaleDivs = S.scaleDivs.map(function (d) {
      return { name: d.name, monthTarget: m2(d.mT), monthEstimate: m2(d.mE),
               quarterTarget: m2(d.qT), quarterEstimate: m2(d.qE) };
    });
    var sum = function (k) { return scaleDivs.reduce(function (a, d) { return a + d[k]; }, 0); };
    var mT = sum('monthTarget'), mE = sum('monthEstimate');
    var qT = sum('quarterTarget'), qE = sum('quarterEstimate');

    function side(g) {
      var target = m(g.target), a = m(g.approved), i2 = m(g.inproc), p = m(g.paid);
      var total = a + i2 + p;
      return { target: target, approved: a, inproc: i2, paid: p, total: total,
               pct: target ? Math.round(total / target * 1000) / 10 : 0 };
    }
    var summaryRows = [];
    S.summary.forEach(function (g) {
      if (q.div && g.div !== q.div && g.div !== 'Total') return;
      var mo = side(g), qu = side(g);
      S.checkLevels.forEach(function (lvl) {
        var zero = { target: 0, approved: 0, inproc: 0, paid: 0, total: 0, pct: 0 };
        var filled = lvl === 'Total' || lvl === 'Rebate';
        summaryRows.push({ div: g.div, level: lvl,
          month: filled ? mo : zero, quarter: filled ? qu : zero });
      });
    });

    var conditions = S.conditions.filter(function (c) {
      return (!q.div || c.division === q.div) && (!q.status || c.status === q.status);
    }).map(function (c) {
      var o = JSON.parse(JSON.stringify(c));
      o.amount = m(c.amount);
      return o;
    });

    return {
      appliedFilter: { bukrs: q.bukrs || '', gsper: q.gsper || '', div: q.div || '', status: q.status || '' },
      month: { label: '26.02', target: mT, estimate: mE, pct: mT ? Math.round(mE / mT * 1000) / 10 : 0 },
      quarter: { label: '26.1Q', target: qT, estimate: qE, pct: qT ? Math.round(qE / qT * 1000) / 10 : 0 },
      scaleDivisions: scaleDivs,
      checkLevels: S.checkLevels,
      summaryRows: summaryRows,
      conditions: conditions,
      conditionTotal: conditions.reduce(function (a, c) { return a + c.amount; }, 0),
      divOptions: S.summary.filter(function (g) { return g.div !== 'Total'; }).map(function (g) { return g.div; }),
      statusOptions: ['Approved', 'In Processing', 'Paid'],
      months: ['2026-02'],
    };
  }

  /* preview/mock 모드에서는 서버가 없어 Budget 엑셀도 CSV로 대체 */
  function budgetRawCsv(q) {
    var rows = budgetResponse(q).conditions;
    var head = ['Division', 'SD Type', 'Status', 'Condition doc.', 'Title', 'Start Date', 'End Date', 'Customer', 'Customer Name', 'Amount(L)'];
    var lines = [head.join(',')].concat(rows.map(function (c) {
      var t = '"' + String(c.title).replace(/"/g, '""') + '"';
      var n = '"' + String(c.customerName).replace(/"/g, '""') + '"';
      return [c.division, '"' + c.sdType + '"', c.status, c.doc, t, c.startDate, c.endDate, c.customer, n, c.amount].join(',');
    }));
    return '\uFEFF' + lines.join('\r\n');
  }

  function respond(url) {
    var u = String(url).replace(/^https?:\/\/[^\/]+/, '');
    var parts = u.split('?');
    var path = parts[0];
    var q = parseQS(parts[1]);
    if (path === '/api/approval') return { json: q.view === 'all' ? BASE.approval_all : BASE.approval_inbox };
    if (path === '/api/claim-lt/raw-data') {
      return { csv: claimRawCsv(q), filename: 'claim_lt_customers_' + (q.period || 'latest') + '.csv' };
    }
    if (path === '/api/claim-lt') return { json: claimResponse(q) };
    if (path === '/api/overdue')  return { json: overdueResponse(q) };
    if (path === '/api/budget/raw-data') {
      return { csv: budgetRawCsv(q), filename: 'budget_conditions_2026-02.csv' };
    }
    if (path === '/api/budget')   return { json: budgetResponse(q) };
    return null;
  }

  window.fetch = function (url) {
    var r = respond(url);
    if (r && r.json) {
      return Promise.resolve({
        ok: true,
        status: 200,
        json: function () {
          return new Promise(function (res) { setTimeout(function () { res(r.json); }, 300); });
        },
      });
    }
    if (r && r.csv) {
      return Promise.resolve({
        ok: true,
        status: 200,
        headers: { get: function (k) {
          return k.toLowerCase() === 'content-disposition'
            ? 'attachment; filename="' + r.filename + '"' : null;
        } },
        blob: function () {
          return Promise.resolve(new Blob([r.csv], { type: 'text/csv;charset=utf-8' }));
        },
      });
    }
    return realFetch ? realFetch(url) : Promise.reject(new Error('no mock for ' + url));
  };
})();
