# Sales-Deduction AI Agent — 작업 현황 정리

> 작성일: 2026-07-13 · 와이어프레임(`0710_wireframe.html`) → 백엔드/프론트엔드 분리 구현 프로젝트

## 1. 프로젝트 개요

와이어프레임 한 장에 하드코딩되어 있던 4개 대시보드를 **Python(FastAPI) 백엔드 + JSP 프론트엔드**로 분리했다.
백엔드는 "숫자와 구조"만 내려주고, 프론트엔드(바닐라 JS)가 표현을 담당한다.
현재는 FastAPI를 띄울 수 없는 환경을 고려해 **mock 모드(기본값)** 로 Tomcat만으로 전체 화면·인터랙션이 동작한다.

## 2. 기술 스택 / 의존성

| 구분 | 스택 | 외부 라이브러리 |
|---|---|---|
| 백엔드 | Python, FastAPI, uvicorn | fastapi, uvicorn, openpyxl (엑셀 생성) |
| 프론트엔드 | JSP(Tomcat) + 바닐라 JS/CSS | 없음 (Google Fonts CDN만 사용) |
| 캐시/저장소 | 외부 인프라 없음 | JS 객체(요청 캐시), sessionStorage(필터 공유) |

## 3. 디렉토리 구조

```
sales-deduction-app/
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py          # FastAPI — 엔드포인트 + 집계/필터 로직
│       └── data.py          # 샘플 데이터 (DB 대체 지점, 실 연동 시 교체)
└── frontend/
    ├── index.jsp            # → approval.jsp 리다이렉트
    ├── approval.jsp / claimLt.jsp / overdue.jsp / budget.jsp
    ├── common/
    │   ├── head.jspf        # 공통 <head> + api.mock 플래그 처리
    │   └── header.jspf      # 공통 상단바/네비 (activeNav로 활성 탭)
    ├── static/
    │   ├── dashboard.css
    │   ├── common.js        # 유틸·fetch 캐시·공유 필터·네비 뱃지
    │   ├── approval.js / claim.js / overdue.js / budget.js
    │   └── mock-api.js      # 샘플 데이터 + 백엔드 로직 미러 (fetch 가로챔)
    └── preview/             # 서버 없이 브라우저로 확인용 HTML 4장
```

## 4. API 계약 (구현 완료)

| Method / Endpoint | 파라미터 | 반환 |
|---|---|---|
| GET `/api/approval` | `userId`, `view=inbox\|all` | condition 문서(`F01_TO_T_PT_DOCUMENT`: OBKEY/TYPE/APP_STATUS/BUKRS/GSPER), 법인·BA·Product 리스트, **view 기준** condition 최다 법인×BA `defaultFilter` |
| GET `/api/claim-lt` | `period`, `bukrs`, `gsper`, `product` | 화면 전체 데이터(KPI·트렌드·byProduct·Step·고객) 필터 반영 |
| GET `/api/claim-lt/raw-data` | 상동 | by Customer 원본 **.xlsx** (openpyxl 생성) |
| GET `/api/overdue` | `period`, `bukrs`, `gsper`, `product` | 법인×BA 팩트에서 재집계한 요약/버킷/사업부 테이블 |
| GET `/api/budget` | `period`, `div`, `status` | 예산 테이블(선택 DIV+Total) + Condition List 필터 |

## 5. 데이터 흐름 (현재: mock 모드)

1. Tomcat이 JSP 셸(빈 틀)만 서빙. `head.jspf`가 `api.mock=true`(기본)면 `mock-api.js` 로드.
2. `mock-api.js`가 `window.fetch`를 가로채, 내장 샘플 데이터 + 백엔드 미러 로직으로 응답
   (필터/period/정렬용 데이터까지 실제 API와 동일 스키마).
3. 페이지별 JS가 `/api/...` URL로 요청 → 응답으로 화면 렌더링.
4. 필터는 `sessionStorage['sd.filter']`로 페이지 간 전달. 요청 캐시는 페이지 수명의 JS 객체.
5. **백엔드 전환**: `-Dapi.mock=false -Dapi.base=http://api서버:8000` — 화면 코드 무수정.

## 6. 화면별 구현 현황

### 공통
- [x] JSP 4페이지 물리 분리 + 공통 헤더/head include(`.jspf`)
- [x] 모든 경로 상대경로화 → 임의 하위 폴더(`/sd/front/` 등) 배포 가능 (실제 Tomcat 10으로 검증)
- [x] 네비 활성 탭 표시, Approval 뱃지(전 페이지, 요청 캐시 공유로 호출 1회)
- [x] 로딩 배너 / API 실패 시 에러 배너 + 다시 시도
- [x] mock 모드 (Tomcat 단독 실행) / preview HTML (서버 전무 실행)

### 01 Approval Review
- [x] userId·view 파라미터 API, Inbox/All 전환(재조회), All 뷰 Status 컬럼
- [x] 필터 초기값 = **inbox 기준** condition 최다 법인×BA (API `defaultFilter`)
- [x] Company/BA 드롭다운 + Apply (차트·테이블 재집계, 공유 필터 저장)
- [x] 차트 클릭 필터 (스테이지 막대 / 리스크 유형 행 → 테이블 필터, 재클릭·✕로 해제)
- [x] Risk only / Clean only 토글, View risk items 버튼

### 02 Claim L/T Analysis
- [x] **0714·0715 와이어프레임 업데이트 반영**: KPI 스트립·Step 카드 → "Claim Lead Time by Step"
      히어로 카드로 교체 (4단계 비례 세그먼트 바 + 마일스톤 + Customer/Samsung Delay 브래킷
      + 전월 대비 증감 ▼▲). 0715에서 마일스톤 아이콘·보라/청록 팔레트·브래킷 강조로
      비주얼 개편. 모든 수치가 기존 응답에서 유도되어 **백엔드 무변경**.
- [x] period+법인+BA+제품 파라미터로 화면 전체 데이터 수신 (Apply·월 이동 시 재조회)
- [x] 월 네비게이션 ◀ ▶ 동작 (KPI·Step 합계 동기 변경)
- [x] by Customer 컬럼 헤더 정렬 (숫자 첫 클릭 내림차순 / 재클릭 반전 / ▲▼ 표시)
- [x] Raw Data Download — 백엔드 .xlsx 생성 (mock 모드에선 CSV 대체)

### 03 Overdue Conditions
- [x] 법인×BA 팩트 기반 서버측 필터 — 요약 카드·aging 버킷·도넛·테이블 전부 재집계
- [x] Product 필터 (사업부→제품군 매핑)

### 04 Target Plan Budget
- [x] DIV 필터 (선택 사업부 + Total 유지), Status 필터 (Approved/In Proc./Paid)
- [x] Condition List 그룹 소계/총계 재계산, 아이템 status 뱃지

## 7. 알려진 제약 / 주의사항

- **데모 스케일 가중치**: Claim의 KPI·트렌드·Step은 샘플에 원천 차원이 없어
  `data.DEMO_*` 가중치로 결정적으로 스케일함. 실 DB 연동 시 원천 집계 쿼리로 교체 필요
  (응답 스키마는 유지되므로 프론트 무수정).
- **Overdue 합계**: 원본 와이어프레임의 하드코딩 요약(45.5M)이 자체 테이블 합과 불일치했음.
  현재는 테이블에서 계산해 44.9M로 내부 일관성 확보.
- **mock 모드의 엑셀**: .xlsx 생성은 서버가 필요해 CSV로 대체 (백엔드 전환 시 자동 .xlsx).
- **CORS**: 백엔드 `allow_origins=["*"]` — 운영 전 실제 도메인으로 축소하거나
  리버스 프록시로 동일 오리진 구성 권장.
- 배포 시 JSP 5장 + `common/` + `static/`이 **같은 폴더**에 있어야 함 (Linux 대소문자 주의).

## 8. 앞으로 해야 하는 일 (TODO)

### 백엔드 연동 (우선)
- [ ] FastAPI 구동 환경 확보 → `-Dapi.mock=false`로 전환 테스트
- [ ] `data.py` → 실제 원천(SAP/DB) 조회로 교체
  - Approval: userId 기준 F01_TO_T_PT_DOCUMENT 실조회
  - Claim: KPI·트렌드·Step의 데모 가중치 제거, 원천 집계로 대체
  - Overdue: 팩트 분해 비율(_OVERDUE_SPLITS) 제거, 실제 법인×BA 데이터
  - Budget: 월별 실데이터 (현재 2026-02 한 달 고정)
- [ ] userId를 하드코딩("jane.doe") 대신 세션/SSO에서 주입 (`head.jspf`에 주입 지점 있음)
- [ ] API 명세 문서화 (백엔드 개발팀 전달용 — 필요 시 요청)

### 화면 잔여 기능 (현재 장식)
- [ ] Approval "Open report" 버튼 — 리포트 상세 화면/모달 연결
- [ ] Approval 월 네비게이션 (현재 비활성 표시) — period 파라미터 지원 시 활성화
- [ ] Overdue/Budget 월 컨트롤 (API는 period 수용, UI 미배선)
- [ ] Claim 외 테이블 정렬 (Budget Condition List 헤더에 ⇅ 표시만 있음)
- [ ] mock 재생성 스크립트를 프로젝트에 포함 (`backend/scripts/gen_mock.py` — 현재 작업 환경에만 존재)

### 운영 준비
- [ ] CORS 축소 또는 리버스 프록시(`/api` → uvicorn) 구성
- [ ] Google Fonts CDN → 폐쇄망이면 로컬 폰트로 교체
- [ ] 에러/로딩 UX 다듬기, 접근성 점검
- [ ] 응답이 무거워지면 서버측 캐시(Redis 등) 검토 — 현재는 캐시 계층 없음

## 9. 실행 방법 요약

```bash
# A. 지금(백엔드 없이): Tomcat에 frontend/ 내용물 배포 → 접속 (mock 모드 기본)
#    예: webapps/sd/front/ 에 배포 → http://호스트:9088/sd/front/index.jsp

# B. 서버 전무 확인: frontend/preview/approval.html 브라우저로 열기

# C. 백엔드 연동 시:
cd backend && pip install -r requirements.txt
uvicorn app.main:app --port 8000
# Tomcat에 -Dapi.mock=false -Dapi.base=http://localhost:8000 추가
```

## 0716 수정판(v5, standalone_9) 반영 (최신)

- **브랜드**: 헤더 "Sales Deduction AI Navigator"로 변경 (head/header jspf + preview 4종)
- **01 Approval**: 카드 제목 "Items by stage"/"Item list", 테이블 개편 — Document No + **Title(신규)** + Stage + Risk type + **Submitted at(신규)** + **동적 컬럼**(Inbox=Received at, All=Status 칩: In Processing/Completed/Rejected) + Report. All 뷰 전용 **All status 필터** 신설(동작형). 문서 데이터에 title/submittedAt/receivedAt 추가(17건 전부)
- **04 Budget**: 페이지 타이틀 **"SPOT Budget for Target Plan"**, Check Level 풀네임(Sales Allowance/Price Protection/Co-op), Condition List **Total 행을 최상단 회색 행으로 이동**("N conditions" 표기 + 합계)
- Claim/Overdue: 변경 없음

## 0716 와이어프레임 반영 (최신)

| 화면 | 변경 |
|---|---|
| 01 Approval | 테이블 툴바에 **Stage / Risk type 드롭다운** 신설(동작형) |
| 02 Claim | 마일스톤 → **알약 배지 + 가이드선/도트**, 브래킷 중앙정렬·Customer 강조(40px + MAIN DELAY DRIVER), **by Product 카드 삭제**, 트렌드 무채색 + 최종월 강조, by Customer **All/Over 토글**(기본 over) + 2단 그룹 헤더 + 평균초과 L/T 빨강 |
| 03 Overdue | 필터바 **Product 칩 삭제**(공유값 보존), aging 차트 **OVER 90 DAYS 존/브래킷**, 도넛 **8밴드** + 2열 범례, 테이블 aging 컬럼 위험도 그라데이션 |
| 04 Budget | **전면 재작성**: Company/BA 필터바, MONTH/QUARTER 실행률 카드 + division 불릿(목표=트랙 50%, 초과 빨강, 200% 캡 ⤍), SUMMARY(Div×Check Level×월/분기 6컬럼), DETAIL Condition List(플랫 10컬럼 + 상태칩 + Total행) + **Excel Download** |

API 변경: `/api/claim-lt` customers **17명 전체**(over-avg 필터는 프론트 토글), `/api/budget` 신규 스키마(month/quarter/scaleDivisions/summaryRows/conditions...), `/api/budget/raw-data`(.xlsx, mock은 CSV) 신설. Condition Amount는 와이어프레임에 값이 없어 데모값 부여.

