/* 01. Approval Review — approval.js
 *
 * API 계약: GET /api/approval?userId=..&view=inbox|all
 *   → companies, businessAreas, defaultFilter(최다 condition 조합),
 *     F01_TO_T_PT_DOCUMENT[{OBKEY, TYPE, APP_STATUS, BUKRS, GSPER, risks, checkedAt}]
 *
 * - Inbox/All 전환은 view 파라미터로 재요청 (URL별 캐시)
 * - Company/BA 필터는 클라이언트에서 적용, 차트/테이블 모두 반영
 * - 필터 초기값: 저장된 공유 필터 > API defaultFilter. Apply 시 sessionStorage에
 *   저장되어 다른 대시보드로 전달된다.
 * - 차트 클릭: 스테이지 막대 → 스테이지 필터, 리스크 행 → 리스크 유형 필터
 *   (Pending items 테이블에 적용, 같은 항목 재클릭 시 해제)
 */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc;

  var view = 'inbox';        // inbox | all (API 파라미터)
  var fBukrs = '';           // '' = All
  var fGsper = '';
  var stageSel = null;       // 차트 클릭: CREATE | CHANGE | CLAIM | null
  var riskSel = null;        // 차트 클릭: 리스크 유형명 | null
  var queueFilter = 'all';   // all | risk | clean
  var stageFilter = '';      // '' | CREATE | CHANGE | CLAIM  (0716 신설)
  var typeFilter = '';       // '' | 리스크 유형명            (0716 신설)
  var statusFilter = '';     // '' | In Processing | Completed | Rejected (v5, All 뷰 전용)
  var filterInited = false;

  var STAGE_ORDER = ['CREATE', 'CHANGE', 'CLAIM'];
  var STAGE_COLOR = { CREATE: '#0381fe', CHANGE: '#0c8fa0', CLAIM: '#e8863c' };

  function endpoint() {
    return '/api/approval?userId=' + encodeURIComponent(SD.userId) + '&view=' + view;
  }

  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.fetchJSON(endpoint()).then(function (data) {
      loading.hidden = true;
      initFilter(data);
      render(data);
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  /* 최초 1회: 저장된 공유 필터가 있으면 그것을, 없으면
     API가 계산해준 최다 condition 조합(defaultFilter)을 초기값으로 */
  function initFilter(data) {
    if (filterInited) return;
    filterInited = true;
    var stored = SD.getFilter();
    if (stored) {
      fBukrs = stored.bukrs || '';
      fGsper = stored.gsper || '';
    } else if (data.defaultFilter) {
      fBukrs = data.defaultFilter.bukrs || '';
      fGsper = data.defaultFilter.gsper || '';
      SD.setFilter({ bukrs: fBukrs, gsper: fGsper, product: '' });
    }
  }

  function render(data) {
    var el = document.getElementById('screen-queue');
    var docs = data.F01_TO_T_PT_DOCUMENT;

    // 1차: 법인 × BA 스코프 (차트·테이블 공통)
    var scope = docs.filter(function (d) {
      return (!fBukrs || d.BUKRS === fBukrs) && (!fGsper || d.GSPER === fGsper);
    });
    var scopePending = scope.filter(function (d) { return d.APP_STATUS === 'PENDING'; });

    // ---- 차트 집계 (스코프의 PENDING 기준) ----
    var byStage = {};
    STAGE_ORDER.forEach(function (s) { byStage[s] = { total: 0, risk: 0 }; });
    scopePending.forEach(function (d) {
      byStage[d.TYPE].total += 1;
      if (d.risks.length) byStage[d.TYPE].risk += 1;
    });

    var riskTypes = {};
    scopePending.forEach(function (d) {
      d.risks.forEach(function (r) {
        var t = riskTypes[r] || (riskTypes[r] = { name: r, byStage: {}, total: 0 });
        t.byStage[d.TYPE] = (t.byStage[d.TYPE] || 0) + 1;
        t.total += 1;
      });
    });
    var riskList = Object.keys(riskTypes).map(function (k) { return riskTypes[k]; })
      .sort(function (a, b) { return b.total - a.total; });
    var scopeRiskCount = scopePending.filter(function (d) { return d.risks.length; }).length;

    // ---- 테이블 행 (스코프 → 차트 클릭 필터 → risk/clean 필터) ----
    var isAllView = view === 'all';
    function statusLabel(s) {
      return s === 'PENDING' ? 'In Processing' : s === 'APPROVED' ? 'Completed' : s === 'REJECTED' ? 'Rejected' : s;
    }
    var visible = scope.filter(function (d) {
      if (stageSel && d.TYPE !== stageSel) return false;
      if (riskSel && d.risks.indexOf(riskSel) < 0) return false;
      if (stageFilter && d.TYPE !== stageFilter) return false;
      if (typeFilter && d.risks.indexOf(typeFilter) < 0) return false;
      if (isAllView && statusFilter && statusLabel(d.APP_STATUS) !== statusFilter) return false;
      if (queueFilter === 'risk') return d.risks.length > 0;
      if (queueFilter === 'clean') return d.risks.length === 0;
      return true;
    });
    var shownRisk = visible.filter(function (d) { return d.risks.length > 0; }).length;
    var isAll = view === 'all';

    // ---- 마크업 조각 ----
    var maxTot = Math.max.apply(null, STAGE_ORDER.map(function (s) { return byStage[s].total; }).concat([1]));
    var stageBars = STAGE_ORDER.map(function (s) {
      var st = byStage[s];
      var clean = st.total - st.risk;
      var riskH = st.total ? (st.risk / st.total * 100) : 0;
      var dim = stageSel && stageSel !== s;
      return '' +
        '<div class="stage-col chart-click' + (dim ? ' dim' : '') + '" data-stage="' + s + '" title="클릭하면 테이블에 필터 적용">' +
          '<div class="grow">' +
          (st.total ? '<div class="stage-bar" style="height:' + (st.total / maxTot * 100).toFixed(1) + '%">' +
            (st.risk ? '<div class="risk" style="height:' + riskH.toFixed(1) + '%"><span>' + st.risk + '</span></div>' : '') +
            (clean ? '<div class="clean" style="height:' + (100 - riskH).toFixed(1) + '%"><span>' + clean + '</span></div>' : '') +
          '</div>' : '') +
          '</div>' +
          '<div class="stage-label"><div class="n">' + esc(s) + '</div>' +
          '<div class="t">' + st.total + ' items</div></div>' +
        '</div>';
    }).join('');

    var rtMax = Math.max.apply(null, riskList.map(function (t) { return t.total; }).concat([1]));
    var riskRows = riskList.map(function (t) {
      var dim = riskSel && riskSel !== t.name;
      var segs = STAGE_ORDER.filter(function (st) { return t.byStage[st]; }).map(function (st) {
        var c = t.byStage[st];
        return '<div class="rt-seg" style="width:' + (c / rtMax * 100).toFixed(1) + '%;background:' + STAGE_COLOR[st] + '"><span>' + c + '</span></div>';
      }).join('');
      return '<div class="rt-row chart-click' + (dim ? ' dim' : '') + '" data-risk="' + esc(t.name) + '" title="클릭하면 테이블에 필터 적용">' +
             '<div class="rt-name" title="' + esc(t.name) + '">' + esc(t.name) + '</div>' +
             '<div class="rt-track">' + segs + '</div><div class="rt-total">' + t.total + '</div></div>';
    }).join('') || '<div class="card-sub">No risk items in current scope</div>';

    // v5: 상태 칩 (Completed 초록 / Rejected 빨강 / In Processing 주황)
    function statusChip(label) {
      var st = label === 'Completed' ? 'background:#e9f6ee;color:#0b7a3e;'
        : label === 'Rejected' ? 'background:#fdecec;color:#ef3434;'
        : 'background:#fdf6ee;color:#b5701f;';
      return '<span style="display:inline-block;font:600 13px/1 Manrope,sans-serif;border-radius:6px;padding:4px 9px;white-space:nowrap;' + st + '">' + esc(label) + '</span>';
    }
    var rows = visible.map(function (d) {
      var has = d.risks.length > 0;
      var riskCell = has
        ? '<span class="risk-wrap">' + d.risks.map(function (x) { return '<span class="pill-risk">' + esc(x) + '</span>'; }).join('') + '</span>'
        : '<span class="txt-clean">Clean</span>';
      // 6번째 컬럼: Inbox=Received at, All=Status 칩 (v5)
      var col6 = isAll
        ? statusChip(statusLabel(d.APP_STATUS))
        : '<span style="color:#707070;font-variant-numeric:tabular-nums">' + esc(d.receivedAt || d.checkedAt) + '</span>';
      return '<tr class="' + (has ? 'row-risk' : '') + '">' +
        '<td class="id-cell" style="padding:13px 24px;white-space:nowrap">' + esc(d.OBKEY) + '</td>' +
        '<td style="padding:13px 16px;font:500 13.5px/1.4 Manrope,sans-serif;color:#333;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(d.title || '') + '">' + esc(d.title || '') + '</td>' +
        '<td style="padding:13px 16px;white-space:nowrap;color:#707070">' + esc(d.BUKRS) + ' · ' + esc(d.GSPER) + '</td>' +
        '<td style="padding:13px 16px"><span class="pill-stage ' + esc(d.TYPE) + '">' + esc(d.TYPE) + '</span></td>' +
        '<td style="padding:13px 16px">' + riskCell + '</td>' +
        '<td style="padding:13px 16px;color:#707070;white-space:nowrap;font-variant-numeric:tabular-nums">' + esc(d.submittedAt || '') + '</td>' +
        '<td style="padding:13px 16px;white-space:nowrap">' + col6 + '</td>' +
        '<td class="num" style="padding:13px 24px"><button class="btn-report">Open report</button></td>' +
      '</tr>';
    }).join('');

    var companyOpts = '<option value="">All</option>' + data.companies.map(function (c) {
      return '<option value="' + esc(c.bukrs) + '"' + (c.bukrs === fBukrs ? ' selected' : '') + '>' + esc(c.bukrs) + '</option>';
    }).join('');
    var baOpts = '<option value="">All</option>' + data.businessAreas.map(function (b) {
      return '<option value="' + esc(b.gsper) + '"' + (b.gsper === fGsper ? ' selected' : '') + '>' + esc(b.gsper) + '</option>';
    }).join('');

    // 차트 클릭으로 걸린 필터 표시용 칩
    var activeChips = '';
    if (stageSel) activeChips += '<button class="active-chip" data-clear="stage">Stage: ' + esc(stageSel) + ' ✕</button>';
    if (riskSel)  activeChips += '<button class="active-chip" data-clear="risk">Risk: ' + esc(riskSel) + ' ✕</button>';

    el.innerHTML = '' +
      '<div class="mb22">' +
        '<div class="page-head"><div>' +
          '<h1 class="page-title">Approval Review</h1>' +
          '<div class="page-sub">' + data.pendingCount + ' awaiting your approval</div>' +
        '</div></div>' +
        '<div class="filter-bar" style="margin-top:16px;margin-bottom:0">' +
          '<div class="seg-toggle" id="view-toggle">' +
            '<button data-v="inbox"' + (isAll ? '' : ' class="on"') + '>Inbox <span style="opacity:.7">' + data.pendingCount + '</span></button>' +
            '<button data-v="all"' + (isAll ? ' class="on"' : '') + '>All <span style="opacity:.7">' + data.totalCount + '</span></button>' +
          '</div>' +
          '<div class="vdiv"></div>' +
          '<label class="filter-chip"><span class="k">Company</span><select id="f-bukrs" class="chip-select">' + companyOpts + '</select></label>' +
          '<label class="filter-chip"><span class="k">BusArea</span><select id="f-gsper" class="chip-select">' + baOpts + '</select></label>' +
          '<button class="btn-apply" id="btn-apply">Apply</button>' +
          '<div style="margin-left:auto">' + SD.monthNav('Jun 2026', data.period, true) + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="alert-risk"><span class="alert-dot"></span>' +
        '<span class="alert-text"><b>' + scopeRiskCount + '</b> pending items carry risk flags. Review these first.</span>' +
        '<button class="alert-btn" id="btn-view-risk">View risk items</button>' +
      '</div>' +
      '<div class="grid-2">' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Items by stage</div>' +
          '<div class="card-sub" style="margin-bottom:16px">Click a bar to filter the table below</div>' +
          '<div class="stage-chart">' + stageBars + '</div>' +
          '<div class="legend"><span><i style="background:#ef3434"></i>Risk</span><span><i style="background:#bcd9ff"></i>Clean</span></div>' +
        '</div>' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Risk by type</div>' +
          '<div class="card-sub" style="margin-bottom:18px">Click a row to filter the table below</div>' +
          '<div class="rt-list">' + riskRows + '</div>' +
          '<div class="legend" style="margin-top:16px">' +
            '<span><i style="background:#0381fe"></i>CREATE</span>' +
            '<span><i style="background:#0c8fa0"></i>CHANGE</span>' +
            '<span><i style="background:#e8863c"></i>CLAIM</span>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="card" style="overflow:hidden">' +
        '<div class="tbl-head-bar">' +
          '<div class="tbl-head-title">Item list</div>' +
          '<div class="tbl-head-sub">' + visible.length + ' shown · <b style="color:#ef3434">' + shownRisk + ' risk</b></div>' +
          activeChips +
          '<div style="margin-left:auto;display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
            '<div class="mini-toggle" id="queue-filter">' +
              '<button data-f="all"' + (queueFilter === 'all' ? ' class="on"' : '') + '>All</button>' +
              '<button data-f="risk"' + (queueFilter === 'risk' ? ' class="on"' : '') + '>Risk only</button>' +
              '<button data-f="clean"' + (queueFilter === 'clean' ? ' class="on"' : '') + '>Clean only</button>' +
            '</div>' +
            (function () { // 0716: Stage / Risk type 드롭다운
              var stages = ['CREATE', 'CHANGE', 'CLAIM'];
              var types = [];
              scope.forEach(function (d) { d.risks.forEach(function (r) { if (types.indexOf(r) < 0) types.push(r); }); });
              types.sort();
              function sel(id, label, opts, cur) {
                return '<select id="' + id + '" class="chip-select" style="border:1px solid #ddd;border-radius:8px;background:#fff;padding:7px 10px;font:500 12px/1 Manrope,sans-serif;color:#555">' +
                  '<option value="">' + label + '</option>' +
                  opts.map(function (v) { return '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('') +
                '</select>';
              }
              var out = sel('f-stage', 'All stages', stages, stageFilter) + sel('f-risktype', 'All risk types', types, typeFilter);
              if (isAll) out += sel('f-status', 'All status', ['In Processing', 'Completed', 'Rejected'], statusFilter); // v5
              return out;
            })() +
          '</div>' +
        '</div>' +
        '<div class="tbl-wrap" style="overflow-x:auto"><table class="tbl" style="min-width:1240px">' +
          '<thead><tr>' +
            '<th style="text-align:left;padding:12px 24px">Document No</th>' +
            '<th style="text-align:left">Title</th>' +
            '<th style="text-align:left">Company · BA</th>' +
            '<th style="text-align:left">Stage</th>' +
            '<th style="text-align:left">Risk type</th>' +
            '<th style="text-align:left">Submitted at</th>' +
            '<th style="text-align:left">' + (isAll ? 'Status' : 'Received at') + '</th>' +
            '<th class="num" style="padding:12px 24px">Report</th>' +
          '</tr></thead>' +
          '<tbody>' + (rows || '<tr><td colspan="9" style="padding:24px;text-align:center;color:#909090">No items match the current filters</td></tr>') + '</tbody>' +
        '</table></div>' +
      '</div>';

    bind(el, data);
  }

  function bind(el, data) {
    // Inbox/All: view 파라미터로 재요청
    Array.prototype.forEach.call(el.querySelectorAll('#view-toggle button'), function (btn) {
      btn.addEventListener('click', function () {
        view = btn.getAttribute('data-v');
        load();
      });
    });

    // Company/BA Apply: 클라이언트 필터 적용 + 공유 필터 저장
    el.querySelector('#btn-apply').addEventListener('click', function () {
      fBukrs = el.querySelector('#f-bukrs').value;
      fGsper = el.querySelector('#f-gsper').value;
      stageSel = riskSel = null; // 스코프가 바뀌면 차트 클릭 필터는 해제
      // Product는 이 화면에 없으므로 기존 값을 보존해 다른 대시보드로 넘긴다
      var prev = SD.getFilter() || {};
      SD.setFilter({ bukrs: fBukrs, gsper: fGsper, product: prev.product || '' });
      render(data);
    });

    // 차트 클릭 → 테이블 필터 (재클릭 시 해제)
    Array.prototype.forEach.call(el.querySelectorAll('[data-stage]'), function (col) {
      col.addEventListener('click', function () {
        var s = col.getAttribute('data-stage');
        stageSel = (stageSel === s) ? null : s;
        render(data);
      });
    });
    Array.prototype.forEach.call(el.querySelectorAll('[data-risk]'), function (row) {
      row.addEventListener('click', function () {
        var r = row.getAttribute('data-risk');
        riskSel = (riskSel === r) ? null : r;
        render(data);
      });
    });
    Array.prototype.forEach.call(el.querySelectorAll('[data-clear]'), function (chip) {
      chip.addEventListener('click', function () {
        if (chip.getAttribute('data-clear') === 'stage') stageSel = null;
        else riskSel = null;
        render(data);
      });
    });

    // 0716: Stage / Risk type 드롭다운
    var fs = el.querySelector('#f-stage'), ft = el.querySelector('#f-risktype');
    if (fs) fs.addEventListener('change', function () { stageFilter = fs.value; render(data); });
    if (ft) ft.addEventListener('change', function () { typeFilter = ft.value; render(data); });
    var fst = el.querySelector('#f-status'); // v5: All 뷰 Status 필터
    if (fst) fst.addEventListener('change', function () { statusFilter = fst.value; render(data); });

    Array.prototype.forEach.call(el.querySelectorAll('#queue-filter button'), function (btn) {
      btn.addEventListener('click', function () {
        queueFilter = btn.getAttribute('data-f');
        render(data);
      });
    });
    var viewRisk = el.querySelector('#btn-view-risk');
    if (viewRisk) viewRisk.addEventListener('click', function () {
      queueFilter = 'risk';
      render(data);
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
