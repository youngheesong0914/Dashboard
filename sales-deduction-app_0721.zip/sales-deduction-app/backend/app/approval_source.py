# -*- coding: utf-8 -*-
"""
Approval Review 데이터 소스 (사내망 실행용)
============================================
risk_analysis.py에서 대시보드 /api/approval 에 필요한 부분만 추출한 모듈.

유지한 것
  - sales.log_sd_agent 조회 (fetch_rows)
  - report_html에서 risk 이름 파싱 (extract_risks)
  - condition_id → busarea(GSPER) 추출 + CSV로 법인(BUKRS) 매핑
  - (stage, condition_id)별 최신 점검만 남기기 (latest_rows_by_stage_cond)
  - condition 최다 법인×BA 조합 계산 (defaultFilter)

제거한 것
  - task1~13 전체 (요청/실패율/리텐션/코호트 등 사용 현황 분석)
  - 콘솔 출력, JSON 리포트 저장
  - SUCCESS_TOKENS 기반 성공/실패 판정
    ※ 로그의 status는 '에이전트 실행 성공 여부'이지 결재 상태(APP_STATUS)가 아님.
      PENDING/APPROVED/REJECTED는 이 테이블에 없으므로 별도 소스 필요 (하단 미해결 항목 참조).

사용 예 (FastAPI data 계층에서):
    from .approval_source import build_approval_documents
    docs, companies, business_areas, default_filter = build_approval_documents(
        user_id="jane.doe", date_from="2026-06-22", date_to="2026-07-22")
"""
import csv
import html as html_lib
import json
import os
import re
from collections import Counter
from datetime import datetime

import psycopg2

# ─────────────────────────────────────────────
# 설정
# ─────────────────────────────────────────────
DB = dict(host='10.195.114.142', port=42866,
          user='nerpadmin', password='nerp1245@@', dbname='txt2adb')

COMPCODE_CSV = "/home/nerpadmin/syh/sales_deduction_log/compcode_ba.csv"

STAGES = ["CREATE", "CHANGE", "CLAIM"]
KEY_FULL = "html_full"

UNKNOWN_COMP = "UNKNOWN"            # busarea는 있으나 CSV에 매핑 없음
EXTRACT_FAILED = "(extract_failed)"  # condition_id가 짧아 busarea 추출 실패

# ─────────────────────────────────────────────
# risk 파싱: <h3>🔴 <이름> - Risk</h3>
# ─────────────────────────────────────────────
H3_RE = re.compile(r"<h3[^>]*>(.*?)</h3>", re.IGNORECASE | re.DOTALL)
RISK_RE = re.compile(r"🔴\s*(.+?)\s*-\s*Risk\s*$", re.IGNORECASE)


def extract_risks(html_full):
    """html_full에서 발견된 risk 이름 목록(중복 포함)을 반환."""
    names = []
    for inner in H3_RE.findall(html_full or ""):
        text = re.sub(r"<[^>]+>", "", inner)
        text = html_lib.unescape(text).strip()
        m = RISK_RE.match(text)
        if m:
            names.append(re.sub(r"\s+", " ", m.group(1).strip()))
    return names


# ─────────────────────────────────────────────
# busarea(GSPER) / 법인(BUKRS) 매핑
#   condition_id[3:7] = busarea, CSV(탭 구분)로 compcode 매핑
# ─────────────────────────────────────────────
def load_busarea_map(path=COMPCODE_CSV):
    mapping = {}
    if not os.path.exists(path):
        return mapping
    with open(path, encoding="utf-8-sig", newline="") as fp:
        reader = csv.DictReader(fp, delimiter="\t")
        fields = {(c or "").strip().lower(): c for c in (reader.fieldnames or [])}
        ba_col, cc_col = fields.get("busarea"), fields.get("compcode")
        if not ba_col or not cc_col:
            return mapping
        for row in reader:
            ba = (row.get(ba_col) or "").strip()
            cc = (row.get(cc_col) or "").strip()
            if ba:
                mapping[ba.upper()] = cc or UNKNOWN_COMP
    return mapping


def extract_busarea(condition_id):
    cid = (condition_id or "").strip()
    return cid[3:7].upper() if len(cid) >= 7 else None


def resolve_company(condition_id, busarea_map):
    """(busarea=GSPER, compcode=BUKRS) 반환."""
    ba = extract_busarea(condition_id)
    if ba is None:
        return EXTRACT_FAILED, UNKNOWN_COMP
    return ba, busarea_map.get(ba, UNKNOWN_COMP)


# ─────────────────────────────────────────────
# DB 조회
# ─────────────────────────────────────────────
def fetch_rows(user_id=None, date_from=None, date_to=None, exclude_users=None):
    """log_sd_agent 조회. 대시보드는 보통 user_id(결재자)로 좁혀서 사용."""
    where, params = [], []
    if user_id:
        where.append("user_id = %s")
        params.append(user_id)
    if date_from:
        where.append("created_at >= %s")
        params.append(date_from)
    if date_to:
        where.append("created_at < %s")
        params.append(date_to)
    if exclude_users:
        ph = ", ".join(["%s"] * len(exclude_users))
        where.append("user_id NOT IN (%s)" % ph)
        params.extend(exclude_users)

    sql = """
        SELECT user_id, condition_id, stage, status, created_at, report_html
        FROM sales.log_sd_agent
        {wc}
        ORDER BY user_id, condition_id, created_at
    """.format(wc=("WHERE " + " AND ".join(where)) if where else "")

    conn = psycopg2.connect(**DB)
    cur = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    cur.close()
    conn.close()

    out = []
    for uid, condition_id, stage, status, created_at, report_html in rows:
        val = report_html
        if isinstance(val, str):
            try:
                val = json.loads(val)
            except (ValueError, TypeError):
                val = {}
        if not isinstance(val, dict):
            val = {}
        out.append({
            "user_id": (uid or "").strip(),
            "condition_id": (condition_id or "").strip(),
            "stage": (stage or "").strip().upper(),
            "status": status,  # 에이전트 실행 상태 (결재 상태 아님)
            "created_at": str(created_at) if created_at is not None else "",
            "html_full": val.get(KEY_FULL) or "",
        })
    return out


# ─────────────────────────────────────────────
# 최신 점검만 남기기: 같은 (stage, condition)을 여러 번 조회했으면
# 마지막 결과가 현재 상태 (재조회로 risk가 해소된 경우 반영)
# ─────────────────────────────────────────────
def latest_rows_by_stage_cond(rows):
    latest = {}
    for r in rows:
        key = (r["stage"], r["condition_id"])
        cur = latest.get(key)
        if cur is None or r["created_at"] > cur["created_at"]:
            latest[key] = r
    return list(latest.values())


def _fmt_checked_at(created_at):
    """'2026-06-26 16:34:12' → 'MM-DD HH:MM' (대시보드 표시 형식)."""
    s = (created_at or "").strip().replace("T", " ")
    for n, fmt in ((19, "%Y-%m-%d %H:%M:%S"), (16, "%Y-%m-%d %H:%M")):
        try:
            return datetime.strptime(s[:n], fmt).strftime("%m-%d %H:%M")
        except ValueError:
            continue
    return s[:16]


# ─────────────────────────────────────────────
# 대시보드 응답 조립: /api/approval 이 기대하는 형태로 변환
# ─────────────────────────────────────────────
def build_approval_documents(user_id=None, date_from=None, date_to=None,
                             exclude_users=None):
    """
    반환:
      docs            : F01_TO_T_PT_DOCUMENT 형태 리스트
                        [{OBKEY, TYPE, APP_STATUS, BUKRS, GSPER, risks, checkedAt}]
      companies       : [{"bukrs": ...}]  (조회된 데이터에서 유도)
      business_areas  : [{"gsper": ...}]
      default_filter  : {"bukrs", "gsper", "product": ""}  (condition 최다 조합)
    """
    busarea_map = load_busarea_map()
    rows = fetch_rows(user_id=user_id, date_from=date_from, date_to=date_to,
                      exclude_users=exclude_users)
    latest = latest_rows_by_stage_cond(rows)

    docs = []
    for r in latest:
        gsper, bukrs = resolve_company(r["condition_id"], busarea_map)
        docs.append({
            "OBKEY": r["condition_id"],
            "TYPE": r["stage"],
            # ⚠️ 결재 상태는 이 로그에 없음. 실제 소스(SAP 등) 연동 전까지
            #    전부 PENDING으로 두면 Inbox 화면은 성립하나 All 뷰 구분은 불가.
            "APP_STATUS": "PENDING",
            "BUKRS": bukrs,
            "GSPER": gsper,
            "risks": sorted(set(extract_risks(r["html_full"]))),
            "checkedAt": _fmt_checked_at(r["created_at"]),
        })

    # 최신 점검 시각 내림차순 (대시보드 테이블 기본 정렬)
    docs.sort(key=lambda d: d["checkedAt"], reverse=True)

    companies = [{"bukrs": b} for b in sorted({d["BUKRS"] for d in docs})]
    business_areas = [{"gsper": g} for g in sorted({d["GSPER"] for d in docs})]

    combo = Counter((d["BUKRS"], d["GSPER"]) for d in docs)
    top = combo.most_common(1)[0][0] if docs else (None, None)
    default_filter = {"bukrs": top[0], "gsper": top[1], "product": ""}

    return docs, companies, business_areas, default_filter


# ─────────────────────────────────────────────
# 미해결 항목 (실 연동 시 결정 필요)
# ─────────────────────────────────────────────
# 1) APP_STATUS: log_sd_agent에는 결재 상태가 없다 (status는 에이전트 실행 결과).
#    PENDING/APPROVED/REJECTED 구분과 Inbox/All 분리는 결재 시스템(SAP) 조회가 필요.
# 2) userId 의미: 로그의 user_id는 '점검을 실행한 사람'. 대시보드의 userId
#    (결재자)와 동일 인물인지 확인 필요. 다르면 결재선 테이블로 조인해야 함.
# 3) 조회 기간: 대시보드 기본 기간(예: 최근 30일)을 정해 fetch_rows에 전달.
# 4) companies/business_areas 리스트를 조회 데이터에서 유도할지,
#    CSV(전체 마스터)에서 채울지 결정. 마스터 기준이면 load_busarea_map()의
#    키/값을 그대로 리스트업하면 됨.

if __name__ == "__main__":
    # 사내망에서 단독 실행 시 간단 점검
    docs, comps, bas, default = build_approval_documents(
        date_from="2026-06-22", date_to="2026-07-22")
    print("documents:", len(docs))
    print("companies:", [c["bukrs"] for c in comps])
    print("businessAreas:", [b["gsper"] for b in bas])
    print("defaultFilter:", default)
    for d in docs[:5]:
        print(" ", d["OBKEY"], d["TYPE"], d["BUKRS"], d["GSPER"], d["risks"], d["checkedAt"])
