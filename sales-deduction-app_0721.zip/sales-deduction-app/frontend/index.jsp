<%@ page contentType="text/html; charset=UTF-8" %>
<% response.sendRedirect("approval.jsp"); // 같은 폴더 기준 — 어떤 하위 경로에 배포해도 동작 %>
