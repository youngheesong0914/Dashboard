/* 02. Claim L/T Analysis — claim.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmt1 = SD.fmt1;

  var period = '';           // ''=최신. API가 실제 적용된 period를 돌려준다
  var sortKey = null;        // by Customer 정렬 컬럼
  var sortDir = -1;          // 1=오름차순, -1=내림차순
  var custView = 'over';     // by Customer 토글: 'over'(평균 초과만) | 'all'

  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function periodLabel(p) { // "2026-06" → "Jun 2026"
    return MONTHS[parseInt(p.slice(5, 7), 10) - 1] + ' ' + p.slice(0, 4);
  }
  function qs() {
    var q = SD.filterQS('?');
    if (period) q += (q ? '&' : '?') + 'period=' + encodeURIComponent(period);
    return q;
  }

  /* 메타(법인/BA/Product 리스트)는 Approval Review의 view=all 응답에서,
     기본 필터는 그 안의 defaultFilter(ALL 기준 최다 조합, Product=All)에서 온다. */
  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.loadMeta().then(function (meta) {
      SD.ensureFilter(meta);
      return SD.fetchJSON('/api/claim-lt' + qs()).then(function (data) {
        loading.hidden = true;
        period = data.period; // 실제 적용된 월로 동기화
        render(meta, data);
      });
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  function sortHint(key, dim) {
    return sortKey === key
      ? '<span class="sort-hint" style="color:#0b57c2">' + (sortDir === 1 ? '▲' : '▼') + '</span>'
      : '<span class="sort-hint"' + (dim ? ' style="color:' + dim + '"' : '') + '>⇅</span>';
  }

  function render(meta, data) {
    var el = document.getElementById('screen-claim');
    var f = SD.getFilter() || {};

    // ---- Monthly Trend (0716): 무채색 + 최종 월 강조, 전체 폭 ----
    var cMax = Math.max.apply(null, data.trend.map(function (t) { return t.claims; }));
    var aMin = 80, aMax = 140;
    var yOf = function (a) { return Math.max(2, Math.min(98, (1 - (a - aMin) / (aMax - aMin)) * 100)); };
    var lastIdx = data.trend.length - 1;

    var trendCols = data.trend.map(function (t, i) {
      var isLast = i === lastIdx;
      return '<div class="trend-col">' +
        '<div class="trend-avg" style="top:' + yOf(t.avgDays).toFixed(1) + '%;font:800 11.5px/1 Manrope,sans-serif;border-radius:5px;padding:2px 5px;' +
          (isLast ? 'background:#1f2430;color:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25)'
                  : 'background:#fff;color:#1f2430;box-shadow:0 0 0 1px rgba(0,0,0,.12)') + '">' + fmt1(t.avgDays) + '</div>' +
        '<div class="trend-claims" style="font:' + (isLast ? '800 12.5px' : '600 11.5px') + '/1 Manrope,sans-serif;color:' + (isLast ? '#111' : '#3a4351') + '">' + fmt(t.claims) + '</div>' +
        '<div class="trend-bar" style="height:' + (t.claims / cMax * 70).toFixed(1) + '%;max-width:' + (isLast ? 32 : 26) + 'px;background:' + (isLast ? '#1f2430' : '#c2cad6') +
          (isLast ? ';box-shadow:0 0 0 2px #1f2430,0 4px 10px rgba(31,36,48,.28)' : '') + '"></div>' +
      '</div>';
    }).join('');
    var trendLine = data.trend.map(function (t, i) {
      return ((i + 0.5) / data.trend.length * 100).toFixed(2) + ',' + yOf(t.avgDays).toFixed(2);
    }).join(' ');
    var trendX = data.trend.map(function (t, i) {
      return '<div style="font:' + (i === lastIdx ? '800 11.5px' : '600 11px') + '/1 Manrope,sans-serif;color:' + (i === lastIdx ? '#111' : '#555') + '">' + esc(t.month) + '</div>';
    }).join('');

    // ---- Lead Time 히어로 (0716): 알약 마일스톤 + 가이드/도트 + 강조 브래킷 ----
    var SEG_COLORS = ['#6b4fc0', '#a08ddd', '#0c8fa0', '#62b9c6'];
    var MS_ICONS = {
      'Promo End':      ['#6b4fc0', '<path d="m3 11 18-5v12L3 14v-3z"></path><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"></path>'],
      'I/V Issue':      ['#8d7ad2', '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"></path><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path><path d="M12 17.5v-11"></path>'],
      'I/V Receipt':    ['#0c8fa0', '<path d="m16 16 2 2 4-4"></path><path d="M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14"></path><path d="M3.3 7 12 12l8.7-5"></path><path d="M12 22V12"></path>'],
      'Claim Creation': ['#3ea8b8', '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"></rect><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21 4 22l.99-3.95 5.43-5.44Z"></path><path d="M4 13.5V6a2 2 0 0 1 2-2h2"></path><path d="M16 4h2a2 2 0 0 1 2 2v4"></path>'],
      'End of Approval': ['#0c8fa0', '<path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526"></path><circle cx="12" cy="8" r="6"></circle>'],
    };
    function pillIcon(color, paths) {
      return '<span style="width:23px;height:23px;border-radius:9999px;background:' + color + ';display:flex;align-items:center;justify-content:center;flex:0 0 auto">' +
        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' + paths + '</svg></span>';
    }

    var stepRows = data.steps.filter(function (s) { return s.kind === 'step'; });
    var ltTotal = stepRows.reduce(function (a, s) { return a + s.days; }, 0);
    var custDelay = stepRows.length >= 2 ? stepRows[0].days + stepRows[1].days : 0;
    var samDelay = ltTotal - custDelay;
    var custPct = ltTotal ? custDelay / ltTotal * 100 : 0;

    var pIdx = (data.availablePeriods || []).indexOf(data.period);
    var deltaHtml = '';
    if (pIdx > 0 && data.trend[pIdx] && data.trend[pIdx - 1]) {
      var d = data.trend[pIdx].avgDays - data.trend[pIdx - 1].avgDays;
      var down = d <= 0;
      deltaHtml = '<div style="font:600 11px/1.5 Manrope,sans-serif;white-space:nowrap;color:' + (down ? '#1a9850' : '#ef3434') + '">' +
        (down ? '▼ ' : '▲ ') + fmt1(Math.abs(d)) + ' vs prior month</div>';
    }

    var segsBar = '';
    stepRows.forEach(function (s, i) {
      var pct = ltTotal ? s.days / ltTotal * 100 : 0;
      segsBar += '<div style="width:' + pct.toFixed(2) + '%;background:' + SEG_COLORS[i % SEG_COLORS.length] +
        ';border-left:' + (i === 0 ? 'none' : '2px solid #fff') +
        ';display:flex;align-items:center;justify-content:center;color:#fff' +
        ';font:700 ' + (pct < 6 ? '13px' : '19px') + '/1 Manrope,sans-serif;overflow:hidden">' +
        fmt1(s.days) + '</div>';
    });

    // 마일스톤 경계: step 이름("A ~ B")에서 이름·누적 % 유도
    var msNames = [], acc = 0, bounds = [0];
    stepRows.forEach(function (s, i) {
      var parts = s.name.replace(/^\d+\.\s*/, '').split('~').map(function (x) { return x.trim(); });
      if (i === 0) msNames.push(parts[0]);
      msNames.push(parts[1] || '');
      acc += s.days;
      bounds.push(ltTotal ? acc / ltTotal * 100 : 0);
    });
    var MS_LINE = ['#6b4fc0', '#8d7ad2', '#0c8fa0', '#3ea8b8', '#0c8fa0'];
    var msHtml = '';
    msNames.forEach(function (name, i) {
      var first = i === 0, last = i === msNames.length - 1;
      var crowded = i > 0 && !last && (bounds[i] - bounds[i - 1]) < 6;
      if (!crowded && i > 1 && !last && (bounds[i] - bounds[i - 1]) < 18 && (bounds[i - 1] - bounds[i - 2]) < 6) crowded = true;
      var lineColor = MS_LINE[i % MS_LINE.length];
      var posLine = first ? 'left:1px' : (last ? 'right:1px' : 'left:' + bounds[i].toFixed(1) + '%;transform:translateX(-50%)');
      var posDot = first ? 'left:0' : (last ? 'right:0' : 'left:' + bounds[i].toFixed(1) + '%;transform:translateX(-50%)');
      var posPill = first ? 'left:0' : (last ? 'right:0' : 'left:' + bounds[i].toFixed(1) + '%;transform:translateX(-50%)');
      var icon = MS_ICONS[name];
      msHtml +=
        '<span style="position:absolute;top:' + (crowded ? '62px' : '30px') + ';bottom:-5px;' + posLine + ';width:2px;background:' + lineColor + ';opacity:.3"></span>' +
        '<span style="position:absolute;bottom:-7px;' + posDot + ';width:12px;height:12px;border-radius:9999px;background:' + lineColor + ';border:3px solid #fff;box-shadow:0 0 0 1px ' + lineColor + ';z-index:3"></span>' +
        '<div style="position:absolute;top:' + (crowded ? '32px' : '0') + ';' + posPill + ';z-index:4;display:inline-flex;align-items:center;gap:7px;background:#fff;border:1.5px solid ' + lineColor + ';border-radius:9999px;padding:3px 12px 3px 3px;box-shadow:0 1px 4px rgba(0,0,0,.12);white-space:nowrap">' +
          (icon ? pillIcon(lineColor, icon[1]) : '') +
          '<span style="font:800 14px/1 Manrope,sans-serif;color:#1f2430">' + esc(name) + '</span>' +
        '</div>';
    });

    var warnIcon = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg>';

    var ltHero = '' +
      '<div class="card" style="padding:22px 28px 24px;margin-bottom:16px">' +
        '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px">' +
          '<div>' +
            '<div style="font:700 10.5px/1 Manrope,sans-serif;letter-spacing:0.12em;text-transform:uppercase;color:#0b57c2;margin-bottom:6px;white-space:nowrap">Claim Lead Time</div>' +
            '<div style="font:700 18px/1.2 Manrope,sans-serif">by Step</div>' +
          '</div>' +
          '<div style="display:flex;align-items:stretch;gap:22px">' +
            '<div style="text-align:right">' +
              '<div style="font:600 10.5px/1.4 Manrope,sans-serif;letter-spacing:0.06em;text-transform:uppercase;color:#909090">Total Lead Time</div>' +
              '<div style="font:800 30px/1.1 Manrope,sans-serif;letter-spacing:-0.02em;color:#0b57c2">' + fmt1(ltTotal) +
                '<span style="font:600 13px/1 Manrope,sans-serif;color:#909090;margin-left:4px">days</span></div>' +
              deltaHtml +
            '</div>' +
            '<div style="width:1px;background:#e5e5e5"></div>' +
            '<div style="text-align:right">' +
              '<div style="font:600 10.5px/1.4 Manrope,sans-serif;letter-spacing:0.06em;text-transform:uppercase;color:#909090">No. Claims</div>' +
              '<div style="font:800 30px/1.1 Manrope,sans-serif;letter-spacing:-0.02em">' + fmt(data.kpi.claims) +
                '<span style="font:600 13px/1 Manrope,sans-serif;color:#909090;margin-left:4px">EA</span></div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div style="position:relative;height:74px">' + msHtml + '</div>' +
        '<div style="display:flex;height:52px;border-radius:8px;overflow:hidden">' + segsBar + '</div>' +
        '<div style="position:relative;height:10px;margin-top:14px">' +
          '<div style="position:absolute;left:0;width:' + (custPct - 0.4).toFixed(1) + '%;height:9px;border:1px solid #d4d4d4;border-bottom:none;border-radius:6px 6px 0 0"></div>' +
          '<div style="position:absolute;left:' + (custPct + 0.4).toFixed(1) + '%;right:0;height:9px;border:1px solid #d4d4d4;border-bottom:none;border-radius:6px 6px 0 0"></div>' +
        '</div>' +
        '<div style="display:flex;gap:1.2%;margin-top:12px">' +
          '<div style="width:' + (custPct - 0.4).toFixed(1) + '%;display:flex;flex-direction:column;align-items:center;text-align:center;gap:7px">' +
            '<div style="font:800 17px/1.2 Manrope,sans-serif;color:#4b3f9e">Customer Delay <span style="font:500 14px/1.3 Manrope,sans-serif;color:#707070">(Promo End ~ I/V Receipt)</span></div>' +
            '<div style="display:flex;align-items:baseline;gap:11px;justify-content:center">' +
              '<span style="font:800 40px/1 Manrope,sans-serif;letter-spacing:-0.01em;color:#4b3f9e">' + fmt1(custDelay) +
                '<span style="font:600 15px/1 Manrope,sans-serif;color:#9a9a9a;margin-left:5px">days</span></span>' +
              '<span style="font:800 24px/1 Manrope,sans-serif;color:#6b4fc0">' + custPct.toFixed(1) + '%</span>' +
            '</div>' +
            '<div style="display:inline-flex;align-items:center;gap:6px;color:#6b4fc0;font:700 13px/1 Manrope,sans-serif;letter-spacing:0.05em">' + warnIcon + ' MAIN DELAY DRIVER</div>' +
          '</div>' +
          '<div style="flex:1 1 0%;display:flex;flex-direction:column;align-items:center;text-align:center;gap:7px">' +
            '<div style="font:800 17px/1.2 Manrope,sans-serif;color:#587a80">Samsung Delay <span style="font:500 14px/1.3 Manrope,sans-serif;color:#909090">(I/V Receipt ~ End of Approval)</span></div>' +
            '<div style="display:flex;align-items:baseline;gap:11px;justify-content:center">' +
              '<span style="font:800 30px/1 Manrope,sans-serif;letter-spacing:-0.01em;color:#707070">' + fmt1(samDelay) +
                '<span style="font:600 15px/1 Manrope,sans-serif;color:#9a9a9a;margin-left:5px">days</span></span>' +
              '<span style="font:800 19px/1 Manrope,sans-serif;color:#4a99a5">' + (100 - custPct).toFixed(1) + '%</span>' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';

    // ---- by Customer (0716): All/Over 토글 + 필터, 정렬 유지 ----
    var companyAvg = data.companyAvg;
    var customers = data.customers.slice().filter(function (c) {
      return custView === 'all' || c.ltAvg > companyAvg;
    });
    if (sortKey) {
      customers.sort(function (a, b) {
        var x = a[sortKey], y = b[sortKey];
        var cmp = (typeof x === 'string') ? x.localeCompare(y) : (x - y);
        return cmp * sortDir;
      });
    }

    var custRows = customers.map(function (c) {
      var overAvg = c.ltAvg > companyAvg;
      return '<tr>' +
        '<td style="padding:10px 12px;font:600 14px/1.3 Manrope,sans-serif;white-space:nowrap">' + esc(c.name) + '</td>' +
        '<td class="num" style="font:700 14px/1">' + fmt(c.claims) + '</td>' +
        '<td class="num" style="background:#f6f6f7;font:800 14.5px/1 Manrope,sans-serif;color:' + (overAvg ? '#ef3434' : '#333') + '">' + fmt1(c.ltAvg) + '</td>' +
        '<td class="num" style="background:#fbfafd;border-left:2px solid #f0ecf8;color:#555">' + fmt1(c.s1) + '</td>' +
        '<td class="num" style="background:#fbfafd;color:#555">' + fmt1(c.s2) + '</td>' +
        '<td class="num" style="background:#f8f5fd;font-weight:700;color:#5d47b8">' + fmt1(c.customerDelay) + '</td>' +
        '<td class="num" style="background:#f8fbfc;border-left:2px solid #e6f1f3;color:#555">' + fmt1(c.s3) + '</td>' +
        '<td class="num" style="background:#f8fbfc;color:#555">' + fmt1(c.s4) + '</td>' +
        '<td class="num" style="background:#f3f9fa;font-weight:700;color:#0c8fa0">' + fmt1(c.samsungDelay) + '</td>' +
      '</tr>';
    }).join('');

    var thBase = 'padding:10px 12px;background:#fafafa;border-bottom:1px solid #ddd;font:600 13px/1.3 Manrope,sans-serif;color:#555;white-space:nowrap;vertical-align:bottom;cursor:pointer;';
    var custHead = '' +
      '<tr>' +
        '<th rowspan="2" class="sortable" data-sort="name" style="' + thBase + 'text-align:left">Customer ' + sortHint('name') + '</th>' +
        '<th rowspan="2" class="sortable" data-sort="claims" style="' + thBase + 'text-align:right">No. Claims ' + sortHint('claims') + '</th>' +
        '<th rowspan="2" class="sortable" data-sort="ltAvg" style="' + thBase + 'text-align:right;background:#e9ebee;border-bottom:2px solid #9aa0aa;font:800 13.5px/1.3 Manrope,sans-serif;color:#111">L/T Avg Days ' + sortHint('ltAvg') + '</th>' +
        '<th colspan="3" style="text-align:center;padding:8px 12px;background:#f2eefb;border-top:3px solid #6b4fc0;border-bottom:1px solid #e2d9f5;border-left:2px solid #fff;font:800 13.5px/1 Manrope,sans-serif;color:#5d47b8;white-space:nowrap">Customer Delay <span style="font-weight:600;color:#8a7ec8">= ① + ②</span></th>' +
        '<th colspan="3" style="text-align:center;padding:8px 12px;background:#e6f2f4;border-top:3px solid #0c8fa0;border-bottom:1px solid #cfe6ea;border-left:2px solid #fff;font:800 13.5px/1 Manrope,sans-serif;color:#0c8fa0;white-space:nowrap">Samsung Delay <span style="font-weight:600;color:#6ab5c0">= ③ + ④</span></th>' +
      '</tr>' +
      '<tr>' +
        '<th class="sortable" data-sort="s1" style="text-align:right;padding:9px 12px;background:#fbfafd;border-bottom:1px solid #ddd;border-left:2px solid #fff;font:600 13px/1.3 Manrope,sans-serif;color:#7a68b8;white-space:nowrap;cursor:pointer">① Promo End<br>~ I/V Issue ' + sortHint('s1', '#c4b4ea') + '</th>' +
        '<th class="sortable" data-sort="s2" style="text-align:right;padding:9px 12px;background:#fbfafd;border-bottom:1px solid #ddd;font:600 13px/1.3 Manrope,sans-serif;color:#7a68b8;white-space:nowrap;cursor:pointer">② I/V Issue<br>~ I/V Receipt ' + sortHint('s2', '#c4b4ea') + '</th>' +
        '<th class="sortable" data-sort="customerDelay" style="text-align:right;padding:9px 12px;background:#f2eefb;border-bottom:1px solid #ddd;font:700 13px/1.3 Manrope,sans-serif;color:#5d47b8;white-space:nowrap;vertical-align:bottom;cursor:pointer">= Subtotal ' + sortHint('customerDelay', '#c4b4ea') + '</th>' +
        '<th class="sortable" data-sort="s3" style="text-align:right;padding:9px 12px;background:#f8fbfc;border-bottom:1px solid #ddd;border-left:2px solid #fff;font:600 13px/1.3 Manrope,sans-serif;color:#4a97a3;white-space:nowrap;cursor:pointer">③ I/V Receipt<br>~ Claim Creation ' + sortHint('s3', '#9ccfd8') + '</th>' +
        '<th class="sortable" data-sort="s4" style="text-align:right;padding:9px 12px;background:#f8fbfc;border-bottom:1px solid #ddd;font:600 13px/1.3 Manrope,sans-serif;color:#4a97a3;white-space:nowrap;cursor:pointer">④ Claim Creation<br>~ End of Approval ' + sortHint('s4', '#9ccfd8') + '</th>' +
        '<th class="sortable" data-sort="samsungDelay" style="text-align:right;padding:9px 12px;background:#e6f2f4;border-bottom:1px solid #ddd;font:700 13px/1.3 Manrope,sans-serif;color:#0c8fa0;white-space:nowrap;vertical-align:bottom;cursor:pointer">= Subtotal ' + sortHint('samsungDelay', '#9ccfd8') + '</th>' +
      '</tr>';

    var tabOn = 'border:none;border-radius:9999px;padding:7px 16px;font:700 13.5px/1 Manrope,sans-serif;cursor:pointer;background:#000;color:#fff;';
    var tabOff = 'border:none;border-radius:9999px;padding:7px 16px;font:700 13.5px/1 Manrope,sans-serif;cursor:pointer;background:transparent;color:#707070;';
    var badgeStyle = custView === 'over'
      ? 'font:600 13.5px/1 Manrope,sans-serif;color:#ef3434;background:#fdecec;border:1px solid #f6c7c7;padding:5px 10px;border-radius:6px;white-space:nowrap'
      : 'font:600 13.5px/1 Manrope,sans-serif;color:#0b57c2;background:#eef4ff;border:1px solid #cfe0fb;padding:5px 10px;border-radius:6px;white-space:nowrap';
    var badgeText = (custView === 'over' ? 'Over Company Avg · ' : 'Company Avg · ') + fmt1(companyAvg) + ' days';
    var custSubtitle = custView === 'over'
      ? 'Showing only customers whose L/T Avg Days exceeds the company average (' + fmt1(companyAvg) + ' days) · Click a column header to sort'
      : 'Showing all customers — red L/T Avg Days marks those above the company average (' + fmt1(companyAvg) + ' days) · Click a column header to sort';

    el.innerHTML = '' +
      '<div class="page-head"><h1 class="page-title">Claim L/T Analysis</h1></div>' +
      '<div class="ai-box">' +
        '<div class="ai-head"><span class="ai-badge">AI</span><span class="ai-title">AI Insight</span>' +
        '<span class="ai-sub">LLM-generated summary</span></div>' +
        '<div class="ai-body">' + esc(data.aiInsight) + '</div>' +
      '</div>' +
      '<div class="filter-bar">' +
        (function () {
          var i = (data.availablePeriods || []).indexOf(data.period);
          var canPrev = i > 0, canNext = i >= 0 && i < (data.availablePeriods || []).length - 1;
          return '<div class="month-nav">' +
            '<button id="m-prev"' + (canPrev ? '' : ' disabled style="opacity:.3;cursor:default"') + '>◀</button>' +
            '<div class="m-wrap"><div class="m">' + periodLabel(data.period) + '</div>' +
            '<div class="m-sub">' + esc(data.period) + '</div></div>' +
            '<button id="m-next"' + (canNext ? '' : ' disabled style="opacity:.3;cursor:default"') + '>▶</button>' +
          '</div>';
        })() + '<div class="vdiv"></div>' +
        SD.selectChip('Company', 'f-bukrs', meta.companies.map(function (c) { return c.bukrs; }), f.bukrs) +
        SD.selectChip('BusArea', 'f-gsper', meta.businessAreas.map(function (b) { return b.gsper; }), f.gsper) +
        SD.selectChip('Product', 'f-product', meta.products, f.product) +
        '<button class="btn-apply" id="btn-apply">Apply</button>' +
      '</div>' +
      ltHero +
      '<div style="margin-bottom:16px">' +
        '<div class="card card-pad">' +
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">' +
            '<div class="card-title" style="font-size:15px">Monthly Trend</div>' +
            '<div class="legend" style="margin-top:0"><span><i style="background:#aeb8c6;width:12px;height:8px;border-radius:2px"></i>Number of Claims</span>' +
            '<span><i style="background:#2e3440;width:12px;height:2px;border-radius:0"></i>L/T Avg Days</span></div>' +
          '</div>' +
          '<div class="trend-wrap">' +
            '<svg class="trend-svg" viewBox="0 0 100 100" preserveAspectRatio="none">' +
              '<polyline points="' + trendLine + '" fill="none" stroke="#2e3440" stroke-width="0.7" vector-effect="non-scaling-stroke"></polyline>' +
            '</svg>' +
            '<div class="trend-bars">' + trendCols + '</div>' +
            '<div class="trend-x">' + trendX + '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:6px">' +
          '<div style="font:700 15px/1.2 Manrope,sans-serif">by Customer</div>' +
          '<div style="display:inline-flex;background:#f0f0f0;border-radius:9999px;padding:4px">' +
            '<button id="cust-all" style="' + (custView === 'all' ? tabOn : tabOff) + '">All customers</button>' +
            '<button id="cust-over" style="' + (custView === 'over' ? tabOn : tabOff) + '">Over company avg</button>' +
          '</div>' +
          '<span style="' + badgeStyle + '">' + badgeText + '</span>' +
          '<button class="btn-download" id="btn-download" style="margin-left:auto">⭳ Raw Data Download</button>' +
        '</div>' +
        '<div class="tbl-note">' + custSubtitle + '</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1040px">' +
          '<thead>' + custHead + '</thead>' +
          '<tbody>' + (custRows || '<tr><td colspan="9" style="padding:24px;text-align:center;color:#909090">No customers match the current filters</td></tr>') + '</tbody>' +
        '</table></div>' +
      '</div>';

    el.querySelector('#btn-apply').addEventListener('click', function () {
      SD.setFilter({
        bukrs: el.querySelector('#f-bukrs').value,
        gsper: el.querySelector('#f-gsper').value,
        product: el.querySelector('#f-product').value,
      });
      load();
    });

    // by Customer 토글 (재조회 없이 재렌더)
    el.querySelector('#cust-all').addEventListener('click', function () {
      if (custView !== 'all') { custView = 'all'; render(meta, data); }
    });
    el.querySelector('#cust-over').addEventListener('click', function () {
      if (custView !== 'over') { custView = 'over'; render(meta, data); }
    });

    // 월 이동
    var prev = el.querySelector('#m-prev'), next = el.querySelector('#m-next');
    function moveMonth(step) {
      var i = (data.availablePeriods || []).indexOf(data.period) + step;
      if (i < 0 || i >= (data.availablePeriods || []).length) return;
      period = data.availablePeriods[i];
      load();
    }
    if (prev && !prev.disabled) prev.addEventListener('click', function () { moveMonth(-1); });
    if (next && !next.disabled) next.addEventListener('click', function () { moveMonth(1); });

    // 컬럼 헤더 정렬 (첫 클릭: 문자열=오름차순, 숫자=내림차순 / 재클릭: 방향 반전)
    Array.prototype.forEach.call(el.querySelectorAll('th.sortable'), function (th) {
      th.addEventListener('click', function () {
        var key = th.getAttribute('data-sort');
        if (sortKey === key) sortDir = -sortDir;
        else { sortKey = key; sortDir = (key === 'name') ? 1 : -1; }
        render(meta, data);
      });
    });

    // Raw Data Download (.xlsx) — 현재 필터/월 그대로 서버에서 생성
    el.querySelector('#btn-download').addEventListener('click', function () {
      var url = (window.API_BASE || '') + '/api/claim-lt/raw-data' + qs();
      fetch(url).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        var cd = res.headers && res.headers.get && res.headers.get('content-disposition');
        var m = cd && /filename="?([^";]+)"?/.exec(cd);
        return res.blob().then(function (blob) {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = m ? m[1] : 'claim_lt_customers.xlsx';
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
        });
      }).catch(function (err) {
        alert('다운로드에 실패했습니다: ' + (err.message || err));
      });
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
