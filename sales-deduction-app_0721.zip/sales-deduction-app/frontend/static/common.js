/* Sales-Deduction AI Agent — common.js
 * 페이지 공통 유틸: 포맷터, fetch(요청 캐시), 로딩/에러 처리, 네비 뱃지.
 * 각 페이지 스크립트(approval.js 등)는 window.SD를 통해 사용한다. */
(function () {
  'use strict';

  var API = (window.API_BASE || '').replace(/\/$/, '');
  var USER_ID = window.USER_ID || 'jane.doe'; // 실제 앱에서는 세션에서 주입
  // 요청 캐시: 순수 자바스크립트 객체(인메모리)이며 { "URL": Promise } 형태.
  // Redis 같은 외부 캐시가 아니라, "현재 페이지가 떠 있는 동안"만 유효하고
  // 페이지 이동/새로고침 시 사라진다. 목적은 성능 최적화가 아니라 같은 페이지
  // 안에서 동일 URL 중복 호출 방지(예: 네비 뱃지 + 본문이 /api/approval 공유).
  var cache = {};

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function fmt(n) { return n == null ? '—' : Number(n).toLocaleString('en-US'); }
  function fmt1(n) { return n == null ? '—' : Number(n).toFixed(1); }
  function fmtM(v) { return v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : Math.round(v / 1e3) + 'K'; }

  function fetchJSON(path) {
    if (!cache[path]) {
      cache[path] = fetch(API + path).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status + ' — ' + path);
        return res.json();
      }).catch(function (err) {
        delete cache[path]; // 실패한 요청은 캐시에서 제거해 재시도 가능하게
        throw err;
      });
    }
    return cache[path];
  }

  function showLoading(on) {
    var el = document.getElementById('loading');
    if (el) el.hidden = !on;
  }
  function showError(err) {
    var el = document.getElementById('error');
    if (!el) return;
    document.getElementById('error-detail').textContent = err.message || String(err);
    el.hidden = false;
  }
  function hideError() {
    var el = document.getElementById('error');
    if (el) el.hidden = true;
  }

  /* 페이지 부트스트랩: init(data)를 실행하고 로딩/에러/재시도를 공통 처리 */
  function boot(endpoint, init) {
    function run() {
      hideError();
      showLoading(true);
      fetchJSON(endpoint).then(function (data) {
        showLoading(false);
        init(data);
      }).catch(function (err) {
        showLoading(false);
        showError(err);
      });
    }
    var retry = document.getElementById('retry');
    if (retry) retry.addEventListener('click', run);
    run();
  }

  /* ---------- 대시보드 간 공유 필터 (법인 × BA) ----------
     Approval Review에서 정한 필터를 sessionStorage로 다른 페이지에 넘긴다. */
  var FILTER_KEY = 'sd.filter';
  function getFilter() {
    try { return JSON.parse(sessionStorage.getItem(FILTER_KEY) || 'null'); }
    catch (e) { return null; }
  }
  function setFilter(f) {
    try { sessionStorage.setItem(FILTER_KEY, JSON.stringify(f)); } catch (e) {}
  }
  /* 공유 필터를 쿼리스트링으로 변환 (다른 대시보드 API 호출에 부착) */
  function filterQS(prefix) {
    var f = getFilter() || {};
    var q = [];
    if (f.bukrs) q.push('bukrs=' + encodeURIComponent(f.bukrs));
    if (f.gsper) q.push('gsper=' + encodeURIComponent(f.gsper));
    if (f.product) q.push('product=' + encodeURIComponent(f.product));
    return q.length ? (prefix || '?') + q.join('&') : '';
  }

  /* 필터 메타(법인/BA/Product 리스트 + defaultFilter):
     Approval Review의 view=all 응답에서 가져온다. */
  function loadMeta() {
    return fetchJSON('/api/approval?userId=' + encodeURIComponent(USER_ID) + '&view=all');
  }

  /* 저장된 공유 필터가 없으면 초기값 생성:
     ALL 기준 condition 최다 법인×BA 조합 + Product는 무조건 All */
  function ensureFilter(meta) {
    var f = getFilter();
    if (!f) {
      var d = meta.defaultFilter || {};
      f = { bukrs: d.bukrs || '', gsper: d.gsper || '', product: '' };
      setFilter(f);
    }
    if (f.product == null) f.product = '';
    return f;
  }

  /* 드롭다운이 들어간 필터 칩 마크업 */
  function selectChip(label, id, options, current) {
    var opts = '<option value="">All</option>' + options.map(function (v) {
      return '<option value="' + esc(v) + '"' + (v === current ? ' selected' : '') + '>' + esc(v) + '</option>';
    }).join('');
    return '<label class="filter-chip"><span class="k">' + esc(label) + '</span>' +
           '<select id="' + id + '" class="chip-select">' + opts + '</select></label>';
  }

  /* 네비 Approval 탭 뱃지 — 모든 페이지에서 대기 건수 표시.
     approval 페이지에서는 본문 fetch와 캐시를 공유하므로 요청이 1번만 나간다. */
  function initBadge() {
    var badge = document.getElementById('nav-badge');
    if (!badge) return;
    fetchJSON('/api/approval?userId=' + encodeURIComponent(USER_ID) + '&view=inbox').then(function (d) {
      badge.textContent = d.pendingCount;
      badge.hidden = false;
    }).catch(function () { /* 뱃지는 실패해도 조용히 넘어감 */ });
  }

  // ---------- 공용 마크업 조각 ----------
  function filterChip(k, v) {
    return '<div class="filter-chip"><span class="k">' + esc(k) + '</span>' +
           '<span class="v">' + esc(v) + '</span><span class="arr">▾</span></div>';
  }
  function monthNav(main, sub, dim) {
    return '<div class="month-nav"' + (dim ? ' style="opacity:.45"' : '') + '>' +
           '<button>◀</button><div class="m-wrap"><div class="m">' + esc(main) + '</div>' +
           '<div class="m-sub">' + esc(sub) + '</div></div><button>▶</button></div>';
  }

  window.SD = {
    userId: USER_ID,
    esc: esc, fmt: fmt, fmt1: fmt1, fmtM: fmtM,
    fetchJSON: fetchJSON, boot: boot,
    getFilter: getFilter, setFilter: setFilter, filterQS: filterQS,
    loadMeta: loadMeta, ensureFilter: ensureFilter, selectChip: selectChip,
    filterChip: filterChip, monthNav: monthNav,
  };

  initBadge();
})();
