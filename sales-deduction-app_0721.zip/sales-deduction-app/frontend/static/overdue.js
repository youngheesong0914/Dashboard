/* 03. Overdue Conditions — overdue.js */
(function () {
  'use strict';
  var SD = window.SD, esc = SD.esc, fmt = SD.fmt, fmtM = SD.fmtM;

  function load() {
    var loading = document.getElementById('loading');
    var error = document.getElementById('error');
    error.hidden = true;
    loading.hidden = false;
    SD.loadMeta().then(function (meta) {
      SD.ensureFilter(meta);
      return SD.fetchJSON('/api/overdue' + SD.filterQS('?')).then(function (data) {
        loading.hidden = true;
        render(meta, data);
      });
    }).catch(function (err) {
      loading.hidden = true;
      document.getElementById('error-detail').textContent = err.message || String(err);
      error.hidden = false;
    });
  }

  function render(meta, data) {
    var el = document.getElementById('screen-overdue');
    var f = SD.getFilter() || {};
    var s = data.summary;

    var agMax = Math.max.apply(null, data.agingBuckets.map(function (b) { return b.total; }));
    var agingCols = data.agingBuckets.map(function (b, bi) {
      var over = bi >= 4; // 91–180 이후 = Over 90 존 (0716 강조)
      var segH = function (v) { return b.total ? (v / b.total * 100).toFixed(1) : 0; };
      return '<div class="aging-col">' +
        '<div class="aging-total" style="font:' + (over ? '800' : '700') + ' 11.5px/1 Manrope,sans-serif;color:' + (over ? '#ef3434' : '#707070') + '">' + fmtM(b.total) + '</div>' +
        '<div class="aging-bar" style="height:' + Math.max(2.5, b.total / agMax * 100).toFixed(1) + '%">' +
          '<div style="background:#0381fe;height:' + segH(b.mobile) + '%"></div>' +
          '<div style="background:#8fc0f8;height:' + segH(b.ctv) + '%"></div>' +
          '<div style="background:#c9d3e2;height:' + segH(b.others) + '%"></div>' +
        '</div>' +
        '<div class="aging-label" style="font:' + (over ? '800' : '600') + ' 12.5px/1.2 Manrope,sans-serif;color:' + (over ? '#ef3434' : '#707070') + '">' + esc(b.label) + '</div>' +
      '</div>';
    }).join('');
    // 뒤 4개 버킷(Over 90) 강조 브래킷 + 배경 존
    var over90Zone = '' +
      '<div style="position:relative;height:22px;margin-bottom:2px">' +
        '<div style="position:absolute;left:calc(50% + 2px);right:6px;bottom:0;height:8px;border:2px solid #dc8f88;border-bottom:none;border-radius:6px 6px 0 0"></div>' +
        '<div style="position:absolute;left:calc(50% + 2px);right:6px;top:0;text-align:center;font:800 11px/1 Manrope,sans-serif;color:#ef3434;letter-spacing:.05em">OVER 90 DAYS</div>' +
      '</div>';
    var over90Bg = '<div style="position:absolute;top:24px;bottom:26px;left:calc(50% + 2px);right:6px;background:rgba(193,39,45,.045);border-radius:0 0 4px 4px;pointer-events:none;z-index:0"></div>';

    // 도넛(0716): 8개 aging 밴드 비중, Over-90 밴드는 두껍게
    var p90 = s.over90.pctOfTotal;
    var BAND_COLORS = ['#dfe5ee', '#c3ccdb', '#a7b3c7', '#8b9bb5', '#f7b267', '#f4845f', '#e8563f', '#c1272d'];
    var BAND_NAMES = ['1–15 Days', '16–31 Days', '32–60 Days', '61–90 Days', '91–180 Days', '181–365 Days', '1–2 Years', 'Over 2 Years'];
    var bandTot = data.agingBuckets.reduce(function (a, b) { return a + b.total; }, 0);
    var donutSegs = '', donutLegend = '', agCum = 0;
    data.agingBuckets.forEach(function (b, i) {
      var pct = bandTot ? b.total / bandTot * 100 : 0;
      var over = i >= 4;
      donutSegs += '<circle cx="21" cy="21" r="15.9" fill="none" stroke-linecap="butt" stroke="' + BAND_COLORS[i] + '" stroke-width="' + (over ? 7 : 4.5) + '" ' +
        'stroke-dasharray="' + pct.toFixed(2) + ' ' + (100 - pct).toFixed(2) + '" stroke-dashoffset="' + (25 - agCum).toFixed(2) + '"></circle>';
      agCum += pct;
      donutLegend += '<span style="display:flex;align-items:center;gap:6px;white-space:nowrap;font:' + (over ? '700' : '500') + ' 12px/1.4 Manrope,sans-serif;color:' + (over ? '#111' : '#777') + '">' +
        '<span style="width:11px;height:11px;border-radius:3px;flex:0 0 auto;background:' + BAND_COLORS[i] + '"></span>' + BAND_NAMES[i] +
        '<span style="margin-left:auto;font-weight:800">' + pct.toFixed(0) + '%</span></span>';
    });

    // 0716: aging 컬럼별 위험도 스타일 [bg, color, weight] (null=기본)
    var COLS = [
      ['overdueAmt', 'Open Amt', ['', '#000', 700]],
      ['d1_15', '1–15', null], ['d16_31', '16–31', null],
      ['over31', 'Over 31', ['#f3f3f4', '#111', 700]],
      ['d32_60', '32–60', null], ['d61_90', '61–90', null],
      ['over90', 'Over 90', ['#fbe4d3', '#c15f27', 700]],
      ['d91_180', '91–180', ['#fef4e8', '#b5701f', 600]],
      ['over180', 'Over 180', ['#fdecec', '#ef3434', 700]],
      ['d181_365', '181–365', ['#fde7d9', '#c15f27', 700]],
      ['y1_2', '1–2y', ['#fbdcd3', '#d1452f', 700]],
      ['y2_plus', '2y+', ['#f7cec8', '#c1272d', 800]],
    ];
    var headCells = COLS.map(function (c) {
      var s = c[2];
      var st = s ? 'background:' + (s[0] || '#fafafa') + ';color:' + s[1] + ';font-weight:' + s[2] + ';' : '';
      return '<th class="num" style="' + st + '">' + c[1] + '</th>';
    }).join('');
    var divRows = data.divisions.map(function (d) {
      var cells = COLS.map(function (c) {
        var s = c[2];
        var st = s ? (s[0] ? 'background:' + s[0] + ';' : '') + 'color:' + s[1] + ';font-weight:' + s[2] + ';' : '';
        return '<td class="num" style="' + st + '">' + fmt(d.values[c[0]]) + '</td>';
      }).join('');
      return '<tr><td style="font-weight:600;color:#000;white-space:nowrap">' + esc(d.name) + '</td>' +
             '<td style="color:#909090">' + esc(d.currency) + '</td>' + cells + '</tr>';
    }).join('');

    el.innerHTML = '' +
      '<div class="page-head"><div>' +
        '<h1 class="page-title">Expired Open Conditions</h1>' +
        '<div class="page-sub">Over 90 days · <b style="color:#ef3434">' + fmtM(s.over90.amount) + '</b> outstanding</div>' +
      '</div></div>' +
      '<div class="ai-box empty">' +
        '<span class="ai-badge">AI</span><span class="ai-title">AI Insight</span>' +
        '<span class="ai-sub">LLM summary slot — intentionally left blank for now</span>' +
      '</div>' +
      '<div class="filter-bar">' +
        SD.selectChip('Company', 'f-bukrs', meta.companies.map(function (c) { return c.bukrs; }), f.bukrs) +
        SD.selectChip('BA', 'f-gsper', meta.businessAreas.map(function (b) { return b.gsper; }), f.gsper) +
        '<button class="btn-apply" id="btn-apply">Apply</button>' +
      '</div>' +
      '<div class="grid-4">' +
        '<div class="sum-card"><div class="sum-k">Total open amount</div><div class="sum-v">' + fmt(s.totalOverdue) + '</div><div class="sum-p">100%</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 31 days</div><div class="sum-v">' + fmt(s.over31.amount) + '</div><div class="sum-p amber">' + s.over31.pctOfTotal + '% of total</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 90 days</div><div class="sum-v">' + fmt(s.over90.amount) + '</div><div class="sum-p red">' + s.over90.pctOfTotal + '% of total</div></div>' +
        '<div class="sum-card"><div class="sum-k">Over 180 days</div><div class="sum-v">' + fmt(s.over180.amount) + '</div><div class="sum-p red">' + s.over180.pctOfTotal + '% of total</div></div>' +
      '</div>' +
      '<div class="grid-overdue">' +
        '<div class="card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Open amount by aging bucket</div>' +
          '<div class="card-sub" style="margin-bottom:16px">Days since promotion end · stacked by division · local currency</div>' +
          '<div style="position:relative">' + over90Zone + over90Bg +
            '<div class="aging-chart" style="position:relative;z-index:1">' + agingCols + '</div>' +
          '</div>' +
          '<div class="legend"><span><i style="background:#0381fe"></i>Mobile</span>' +
          '<span><i style="background:#0c8fa0"></i>CTV</span><span><i style="background:#c9d3e2"></i>Others</span></div>' +
        '</div>' +
        '<div class="card donut-card" style="padding:20px 24px 18px">' +
          '<div class="card-title">Share by aging band</div>' +
          '<div class="card-sub">Of total open ' + fmtM(s.totalOverdue) + '</div>' +
          '<div class="donut-wrap">' +
            '<svg width="164" height="164" viewBox="0 0 42 42">' +
              '<circle cx="21" cy="21" r="15.9" fill="none" stroke="#f2f2f2" stroke-width="7"></circle>' +
              donutSegs +
            '</svg>' +
            '<div class="donut-center"><div class="donut-pct">' + p90 + '%</div><div class="donut-cap">Over 90 days</div></div>' +
          '</div>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:5px 14px;margin-top:2px">' + donutLegend + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="card card-pad">' +
        '<div style="font:700 15px/1.2 Manrope,sans-serif;margin-bottom:4px">Open amount by division</div>' +
        '<div class="tbl-note">Highlighted columns are cumulative bands (Over 31 / Over 90 / Over 180) · Local currency</div>' +
        '<div class="tbl-wrap"><table class="tbl" style="min-width:1120px">' +
          '<thead><tr><th style="text-align:left">Division</th><th style="text-align:left">L.Curr</th>' + headCells + '</tr></thead>' +
          '<tbody>' + (divRows || '<tr><td colspan="14" style="padding:24px;text-align:center;color:#909090">No data for the current filters</td></tr>') + '</tbody>' +
        '</table></div>' +
      '</div>';

    el.querySelector('#btn-apply').addEventListener('click', function () {
      var prevF = SD.getFilter() || {};
      SD.setFilter({
        bukrs: el.querySelector('#f-bukrs').value,
        gsper: el.querySelector('#f-gsper').value,
        product: prevF.product || '', // 화면에서 Product 칩 제거(0716) — 값은 보존
      });
      load();
    });
  }

  var retry = document.getElementById('retry');
  if (retry) retry.addEventListener('click', load);
  load();
})();
